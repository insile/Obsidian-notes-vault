- `abs( x )`
	- 返回数字的绝对值
```python
print(abs(5))    # 输出：5
print(abs(-5))   # 输出：5
print(abs(0))    # 输出：0

print(abs(3.14)) # 输出：3.14
print(abs(-3.14))# 输出：3.14

print(abs(-10.5))# 输出：10.5

```