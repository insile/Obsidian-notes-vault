- 逻辑运算符，或
```python
a = 0
a<5 or a>5  # True
```