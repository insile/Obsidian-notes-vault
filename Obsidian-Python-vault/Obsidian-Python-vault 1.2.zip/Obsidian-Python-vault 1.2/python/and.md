- 逻辑运算符，与
```python
a = 0
a<5 and a>-5  # True
```