- [[类的定义与实例化]]
- [[重新审视类]]
```python
# 最简单的类定义形式
'''
class 类名:
    # 代码块
'''

# 简单的类
class Dog:
    name = "Candy"
dog = Dor()
print(dog.name)
```