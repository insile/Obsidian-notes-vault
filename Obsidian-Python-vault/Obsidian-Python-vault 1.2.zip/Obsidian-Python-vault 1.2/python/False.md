- [[数字类型|布尔类型值]]，假
```python
type(False)  # False

False == 0  # True

False + 1  # 1
```