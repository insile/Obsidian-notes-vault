- `input( prompt )`
	- 返回用户输入，括号内引号为提示信息

```python
# 获取用户输入并将其存储在变量中
name = input("Please enter your name: ")
print("Hello, " + name + "!")

# 获取用户输入的数字并执行计算
num1 = float(input("Enter a number: "))
num2 = float(input("Enter another number: "))
result = num1 + num2
print("The sum is:", result)

```

