- [[异常处理|断言检查]]
	- 它用于在代码中检查某个条件是否满足，如果条件为False，则会触发AssertionError异常，从而中断程序的执行
	- 其中，condition是一个表达式或条件，如果为False，则会触发断言异常；message是一个可选的错误消息，用于在断言失败时提供更详细的信息，方便调试。
```python
# 断言检查形式
'''
assert condition, message
'''

# 简单的断言检查
def divide(a, b):
    assert b != 0, "错误: 分母不能为0"
    return a / b

result = divide(10, 2)
print("Result:", result)

result = divide(10, 0)  # 这里会触发 AssertionError
print("Result:", result)  # 这一行代码不会执行，因为上一行已经中断了程序的执
```