- [[库|引用库]]
```python
# import 模块/包
import pandas  
pandas.DataFrame()

# from 模块/包 import 对象
from pathlib import Path

# import 模块/包 as 别名
import pandas as pd

# from 模块/包 import *

```