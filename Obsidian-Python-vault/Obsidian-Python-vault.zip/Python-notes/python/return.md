- [[函数及方法类型|函数及方法]]中的返回值
```python
def add(a, b):
    sum = a + b
    return sum  # 返回值
```