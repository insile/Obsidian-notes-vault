编码：返回字符串对应的[[bytes类型]]
- str.encode(encoding='UTF-8',errors='strict')
```python
In : '知'.encode()
Out: b'\xe7\x9f\xa5'
```
