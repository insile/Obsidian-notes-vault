- 逻辑运算符，非
```python
a = 0
not a > 5  # True

not 5  # False
not 0  # True
```