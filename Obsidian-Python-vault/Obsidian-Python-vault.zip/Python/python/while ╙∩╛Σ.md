- 使用保留字 [[while]]
- 无限循环结构，由条件控制的循环运行方式
- 反复执行语句块，直到条件不满足结束
```python
'''
while 条件:
	循环体
'''

count = 0
while count < 5:
    print("Count:", count)
    count += 1
```