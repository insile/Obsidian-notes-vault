- [[数字类型|布尔类型值]]，真
```python
type(True)  # True

True == 1  # True

True + 1  # 2
```