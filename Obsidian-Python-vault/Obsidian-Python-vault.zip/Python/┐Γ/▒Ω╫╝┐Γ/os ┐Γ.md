##### os 库
 - [[os 环境变量]]
 - [[os 文件路径]]
 - [[os 进程管理]]
```python
os.name  # 字符串指示正在使用的平台 'posix', 'nt', 'java'
```