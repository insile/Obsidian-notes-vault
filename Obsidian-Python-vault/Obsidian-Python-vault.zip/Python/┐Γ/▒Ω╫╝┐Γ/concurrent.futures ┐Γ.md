##### concurrent.futures 库
- [[class concurrent.futures.Executor]] 抽象基类执行器
	- [[class concurrent.futures.ThreadPoolExecutor]], 使用线程池来异步执行调用
	- [[class concurrent.futures.ProcessPoolExecutor]], 使用进程池来异步地执行调用

