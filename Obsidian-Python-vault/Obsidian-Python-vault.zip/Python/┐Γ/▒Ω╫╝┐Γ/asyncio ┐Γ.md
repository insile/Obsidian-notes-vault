##### asyncio 库
- [[认识 asyncio 库]]
- [[同步代码和异步代码]]
- 异步程序运行器
	- [[asyncio.run()]]
	- [[class asyncio.Runner]]
- [[可等待对象]]

##### 示例
- [[简单异步爬虫示例]]
- [[实时数据处理示例]]


