##### [[Task 创建]]
##### Task 实例方法
```python
Task.done()
# 如果 Task 对象 已完成 则返回 True

Task.cancel(msg=None)
# 请求取消 Task 对象
```