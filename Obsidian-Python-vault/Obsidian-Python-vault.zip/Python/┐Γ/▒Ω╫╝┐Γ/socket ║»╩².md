##### socket 函数
```python
socket.gethostbyname(hostname)
	# 将主机名转换为 IPv4 地址格式。IPv4 地址以字符串格式返回，如 '100.50.200.5'。

socket.getnameinfo(sockaddr, flags)
	# 将套接字地址 sockaddr 转换为2元组(host, port) (主机、端口)

```
