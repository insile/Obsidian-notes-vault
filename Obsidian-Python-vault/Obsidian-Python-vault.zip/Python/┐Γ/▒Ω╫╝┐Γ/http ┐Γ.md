##### http 库
- [[认识 http]]
- [[class http.HTTPStatus]]  HTTP 状态码
- [[class http.HTTPMethod]] HTTP 方法
- [[http.client 模块]] 是一个低层级的 HTTP 协议客户端；对于高层级的 URL 访问请使用 urllib.request
- [[http.server 模块]] 包含基于 socketserver 的基本 HTTP 服务类
- [[http.cookies 模块]] 包含一些有用来实现通过 cookies 进行状态管理的工具
- [[http.cookiejar 模块]] 提供了 cookies 的持久化


