##### urllib.request 模块
- [[request.urlopen()]] 请求函数
- [[class request.Request]] 请求对象
- [[Opener]]
- [[Handler]]
