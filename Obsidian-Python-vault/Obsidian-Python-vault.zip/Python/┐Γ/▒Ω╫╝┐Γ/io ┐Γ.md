##### io 库
- [[认识 io]]
- [[open()]]
- [[io 库 类.canvas|io class]]
##### 示例
- [[流读写]]
