##### beautiful soup 库
- [[认识 beautiful soup 库]]
- [[beautiful soup 基本使用]]
- [[HTML 解析器]]
---
- [[bs4.BeautifulSoup 类]]  HTML 文档树
- [[bs4.Tag 类]]  HTML 标签
- [[bs4.NavigableString 类]]  标签修饰的字符串
- [[bs4.Comment 类]]  注释字符串
