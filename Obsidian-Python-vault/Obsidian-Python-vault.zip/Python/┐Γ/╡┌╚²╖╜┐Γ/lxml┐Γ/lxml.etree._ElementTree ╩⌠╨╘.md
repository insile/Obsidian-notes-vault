##### lxml.etree._ElementTree 属性
```python
_ElementTree.docinfo
	# 有关解析器和 DTD 提供的文档的信息。

_ElementTree.parser
	# 用于解析此 ElementTree 中的文档的解析器。
```

