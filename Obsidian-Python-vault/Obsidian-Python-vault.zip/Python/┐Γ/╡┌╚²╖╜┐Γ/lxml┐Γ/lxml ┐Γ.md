##### lxml 库
- [[XPath 语法]]
- [[lxml 基本使用]]
---
- lxml.etree 模块
	- [[lxml.etree 函数]]
	- [[class lxml.etree._Element]]  表示XML文档中的元素节点
	- [[class lxml.etree._ElementTree]]  表示整个XML文档的类，它包含一个根元素节点和整个文档的树结构

