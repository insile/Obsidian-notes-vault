##### lxml.etree._ElementTree 创建
```python
etree.ElementTree(element=None, file=None, parser=None)
	# 从 _Element 解析返回_ElementTree

etree.parse(source, parser=None, base_url=None)
	# 从 文件对象 解析返回_ElementTree
```