##### [[numpy 积运算]]
##### [[numpy.linalg 矩阵分解]]
##### [[numpy.linalg 范数, 行列式, 迹]]

##### [[numpy.linalg 矩阵特征值]]

##### [[numpy.linalg 求解]]
