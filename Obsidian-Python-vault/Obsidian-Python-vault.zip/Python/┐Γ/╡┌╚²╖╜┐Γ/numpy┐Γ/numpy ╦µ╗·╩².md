##### [[numpy.random 随机生成器]]
##### [[numpy.random 随机状态]]
