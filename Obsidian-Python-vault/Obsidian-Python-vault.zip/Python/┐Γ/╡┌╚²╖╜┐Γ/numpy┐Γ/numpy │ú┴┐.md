##### numpy 常量
```python
np.inf  # （正）无穷大
np.NINF  # 负无穷大
np.nan  # 不是数字
np.NZERO  # 负零
np.PZERO  # 正零
np.e  # 自然数
np.pi  # pi
np.newaxis  # None

```