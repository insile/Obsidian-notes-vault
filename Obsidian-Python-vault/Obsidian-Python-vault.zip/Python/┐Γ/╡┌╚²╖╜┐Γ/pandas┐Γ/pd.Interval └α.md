##### Interval 类
- 代表一个区间
- [[Interval 创建]]
- Interval 属性
- Interval 方法