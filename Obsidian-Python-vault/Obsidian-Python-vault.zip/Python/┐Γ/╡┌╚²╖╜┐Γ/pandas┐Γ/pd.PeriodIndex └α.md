##### PeriodIndex 类
- [[PeriodIndex 创建]]
- PeriodIndex 属性
- PeriodIndex 方法