##### Categorical 类
- 代表分类变量
- [[Categorical 创建]]
- Categorical 属性
- Categorical 方法