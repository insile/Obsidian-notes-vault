##### CategoricalIndex 类
- [[CategoricalIndex 创建]]
- CategoricalIndex 属性
- CategoricalIndex 方法