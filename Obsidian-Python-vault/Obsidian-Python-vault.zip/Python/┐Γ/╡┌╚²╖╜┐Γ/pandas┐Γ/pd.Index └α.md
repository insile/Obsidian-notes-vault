##### pd.Index 类
- [[Index 创建]]  自定义索引
- [[Index 属性]]
- [[Index 方法]]
##### pd.Index 子类
- [[pd.RangeIndex 类]]  数字索引，默认索引
- [[pd.CategoricalIndex 类]]  分类索引
- [[pd.MultiIndex 类]]  [[pandas 多级索引|多级索引]]
- [[pd.IntervalIndex 类]]  区间索引
- [[pd.DatetimeIndex 类]]  时间索引
- [[pd.TimedeltaIndex 类]]  时间差索引
- [[pd.PeriodIndex 类]]  周期索引
##### [[pandas 索引示例]]