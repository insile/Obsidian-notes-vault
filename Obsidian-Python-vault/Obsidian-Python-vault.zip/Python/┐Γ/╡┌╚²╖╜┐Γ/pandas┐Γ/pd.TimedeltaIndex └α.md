##### TimedeltaIndex 类
- [[TimedeltaIndex 创建]]
- TimedeltaIndex 属性
- TimedeltaIndex 方法