##### [[Series 函数,窗口,分组]]
##### DataFrame 函数,窗口,分组
- [[DataFrame.apply()]]  沿 DataFrame 的轴应用函数
- [[DataFrame.applymap()]]  每个元素应用一个函数