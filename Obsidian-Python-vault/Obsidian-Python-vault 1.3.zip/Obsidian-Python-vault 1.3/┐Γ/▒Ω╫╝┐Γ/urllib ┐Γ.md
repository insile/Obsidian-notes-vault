##### urllib 库
- [[认识 url]]
- [[urllib.request 模块]] 打开和读取 URL
- [[urllib.error 模块]] 包含 urllib.request 抛出的异常
- [[urllib.parse 模块]] 用于解析 URL
- [[urllib.robotparser 模块]] 用于解析 robots.txt 文件


