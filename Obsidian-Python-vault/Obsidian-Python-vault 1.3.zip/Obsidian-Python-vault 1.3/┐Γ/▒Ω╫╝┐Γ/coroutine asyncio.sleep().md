##### coroutine asyncio.sleep()
- 用于在指定的时间内暂停协程的执行，从而模拟等待操作
- 这个函数的作用类似于在同步代码中使用 time.sleep()，但在异步环境中使用它不会阻塞整个事件循环，而只会暂停当前协程的执行
```python
coroutine asyncio.sleep(delay, result=None)
	# 阻塞 delay 指定的秒数
	# 如果指定了 result，则当协程完成时将其返回给调用者
	# sleep() 总是会挂起当前任务，以允许其他任务运行
```
##### 示例
```python
import asyncio
async def main():
    print("Start sleeping")
    await asyncio.sleep(2)
    await asyncio.sleep(2)
    print("Finished sleeping")
asyncio.run(main())  # 4s


import asyncio
async def main():
    print("Start sleeping")
    await asyncio.gather(asyncio.sleep(2),asyncio.sleep(2))
    print("Finished sleeping")
asyncio.run(main())  # 2s
```