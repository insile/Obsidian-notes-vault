##### awaitable asyncio.shield()
```python
awaitable asyncio.shield(aw)
# 保护一个 可等待对象 防止其被 取消。
```
##### 示例
```python
await asyncio.shield(task)
```