##### multiprocessing 库
- [[class multiprocessing.Process]]
- [[class multiprocessing.Queue]]
- [[class multiprocessing.Pool]]
- [[进程间共享内存]]