##### class io.RawIOBase
- 原始二进制流的基类。 
- 继承自 [[class io.IOBase]]