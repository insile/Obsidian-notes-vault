- 异步上下文管理器可以在协程的进入和退出时执行异步操作，以确保资源在正确的时间被获取和释放。
```python
import asyncio

class AsyncResource:
    async def __aenter__(self):
        print("Acquiring resource asynchronously")  # 1
        await asyncio.sleep(1)
        print("Resource acquired")  # 2
        return self

    async def __aexit__(self, exc_type, exc, tb):
        print("Releasing resource asynchronously")  # 4
        await asyncio.sleep(1)
        print("Resource released")  # 5

async def main():
    async with AsyncResource() as resource:
        print("Using the resource asynchronously")  # 3
        await asyncio.sleep(2)

asyncio.run(main())

```