##### coroutine asyncio.wait_for()
```python
coroutine asyncio.wait_for(aw, timeout)
# 等待 aw 可等待对象 完成，指定 timeout 秒数后超时。
```
##### 示例
```python
try:
	await asyncio.wait_for(aw, timeout=2)
except TimeoutError:
	print('timeout')
```