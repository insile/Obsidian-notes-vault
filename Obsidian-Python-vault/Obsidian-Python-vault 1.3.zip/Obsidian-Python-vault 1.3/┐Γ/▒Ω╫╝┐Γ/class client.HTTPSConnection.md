##### client.HTTPSConnection 类
```python
client.HTTPSConnection(host, port=None, key_file=None, cert_file=None, [timeout, ]source_address=None, *, context=None, check_hostname=None, blocksize=8192)
	# HTTPConnection 的子类，使用 SSL 与安全服务器进行通信。 默认端口为 443。
```