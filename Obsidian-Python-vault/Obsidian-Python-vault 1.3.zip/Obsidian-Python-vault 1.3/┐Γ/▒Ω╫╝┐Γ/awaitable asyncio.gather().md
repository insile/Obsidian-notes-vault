##### awaitable asyncio.gather()
```python
awaitable asyncio.gather(*aws, return_exceptions=False)
# 直接并行多个任务并等待结果，返回结果
# 如果 return_exceptions 为 False (默认)，所引发的首个异常会立即传播给等待 gather() 的任务。aws 序列中的其他可等待对象 不会被取消 并将继续运行
# 如果 return_exceptions 为 True，异常会和成功的结果一样处理，并聚合至结果列表
```
##### 示例
```python
import asyncio
import time

async def say_after(delay, what): # 子协程
    await asyncio.sleep(delay)
    print(what)

async def main(): # 主协程
    print(f"started at {time.strftime('%X')}")
    # 主协程挂起，等待子协程
    # await say_after(1, 'hello') # 等待子协程 1 s
    # await say_after(2, 'world') # 等待子协程 2 s
    await asyncio.gather(say_after(1, 'hello'),say_after(2, 'world'))  # 并行2个任务
    print(f"finished at {time.strftime('%X')}")  # 共等 2 s

asyncio.run(main())
# 事件循环处理主协程
```