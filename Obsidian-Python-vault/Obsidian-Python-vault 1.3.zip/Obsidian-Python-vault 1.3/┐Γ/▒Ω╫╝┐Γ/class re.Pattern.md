##### class re.Pattern
```python
# 实例方法，同re函数
Pattern.search(string[, pos[, endpos]])
Pattern.match(string[, pos[, endpos]])
Pattern.split(string, maxsplit=0)
Pattern.findall(string[, pos[, endpos]])
Pattern.finditer(string[, pos[, endpos]])
Pattern.sub(repl, string, count=0)
Pattern.subn(repl, string, count=0)
```