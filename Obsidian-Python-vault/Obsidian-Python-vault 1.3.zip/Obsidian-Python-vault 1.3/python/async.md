- 指定一个函数为协程
- 我们可以理解为轻量级的线程。 通过一个线程实现代码块相互切换执行
- [[asyncio 库]]
```python
import asyncio
import time

async def say_after(delay, what): # 子协程
    await asyncio.sleep(delay)
    print(what)

async def main(): # 主协程
    print(f"started at {time.strftime('%X')}")

	# 主协程挂起，等待子协程
    await say_after(1, 'hello') # 等待子协程
    await say_after(2, 'world') # 等待子协程

    print(f"finished at {time.strftime('%X')}")

asyncio.run(main())
# 事件循环处理主协程
```