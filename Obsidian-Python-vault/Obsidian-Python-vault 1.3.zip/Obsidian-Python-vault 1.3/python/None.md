- 空类型
```python
type(None)  # NoneType
```