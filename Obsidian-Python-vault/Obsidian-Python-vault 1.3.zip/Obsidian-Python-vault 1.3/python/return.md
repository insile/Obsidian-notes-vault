- [[函数及方法类型|函数及方法]]中的返回值
```python
# 返回形式
'''
return 变量
'''

def add(a, b):
    sum = a + b
    return sum  # 返回值
```