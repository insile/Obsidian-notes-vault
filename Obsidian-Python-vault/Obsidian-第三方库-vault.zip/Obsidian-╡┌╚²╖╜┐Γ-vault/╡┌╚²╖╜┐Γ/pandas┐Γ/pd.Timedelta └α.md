##### timedelta 类
- 表示时间差，datetime.timedelta 的替换
- [[Timedelta 创建]]
- Timedelta 属性
- Timedelta 方法