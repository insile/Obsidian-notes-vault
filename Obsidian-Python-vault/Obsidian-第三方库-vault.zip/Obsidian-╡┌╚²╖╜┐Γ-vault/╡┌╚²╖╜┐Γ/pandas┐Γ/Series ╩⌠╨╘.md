##### Series 属性
```python
Series.index
	# 返回索引，index类
Series.values
	# 返回值，ndarray类
Series.name
	# Series对象名，列名
Series.dtype
	# 返回基础数据的dtype对象
Series.shape
	# 返回基础数据形状的元组
Series.size
	# 元素个数
Series.is_unique
	# 是否是唯一值
Series.hasnans
	# 是否存在缺失值
```
