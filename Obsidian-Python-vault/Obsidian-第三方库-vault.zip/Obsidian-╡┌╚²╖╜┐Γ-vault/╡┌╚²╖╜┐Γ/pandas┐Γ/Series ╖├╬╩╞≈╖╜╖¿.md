##### Series 访问器方法
- 提供了特定 dtype 的方法
- [[Series.str]]  String 
- [[Series.dt]]  Datetime, Timedelta, Period
- [[Series.cat]]  Categorical
- Series.sparse  Sparse
