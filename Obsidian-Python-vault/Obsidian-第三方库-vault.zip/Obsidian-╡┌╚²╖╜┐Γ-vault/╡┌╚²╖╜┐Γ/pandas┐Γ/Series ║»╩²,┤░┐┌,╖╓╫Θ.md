##### Series 函数,窗口,分组
- [[Series.apply()]]  对 Series 的值调用函数
- [[Series.transform()]]  对 Series 的值调用函数
- [[Series.pipe()]]  函数链
- [[Series.map()]]  映射值
- [[Series.agg()]]  汇总聚合
- [[Series.groupby()]]  分组聚合  [[GroupBy 类|返回GroupBy对象]]
- [[Series.rolling()]]  滑动窗口  [[Window 类#滑动窗口方法|返回Rolling对象]]
- [[Series.expanding()]]  扩张窗口  [[Window 类#扩张窗口计算|返回Expanding对象]]
- [[Series.ewm()]]  指数加权移动窗口  [[Window 类#指数加权移动窗口|返回ExponentialMovingWindow对象]]



