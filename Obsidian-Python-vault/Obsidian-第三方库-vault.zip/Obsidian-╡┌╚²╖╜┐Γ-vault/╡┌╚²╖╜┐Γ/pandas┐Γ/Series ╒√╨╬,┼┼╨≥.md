##### Series 整形,排序
- [[Series.sort_values()]]  按值排序
- [[Series.sort_index()]]  按索引排序
- [[Series.unstack()]]  pivot
```python
Series.argmin() # 最小值整数位置
Series.argmax() # 最大值整数位置
```