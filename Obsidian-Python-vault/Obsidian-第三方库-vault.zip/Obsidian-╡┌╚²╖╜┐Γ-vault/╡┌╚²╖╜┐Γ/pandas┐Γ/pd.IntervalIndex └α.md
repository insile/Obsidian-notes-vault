##### IntervalIndex 类
- [[IntervalIndex 创建]]
- IntervalIndex 属性
- IntervalIndex 方法