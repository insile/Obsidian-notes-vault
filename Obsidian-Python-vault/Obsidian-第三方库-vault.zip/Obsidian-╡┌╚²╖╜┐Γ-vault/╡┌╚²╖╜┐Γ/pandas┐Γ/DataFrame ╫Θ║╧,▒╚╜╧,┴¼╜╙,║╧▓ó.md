##### [[Series 组合,比较,连接,合并]]
##### DataFrame 组合,比较,连接,合并
- [[DataFrame.assign()]]  添加新列
- [[DataFrame.compare()]]  比较两个表
- [[DataFrame.join()]]  数据库连接（默认左连接，只能连接左表索引）
- [[DataFrame.merge()]]  数据库连接（默认内连接，通用方法）
- [[DataFrame.update()]]  从另一个dataframe更新数据
