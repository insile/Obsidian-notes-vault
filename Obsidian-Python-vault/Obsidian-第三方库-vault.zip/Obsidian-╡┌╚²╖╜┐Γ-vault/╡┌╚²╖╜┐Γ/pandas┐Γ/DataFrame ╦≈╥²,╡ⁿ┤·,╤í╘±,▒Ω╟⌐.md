##### [[Series 索引,迭代,选择,标签]]
##### DataFrame 索引,迭代,选择,标签
- [[DataFrame.xs()]]  交叉索引
- [[DataFrame.set_index()]]  使用现有列设置索引
- [[DataFrame.query()]]  布尔查询
- [[DataFrame.insert()]]  插入列
- [[DataFrame.drop()]]  从行或列中删除指定的标签
