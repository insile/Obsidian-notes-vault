##### Series.cat
```python
Series.cat.categories
Series.cat.ordered
Series.cat.codes 
Series.cat.rename_categories(*args, **kwargs)
Series.cat.reorder_categories(*args, **kwargs)
Series.cat.add_categories(*args, **kwargs)
Series.cat.remove_categories(*args, **kwargs)
Series.cat.remove_unused_categories(*args, ...)
Series.cat.set_categories(*args, **kwargs)
Series.cat.as_ordered(*args, **kwargs)
Series.cat.as_unordered(*args, **kwargs)
```