##### Period 类
- 代表一段时间
- [[Period 创建]]
- Period 属性
- Period 方法