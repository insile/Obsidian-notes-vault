```python
ndarray.ndim 
	# 秩，轴的数量或维度的数量
	# 第0维是最高维
ndarray.shape 
	# 高维到低维显示数组元素个数，shape个数代表几维
ndarray.size 
	# 对象元素的个数，相当于n*m
ndarray.dtype 
	# 对象的元素类型
ndarray.itemsize 
	# 对象中每个元素的大小，以字节为单位
ndarray.all
	# 全真返回True
ndarray.any
	# 存在真返回True

ndarray.argmax
	# 最大值索引
ndarray.argmin
	# 最小值索引
ndarray.argsort
	# 排序索引
```