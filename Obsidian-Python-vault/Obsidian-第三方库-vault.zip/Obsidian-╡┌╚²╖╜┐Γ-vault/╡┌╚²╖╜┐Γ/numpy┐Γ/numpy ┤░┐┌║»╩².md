##### numpy 窗口函数
```python
np.bartlett(M)
np.blackman(M)
np.hamming(M)
np.hanning(M)
np.kaiser(M, beta)
```