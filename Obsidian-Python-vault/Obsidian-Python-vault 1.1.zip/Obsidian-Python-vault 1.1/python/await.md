- 在一个协程函数中运行其他协程函数
- 挂起协程的执行以等待一个 awaitable 对象。 只能在 coroutine function 内部使用。
- 如果一个对象可以在 await 语句中使用，那么它就是 可等待 对象
- asyncio 标准库
```python
import asyncio
import time

async def say_after(delay, what): # 子协程
    await asyncio.sleep(delay)
    print(what)

async def main(): # 主协程
    print(f"started at {time.strftime('%X')}")

	# 主协程挂起，等待子协程
    await say_after(1, 'hello') # 等待子协程
    await say_after(2, 'world') # 等待子协程

    print(f"finished at {time.strftime('%X')}")

asyncio.run(main())
# 事件循环处理主协程
```