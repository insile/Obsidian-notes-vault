- `oct( x )`
	- 将整数转换为八进制字符串
```python
# 将整数转换为八进制字符串
octal_str = oct(8)
print(octal_str)  # 输出：'0o10'

# 将整数转换为八进制字符串
octal_str = oct(10)
print(octal_str)  # 输出：'0o12'

# 将整数转换为八进制字符串
octal_str = oct(0b10)
print(octal_str)  # 输出：'0o2'
```