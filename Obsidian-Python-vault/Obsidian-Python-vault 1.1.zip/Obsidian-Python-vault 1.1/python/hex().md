- `hex( x )`
	- 将整数转换为十六进制字符串
```python
# 将整数转换为十六进制字符串
hex_str = hex(16)
print(hex_str)  # 输出：'0x10'

# 将整数转换为十六进制字符串
hex_str = hex(255)
print(hex_str)  # 输出：'0xff'

# 将整数转换为十六进制字符串
hex_str = hex(0o10)
print(hex_str)  # 输出：'0x8'
```