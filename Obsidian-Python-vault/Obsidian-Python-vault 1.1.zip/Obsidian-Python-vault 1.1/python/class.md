- [[类的定义与实例化|定义类]]
```python
# 最简单的类定义形式
'''
class ClassName:
	<statement-1>
	...
	<statement-N>
'''

# 简单的类
class Dog:
    name = "Candy"
dog = Dor()
print(dog.name)
```