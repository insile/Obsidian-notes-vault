解码：返回[[bytes类型]]对应的字符串
- bytes.decode([encoding="utf-8"][,errors="strict"])