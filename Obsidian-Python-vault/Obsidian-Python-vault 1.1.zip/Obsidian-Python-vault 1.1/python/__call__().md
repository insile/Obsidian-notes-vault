```python
# 通过实现 __call__() 方法，可以让自定义的类的实例表现得像可调用函数一样

class Adder:
    def __init__(self, base):
        self.base = base

    def __call__(self, x):
        return self.base + x

# 创建一个可调用对象
add_five = Adder(base=5)

# 调用可调用对象
result = add_five(10)
print(result)  # 输出：15

```

