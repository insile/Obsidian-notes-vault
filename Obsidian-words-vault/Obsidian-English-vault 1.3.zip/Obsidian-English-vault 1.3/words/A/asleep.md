# 词义
- 英：/əˈsliːp/； 美：/əˈsliːp/
- #adj 睡着的；睡着
- #adv 死去；进入静止状态；睡着地；麻木不仁地
# 例句
- We " stop " work sometimes at 5 pm , but then we spend the night wrestling with solutions to work problems , talking about our work over dinner , and falling asleep thinking about how much work we 'll do tomorrow .
	- 我们有时在下午5点“停止”工作，但是之后我们会用一晚上的时间来设法解决工作的问题，在吃晚饭的时侯谈论工作，睡着的时候还在思考着明天我们会有多少工作要做。
- " Nobody . I do it . " " Really-at night , when you 're asleep ? "
	- "没人。我自己做的。"真的是在晚上,当你睡着的时候?"
- She was still half asleep when she arrived at work .
	- 她到了上班地点时仍然睡眼惺忪。
