# 词义
- 英：/ˈækjupʌŋktʃə(r)/； 美：/ˈækjupʌŋktʃər/
- #n 针灸；针刺疗法
- #v 对…施行针刺疗法
# 例句
- Therapies like acupuncture do work and many people have been healed by them .
	- 针灸等疗法确实有效，已经治愈了很多人。
- Acupuncture was practised in China as long ago as the third millennium BC
	- 中国早在公元前3,000年就已开始采用针灸疗法。
- All of those who received the true acupuncture experienced pain relief .
	- 所有接受了针刺治疗的人都感到疼痛减轻了。
