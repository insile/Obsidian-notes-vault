# 词义
- 英：/əˈbaʊnd/； 美：/əˈbaʊnd/
- #vi 大量；大量存在；有许多
# 例句
- Mistakes abound on every page .
	- 每页上都有大量错误。
- Opportunities abound both in science and other areas for fine careers .
	- 无论从事科学事业或在其他领域工作，都有取得成就的大量机会。
- Stories about his travels abound .
	- 有关他游历的故事多得很。
# 形态
- #word_third abounds
- #word_ing abounding
- #word_done abounded
- #word_past abounded
