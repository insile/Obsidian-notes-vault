# 词义
- 英：/ˈærəɡənt/； 美：/ˈærəɡənt/
- #adj 傲慢的；自大的
# 例句
- He 's an arrogant little swine !
	- 他是个傲慢的小讨厌鬼！
- I disliked the arrogant cast to her mouth .
	- 我不喜欢她傲慢的口吻。
- Arrogant pig !
	- 傲慢的家伙！
