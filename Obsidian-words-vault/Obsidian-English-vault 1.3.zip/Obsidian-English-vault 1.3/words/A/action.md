# 词义
- 英：/ˈækʃn/； 美：/ˈækʃn/
- #n 行动；（身体部位的）动作，功能；作用；行为；诉讼；起诉；战斗；情节；机械装置，活动部件；所做之事；激动人心的事
- #vt 务必做，确保处理(某事)
# 例句
- We need more time to see how things develop before we take action .
	- 我们采取行动以前需要有更多时间观察情况的发展。
- What is the best course of action in the circumstances ?
	- 在这种情况下最佳行动方针是什么？
- Each of us must take responsibility for our own actions .
	- 我们每个人都必须对自己的行为负责。
# 形态
- #word_third actions
- #word_ing actioning
- #word_pl actions
- #word_past actioned
