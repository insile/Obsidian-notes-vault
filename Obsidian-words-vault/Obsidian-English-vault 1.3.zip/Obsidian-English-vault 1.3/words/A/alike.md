# 词义
- 英：/əˈlaɪk/； 美：/əˈlaɪk/
- #adv 同样地；两者都；很相似地；十分相像地
- #adj 相像；十分相似
# 例句
- Ellen sat in her nakedness close by her , and smiled on all alike , and just such a smile Natasha bestowed on Boris .
	- 袒胸露体的海伦坐在她身旁，同样地也对大家微露笑容，娜塔莎同样地也对鲍里斯嫣然一笑。
- Man and beast alike fear my
	- 人和兽都是同样地害怕我的
- It 's a book for young and old alike .
	- 这本书老少咸宜。
