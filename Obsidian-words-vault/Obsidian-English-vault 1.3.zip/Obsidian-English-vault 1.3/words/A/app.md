# 词义
- 英：/æp/； 美：/æp/
- #n (计算机)应用程序
# 例句
- PayPal , for instance , is testing an app that lets you use your mobile phone to pay on the fly at local merchants — without surrendering any card information to them .
	- 例如,PayPal正在测试一款应用程序,它可以让你使用手机在本地商户进行即时支付,而不必提供任何银行卡信息。
- Opening the App near a supermarket provides immediate information on special offers .
	- 在超市附近打开这个应用程序，它可以立即提供特价信息。
- Having to install a different app for each smart appliance in your home is annoying .
	- 费力去给任何一个智能设备安装不同的应用软件都很让人头大。
