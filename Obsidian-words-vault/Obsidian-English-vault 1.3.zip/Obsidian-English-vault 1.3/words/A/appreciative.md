# 词义
- 英：/əˈpriːʃətɪv/； 美：/əˈpriːʃətɪv/
- #adj 感谢的；欣赏的；感激的；赏识的
# 例句
- Come with appreciative mood when people emblazon when this hero , he is quiet however ground demit world and go .
	- 当人们以感激的心情来颂扬这位功臣时，他却平静地辞世而去。
- Appreciative Europeans of the time spoke of " a sense of hope and confidence " these American planners brought – of " restored courage and reawakened energy " in the Old World .
	- 当时，心怀感激的欧洲人谈到这些美国人带来的使旧大陆感到“恢复了勇气和重振起精力”的“希望与信心”。
- The company was very appreciative of my efforts .
	- 公司对我的努力十分赞赏。
