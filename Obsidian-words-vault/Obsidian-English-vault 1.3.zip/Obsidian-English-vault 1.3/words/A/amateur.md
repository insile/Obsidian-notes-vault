# 词义
- 英：/ˈæmətə(r)/； 美：/ˈæmətər/
- #adj 业余；业余爱好的
- #n 业余爱好者；外行；业余运动员；生手
# 例句
- After he won the amateur championship he turned professional .
	- 他获得业余赛冠军后就转为职业运动员了。
- He has that je ne sais quoi that distinguishes a professional from an amateur .
	- 他有那种难以言表的特质，体现出他是专业而非业余的。
- This work was done by a bunch of amateurs !
	- 这项工作是一帮外行干的！
# 形态
- #word_pl amateurs
