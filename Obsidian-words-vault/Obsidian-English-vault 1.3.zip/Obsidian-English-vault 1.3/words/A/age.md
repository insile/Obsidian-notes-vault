# 词义
- 英：/eɪdʒ/； 美：/eɪdʒ/
- #n 年龄；(历史上的)时代，时期；老年；年龄段；期；很长时间
- #v (使)成熟，变陈；变老；使变老；使苍老；使显老
# 例句
- The children are close to each other in age .
	- 这些儿童彼此的年龄很接近。
- Last year , he was ranked second in his age group .
	- 他去年在他的年龄段排名第二。
- They were both only 20 years of age .
	- 他们两人都只有20岁。
# 形态
- #word_third ages
- #word_ing aging
- #word_done aged
- #word_pl ages
- #word_past aged
