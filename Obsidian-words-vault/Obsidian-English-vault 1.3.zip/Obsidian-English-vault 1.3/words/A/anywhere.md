# 词义
- 英：/ˈeniweə(r)/； 美：/ˈeniwer/
- #adv （用于描述所谈论的某个地方的词语前）…地方；任何地方，到处；（用于疑问句和条件从句）某个地方，哪里；（用于否定句）哪儿，到处；（用于强调）根本，一点儿，将近，几乎；（指某个范围内）任何一点上
- #pron 任何地方
# 例句
- " They didn 't work anywhere and all the time --- they were better able to manage their work , " Moen said .
	- “员工并没有在任何地方，任何时间都在工作一他们能更好地管理工作，”摩恩说。
- Through her website Loe emphasizes that " anybody can do this anywhere . "
	- 通过她的网站,Loe强调"任何人都可以在任何地方做到这一点"
- We 're a long way from anywhere here .
	- 我们这里离任何一个地方都很远。
