# 词义
- 英：/ɑːtʃ/； 美：/ɑːrtʃ/
- #n 拱，拱门，拱形结构；.拱形，拱形物；牙弓，齿弓，足背，足弓
- #v (使)成弓形；用拱覆盖，用拱连接，横跨
- #adj 为首的，主要的；调皮的，淘气的；傲慢无礼的
# 例句
- That arch has a span of 70 metres .
	- 那个拱的跨度为70米。
- Study of the Type and Stability of Cable - Arch Structure
	- 索拱结构体型及稳定性研究
- Tall trees arched over the path .
	- 大树呈拱形遮阴了小道。
# 形态
- #word_third arches
- #word_ing arching
- #word_done arched
- #word_pl arches
- #word_past arched
