# 词义
- 英：/əˈlaɪv/； 美：/əˈlaɪv/
- #adj 活着的；活着；在世；充满；有活力；意识到；有生气；继续存在；情绪饱满；激动兴奋
# 例句
- She and Simon 's father had not given up hope that he might be alive
	- 她和西蒙的父亲还没有放弃他或许还活着的希望。
- On paper , I am the healthiest man alive , yet I feel permanently unwell .
	- 理论上，我是活着的最健康的人，但是我总感觉不舒服。
- There is little hope that they will be found alive .
	- 活着找到他们的希望很渺茫。
