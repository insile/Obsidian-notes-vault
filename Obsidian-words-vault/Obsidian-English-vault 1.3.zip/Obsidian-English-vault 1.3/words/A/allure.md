# 词义
- 英：/əˈlʊə(r)/； 美：/əˈlʊr/
- #v 诱惑；引诱；吸引人；勾引诱人
- #n 吸引力；诱惑力；引诱力
# 例句
- Amid all the changes , Antarctica maintains its allure .
	- 在所有这些变化中，南极洲保持着其诱惑力。
- The depressed economy has increased the allure of the jobs offered by the military .
	- 经济的萧条使得由军队提供就业的诱惑力增大了。
- It 's a game that has really lost its allure .
	- 这是一项的确已失去了魅力的游戏。
# 形态
- #word_third allures
- #word_ing alluring
- #word_done allured
- #word_past allured
