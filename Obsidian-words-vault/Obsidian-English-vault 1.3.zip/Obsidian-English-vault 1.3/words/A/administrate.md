# 词义
- #v 管理；管理，支配
# 例句
- Administrate the staff to ensure offering high quality education to the students ;
	- 管理中心全体员工，以确保向学生提供高质量的教育；
- Academic power is a power to administrate the teaching and scientific research of university .
	- 学术权力是管理高等学校教学和科研的力量。
- Structure and application of computer network of the administrating system for scientific research funds
	- 科研经费的计算机网络化管理系统结构与应用
# 形态
- #word_third administrates
- #word_done administrated
- #word_ing administrating
- #word_past administrated
