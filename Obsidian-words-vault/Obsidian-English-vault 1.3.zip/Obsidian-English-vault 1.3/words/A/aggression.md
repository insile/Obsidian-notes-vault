# 词义
- 英：/əˈɡreʃn/； 美：/əˈɡreʃn/
- #n 侵略；侵犯；攻击性；挑衅；好斗情绪
# 例句
- The research shows that computer games may cause aggression .
	- 研究显示，电脑游戏可能引起好斗情绪。
- Take a long walk to release all that pent-up aggression .
	- 出去多散散步会消除郁积的好斗情绪。
- Sport became the perfect outlet for his aggression .
	- 运动成为他攻击性心理的最佳出路。
# 形态
- #word_pl aggressions
