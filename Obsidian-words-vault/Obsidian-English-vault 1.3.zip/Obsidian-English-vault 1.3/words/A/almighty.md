# 词义
- 英：/ɔːlˈmaɪti/； 美：/ɔːlˈmaɪti/
- #adj 全能的；(表示惊奇或愤怒)全能的，有无限权力的；极大的；十分严重的
- #n 全能者（指上帝）
# 例句
- Almighty god , have mercy on us .
	- 全能的主，请垂怜我们。
- How could this world function without a Almighty god ?
	- 没有全能的上帝这个世界怎么能运转呢？
- Let us now confess our sins to Almighty God .
	- 现在让我们向上帝忏悔我们的罪恶。
