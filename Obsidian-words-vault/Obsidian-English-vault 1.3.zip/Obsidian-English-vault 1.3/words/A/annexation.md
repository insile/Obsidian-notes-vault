# 词义
- #n 兼并；附加（物）；归并；并吞
# 例句
- I regard the question of annexation as belonging exclusively to the United States and Texas .
	- 我认为合并的问题，完全属于德克萨斯和美国之间的事。
- Behavior Analysis on Enterprise Horizontal Annexation Based on Decision Advantage
	- 基于决策优势的企业横向兼并行为分析
- Analysis of Barrier Factors of State Enterprise Annexation
	- 国有企业兼并的障碍因素分析
# 形态
- #word_pl annexations
