# 词义
- 英：/əm/； 美：/əm/
- #v 是
- #abbr 上午(ante meridiem)；调幅（Amplitude Modulation）
# 例句
- I really and truly am in love this time .
	- 我这一次确确实实是恋爱了。
- I am using the word ' education ' in the narrower sense .
	- 我说的是较狭义的“教育”。
- If you need anything , I am at your service .
	- 您要是需要什么，请尽管吩咐。
