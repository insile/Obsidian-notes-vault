# 词义
- 英：/əˈkjuːz/； 美：/əˈkjuːz/
- #vt 指责；控告；谴责；控诉
# 例句
- I hate it when people accuse us of that
	- 我讨厌别人就那件事指责我们。
- I don 't think it 's fair to accuse me of having an attitude problem .
	- 我觉得指责我有态度问题有失公允。
- They accused the government of a surrender to business interests .
	- 他们指责政府唯工商界的利益是从。
# 形态
- #word_third accuses
- #word_ing accusing
- #word_done accused
- #word_past accused
