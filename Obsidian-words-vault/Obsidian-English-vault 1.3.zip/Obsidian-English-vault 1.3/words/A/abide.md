# 词义
- 英：/əˈbaɪd/； 美：/əˈbaɪd/
- #v 遵守；(abide by)接受，遵照（规则，决定，劝告）；逗留，停留
# 例句
- You 'll have to **abide by** the rules of the club .
	- 你必须遵守俱乐部的规定。
- They have got to **abide by** the rules .
	- 他们必须遵守规则。
- May joy and peace **abide in** us all .
	- 愿我们大家都欢乐平安。
# 形态
- #word_third abides
- #word_ing abiding
- #word_done abided
- #word_past abided
