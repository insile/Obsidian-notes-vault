# 词义
- 英：/ˈærəɡəns/； 美：/ˈærəɡəns/
- #n 傲慢；自大
# 例句
- His arrogance knew no limits .
	- 他极其傲慢。
- It is easy to misconstrue confidence as arrogance .
	- 很容易将信心误解为傲慢。
- His confidence was misread as arrogance .
	- 他的信心被误解为傲慢。
