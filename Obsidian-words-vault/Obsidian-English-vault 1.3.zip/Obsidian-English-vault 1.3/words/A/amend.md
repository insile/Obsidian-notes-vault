# 词义
- 英：/əˈmend/； 美：/əˈmend/
- #vt 修订(法律文件、声明等)；修正
# 例句
- The Problems in City Tourism Image and the System to Amend
	- 城市旅游形象问题及系统修正研究
- Research on Using Standard Land Price Category to Amend Comprehensive Valuation
	- 应用基准地价分类修正综合法估价的研究
- He asked to see the amended version .
	- 他要求看修订本。
# 形态
- #word_third amends
- #word_ing amending
- #word_done amended
- #word_past amended
