# 词义
- 英：/əˈsend/； 美：/əˈsend/
- #v 上升；升高；登高
# 例句
- And a spiral tower provides different views at every step when visitors ascend the tower .
	- 螺旋式的观景塔让参观者在上升的每一个点上都能看到不同的景致。
- Discussion on the Damage Reason and Improving measurement of the Flash Furnace 's Ascend Flue Roof
	- 闪速炉上升烟道顶损坏原因分析及改进措施探讨
- The air became colder as we ascended .
	- 随着我们往上攀登，空气就寒冷起来。
# 形态
- #word_third ascends
- #word_ing ascending
- #word_done ascended
- #word_past ascended
