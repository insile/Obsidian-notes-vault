# 词义
- 英：/əˈreɪ/； 美：/əˈreɪ/
- #n 阵列；数组；大量；大堆；大群
- #vt 排列；配置(兵力)；布置
# 例句
- I was confronted with an array of knobs , levers , and switches .
	- 我面对的是一大堆旋钮、控制杆和开关。
- Such failures can be caused by an array of problems .
	- 这种失败可以有一大堆的问题引起。
- Jars of all shapes and sizes were arrayed on the shelves .
	- 在搁架上整齐地排列着大大小小各式各样的罐子。
# 形态
- #word_third arrays
- #word_ing arraying
- #word_done arrayed
- #word_pl arrays
- #word_past arrayed
