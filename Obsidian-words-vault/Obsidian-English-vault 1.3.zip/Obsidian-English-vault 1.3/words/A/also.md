# 词义
- 英：/ˈɔːlsəʊ/； 美：/ˈɔːlsoʊ/
- #adv 而且；此外；同样；也
- #conj 同“also beautiful”
# 例句
- She was not only intelligent but also very musical .
	- 她不仅聪明，而且极具音乐天分。
- He not only read the book , but also remembered what he had read .
	- 他不但读了这本书，而且记得所读的内容。
- Prevention also plays a central role in traditional medicine .
	- 预防在传统医学中也起着主导作用。
