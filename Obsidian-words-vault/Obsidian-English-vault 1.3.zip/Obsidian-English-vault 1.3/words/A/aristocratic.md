# 词义
- 英：/ˌærɪstəˈkrætɪk/； 美：/əˌrɪstəˈkrætɪk/
- #adj 贵族的
# 例句
- In England , where architecture was increasingly seen as an aristocratic pursuit , noblemen often applied what they learned from the villas of Palladio in the Veneto and the evocative ruins of Rome to their own country houses and gardens .
	- 在英国，建筑越来越被视为一种贵族的追求，威尼托的帕拉迪奥别墅以及罗马那些唤起人们回忆的遗迹，贵族们往往将他们从这两者中学到的东西应用到自己的乡间别墅和花园里。
- This thesis investigates and analyzes systematically the evolution of aristocratic forms in Chinese history .
	- 本文对中国传统社会里贵族的历史形态的沿革进行了系统的梳理。
- Nabokov was the scion of an aristocratic family .
	- 纳博科夫是一个贵族家庭的阔少。
