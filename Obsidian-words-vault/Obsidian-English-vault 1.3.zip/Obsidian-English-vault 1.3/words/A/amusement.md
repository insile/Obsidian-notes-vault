# 词义
- 英：/əˈmjuːzmənt/； 美：/əˈmjuːzmənt/
- #n 娱乐；游戏；娱乐活动；可笑；愉悦；消遣活动
# 例句
- Amusement gleamed in his eyes .
	- 他眼睛里流露出愉悦的神情。
- Her eyes twinkled with amusement .
	- 她的眼睛闪耀着愉悦的光芒。
- His expression changed from surprise to one of amusement .
	- 他的神情由惊变喜。
# 形态
- #word_pl amusements
