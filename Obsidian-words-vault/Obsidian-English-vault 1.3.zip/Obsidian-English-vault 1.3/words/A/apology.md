# 词义
- 英：/əˈpɒlədʒi/； 美：/əˈpɑːlədʒi/
- #n 道歉；(因不能赴会或提前离会的)致歉；谢罪
# 例句
- Getting an apology from him was like getting blood from a stone .
	- 让他道歉几乎是不可能的。
- No explanation was offered , still less an apology .
	- 连个解释都不给，就更不用说道歉了。
- She made her apologies and left early .
	- 她致歉后就提前离开了。
# 形态
- #word_pl apologies
