# 词义
- 英：/əˈpendɪks/； 美：/əˈpendɪks/
- #n (书、文件的)附录；阑尾
# 例句
- Full details are given in Appendix 3 .
	- 详情见附录3。
- For details , see the appendix .
	- 详见附录。
- He had to have his appendix out .
	- 他不得不切除了阑尾。
# 形态
- #word_pl appendixes
