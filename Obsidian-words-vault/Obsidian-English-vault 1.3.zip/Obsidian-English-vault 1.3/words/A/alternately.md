# 词义
- #adv 交替地；轮流地；间隔地
# 例句
- He felt alternately hot and cold .
	- 他感到忽冷忽热。
- The two methods can be used alternately .
	- 两种方法可交互使用。
- Dances and recitations of poems are performed alternately .
	- 舞蹈、诗歌朗诵穿插表演。
