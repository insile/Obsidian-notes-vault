# 词义
- 英：/əˈpɔːl/； 美：/əˈpɔːl/
- #v 骇人听闻；使胆寒；使惊骇
# 例句
- ' It 's appalling . ' — ' It is . I agree . '
	- “真是骇人听闻。”——“嗯，我同意。”
- Nothing can extenuate such appalling behaviour .
	- 这种骇人听闻的行径罪无可恕。
- It appalled me that they could simply ignore the problem .
	- 他们竟然对问题置之不理，令我非常诧异。
# 形态
- #word_third appalls
- #word_done appalled
- #word_ing appalling
- #word_past appalled
