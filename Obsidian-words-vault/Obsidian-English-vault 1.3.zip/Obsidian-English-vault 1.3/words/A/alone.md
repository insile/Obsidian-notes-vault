# 词义
- 英：/əˈləʊn/； 美：/əˈloʊn/
- #adj #adv 单独；独自；仅仅，单，只；唯一，只有；孤独；单独地；寂寞；独力；孤苦伶仃；无依无靠
# 例句
- ATM , however , cannot efficiently distribute these services alone .
	- 然而，ATM不能单独地高效地分配这些服务。
- It was the first time since his return that they had talked alone and of their love .
	- 这是他回家以后他们两人头一回单独地倾吐爱慕之情。
- I quite understand that you need some time alone .
	- 我很理解你需要独自静一会。
# 形态
- #word_est aloneest
- #word_er aloneer
