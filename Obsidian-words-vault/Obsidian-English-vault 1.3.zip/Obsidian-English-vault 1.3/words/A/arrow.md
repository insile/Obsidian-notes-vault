# 词义
- 英：/ˈærəʊ/； 美：/ˈæroʊ/
- #n 箭头；箭；箭号
# 例句
- The arrow flew straight and true to the target .
	- 箭不偏不斜地朝靶子飞去。
- His arrow thudded into the target .
	- 他的箭噗的一声射中靶子。
- A series of yellow arrows pointed the way to reception .
	- 连续的黄色箭头标出往接待站的路。
# 形态
- #word_pl arrows
