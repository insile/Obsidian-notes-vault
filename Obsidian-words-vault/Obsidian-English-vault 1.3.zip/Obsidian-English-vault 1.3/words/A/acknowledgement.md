# 词义
- 英：/əkˈnɒlɪdʒmənt/； 美：/əkˈnɑːlɪdʒmənt/
- #n 确认；(对事实、现实、存在的)承认；感谢；致谢，鸣谢；收件复函；谢礼
# 例句
- Using Current Spectrum Estimation Method to Implement High Confidence Level Acknowledgement of Missile System Simulation Models
	- 用现代谱估计法实现导弹系统仿真模型的高可信度确认
- Send out an acknowledgement with the result \/ output of the process .
	- 发送带有业务结果\/输出的确认通知。
- This report is an acknowledgement of the size of the problem .
	- 这个报告承认了问题的严重性。
# 形态
- #word_pl acknowledgements
