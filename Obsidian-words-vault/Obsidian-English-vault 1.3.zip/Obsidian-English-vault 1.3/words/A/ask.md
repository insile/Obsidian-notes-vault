# 词义
- 英：/ɑːsk/； 美：/æsk/
- #v 问；要求；请；询问；请求；征求；期望；要价；恳求(给予)；请求允许
# 例句
- There 's another thing I 'd like to ask you .
	- 还有一件事我想问你。
- May I ask why you took that decision ?
	- 我可否问一下你为什么要作出那样的决定？
- She asked her students to get into groups of four .
	- 她让学生每四人分为一小组。
# 形态
- #word_third asks
- #word_ing asking
- #word_done asked
- #word_past asked
