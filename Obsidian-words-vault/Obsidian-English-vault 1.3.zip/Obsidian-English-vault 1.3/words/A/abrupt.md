# 词义
- 英：/əˈbrʌpt/； 美：/əˈbrʌpt/
- #adj 突然的；(言语、行为)粗鲁的，莽撞的，唐突的；意外的；生硬的
# 例句
- This abrupt removal caused a serious imbalance in the system that was coordinating the energy interaction within the Vega system .
	- 这个突然的移除导致系统内一系列的不平衡，这影响了织女星系统内的能量互动。
- This driver utilizes inductors to resonate with the equivalent intrinsic capacitance of the PDP to avoid the abrupt charging \/ discharging operation .
	- 该电路利用PDP的等效固有电容和外加电感器产生谐振，以防止突然的充放电。
- These policies have sent the construction industry into an abrupt nosedive .
	- 这些政策使得建筑业的形势急转直下。
