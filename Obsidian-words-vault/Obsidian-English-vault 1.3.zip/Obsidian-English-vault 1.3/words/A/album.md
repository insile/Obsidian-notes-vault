# 词义
- 英：/ˈælbəm/； 美：/ˈælbəm/
- #n 专辑；相册；(唱片或盒式磁带等上的)音乐专辑；影集；歌曲专辑；集邮簿；歌集唱片；集物簿册
# 例句
- The new album went straight to number one .
	- 这张新的歌曲专辑一举登上了周销售量榜首。
- The band did some great stuff on their first album .
	- 这支乐队首张专辑有几支很棒的曲子。
- The band 's new album takes up where their last one left off .
	- 这个乐队的新唱片集是接上一集的乐曲录制的。
# 形态
- #word_pl albums
