# 词义
- #n 上升；优越，权势，主权
# 例句
- A Summery of the International Symposium on the Social Ascendance in Modern Chinese Villages
	- 近代中国乡村社会权势国际学术研讨会综述
- China 's ascendance to prominence must begin with our generation !
	- 中华民族的崛起必须从我们这一代开始！
- As a qualitative ascendance , the economic development is marked as the final goal of Old Age Security .
	- 作为经济增长质的提高，经济发展才是老年保障的终极目标。
