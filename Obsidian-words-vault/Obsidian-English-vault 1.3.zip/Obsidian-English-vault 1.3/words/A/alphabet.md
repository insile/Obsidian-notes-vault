# 词义
- 英：/ˈælfəbet/； 美：/ˈælfəbet/
- #n 字母表；(一种语言的)全部字母
# 例句
- The alphabet might be more rational if all the vowels came first
	- 如果把所有的元音列在前面，字母表可能会更为合理一些。
- The modern Russian alphabet has 31 letters
	- 现代俄语字母表有31个字母。
- By two and a half he knew the alphabet .
	- 两岁半时他已认识全部字母。
# 形态
- #word_pl alphabets
