# 词义
- 英：/ˌælfəˈbetɪk/； 美：/ˌælfəˈbetɪk/
- #adj (属于)字母的
# 例句
- With alphabetic intent , this branching coral near the Turks and Caicos Islands in the Caribbean Sea seems to be spelling out a message .
	- 随着字母的意图，这一分支的珊瑚靠近特克斯和凯科斯群岛，加勒比海似乎拼写了一条消息。
- The check of effective alphabetic to ensure the correctness of input alphabetic .
	- 字母有效性检查，以保证输入字母的正确。
- It is more widely in use than alphabetic writing systems ．
	- 它比字母书写系统使用得更广泛。
