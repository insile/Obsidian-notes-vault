# 词义
- 英：/əˈpɪərəns/； 美：/əˈpɪrəns/
- #n 出现；外观；外表；外貌；出版；公开露面；(尤指突然的)抵达，到来；起源；首次使用
# 例句
- She had never been greatly concerned about her appearance .
	- 她从来不怎么注重外貌。
- She sets great store by her appearance .
	- 她十分看重自己的外貌。
- The President made a personal appearance at the event .
	- 总统亲临现场。
# 形态
- #word_pl appearances
