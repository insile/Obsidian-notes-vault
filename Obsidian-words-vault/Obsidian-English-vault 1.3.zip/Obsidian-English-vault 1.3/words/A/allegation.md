# 词义
- 英：/ˌæləˈɡeɪʃn/； 美：/ˌæləˈɡeɪʃn/
- #n 指控；(无证据的)说法
# 例句
- The allegation has caused one lecturer 's career to bite the dust .
	- 这项指控断送了一名讲师的前程。
- The US state department said the allegation was " simply untrue . "
	- 美国国务院说，这个指控“根本不真实”。
- The allegations are likely to damage his political career .
	- 这些指控有可能伤及他的政治生涯。
# 形态
- #word_pl allegations
