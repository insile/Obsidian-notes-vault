# 词义
- 英：/ˈælaɪ , əˈlaɪ/； 美：/ˈælaɪ , əˈlaɪ/
- #n 盟友；(第二次世界大战中的)同盟国；(尤指从政者的)支持者；(第一次世界大战中的)协约国
- #v 与…结盟
# 例句
- The United States is a close ally of South Korea .
	- 美国是韩国的亲密盟友。
- She will regret losing a close political ally .
	- 她将为失去一个亲密的政治盟友而懊悔。
- The decision left the country isolated from its allies .
	- 这个决定使这个国家在盟国中受到孤立。
# 形态
- #word_third allies
- #word_ing allying
- #word_done allied
- #word_pl allies
- #word_past allied
