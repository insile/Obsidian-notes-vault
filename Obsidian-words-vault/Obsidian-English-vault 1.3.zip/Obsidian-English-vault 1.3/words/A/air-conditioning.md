# 词义
- 英：/ˈeə kəndɪʃnɪŋ/； 美：/ˈer kəndɪʃnɪŋ/
- #n 空调设备；用空气调节设备调节空气
# 例句
- Air-conditioning is an absolute necessity in this climate .
	- 这样的气候绝对需要有空调。
- The air-conditioning screeched all the time
	- 空调一直在发出刺耳的声音。
- The car includes air-conditioning among its options .
	- 这辆汽车的附件中包括空调设备。
# 形态
- #word_proto air-condition
