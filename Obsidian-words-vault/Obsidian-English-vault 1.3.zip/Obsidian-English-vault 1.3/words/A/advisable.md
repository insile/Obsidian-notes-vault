# 词义
- 英：/ədˈvaɪzəbl/； 美：/ədˈvaɪzəbl/
- #adj 可取；明智的；明智
# 例句
- Early booking is advisable .
	- 早订票是明智的。
- It will be advisable for you to drop an acquaintance such as John ; he is not a good companion for you .
	- 你和约翰那样的人断绝往来是明智的，对于你他并不是一个好伙伴。
- It is advisable to book early .
	- 宜提早订票。
