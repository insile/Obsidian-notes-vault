# 词义
- 英：/ˈælɡərɪðəm/； 美：/ˈælɡərɪðəm/
- #n 算法；计算程序
# 例句
- " An ultimate face recognition algorithm should perform with billions of people in a dataset , " the researchers wrote .
	- “一个终极的人脸识别算法应该可以识别数据集中数以十亿计的人，”研究人员写道。
- The paper then certifies this algorithm by infrared image processing .
	- 并且文中使用红外图像对这个算法进行了验证。
- Many robots are equipped with high-tech sensors and complex learning algorithms to avoid injuring humans as they work side by side .
	- 许多机器人配备有高科技传感器和复杂的学习算法，以避免伤害到与其并肩工作的人类。
# 形态
- #word_pl algorithms
