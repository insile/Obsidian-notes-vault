# 词义
- 英：/ˈeniwʌn/； 美：/ˈeniwʌn/
- #pron 重要人物；随便哪个人；(用于否定句、疑问句，也用于if或whether之后，或紧接prevent、forbid、avoid等动词，代替someone)任何人
# 例句
- I would prefer it if you didn 't tell anyone .
	- 我希望你别告诉任何人。
- I don 't want anyone getting the wrong idea .
	- 我不希望任何人有所误会。
- Keep down ! You mustn 't let anyone see you .
	- 蹲下！一定不要让人看见你。
