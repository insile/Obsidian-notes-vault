# 词义
- 英：/ˌærɪˈstɒkrəsi/； 美：/ˌærɪˈstɑːkrəsi/
- #n (某些国家的)贵族
# 例句
- She married into the aristocracy .
	- 她因为婚姻关系而跻身贵族。
- A century ago the aristocracy were truly lords of the earth .
	- 一个世纪之前，贵族阶层是绝对的统治者。
- People said the aristocracy was effete .
	- 人们说贵族阶级已是日薄西山了。
# 形态
- #word_pl aristocracies
