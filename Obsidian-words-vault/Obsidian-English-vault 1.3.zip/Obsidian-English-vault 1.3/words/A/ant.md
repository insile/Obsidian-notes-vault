# 词义
- 英：/ænt/； 美：/ænt/
- #n 蚂蚁
# 例句
- His industry and persistence suggest that he was an ant in a previous incarnation .
	- 他的勤奋与坚持表明他前世是只蚂蚁。
- The ant is a social insect .
	- 蚂蚁是一种群居昆虫。
- An army of ants marched across the path .
	- 一大群蚂蚁浩浩荡荡地穿过小径。
# 形态
- #word_pl ants
