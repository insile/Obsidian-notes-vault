# 词义
- 英：/ˈɑːmə/； 美：/ˈɑrmər/
- #n 装甲；盔甲
- #v 为…装甲
# 例句
- Energy projectors fired and peeled off the ships ' armor in a flash .
	- 能量投射器开火然后在一阵闪光后剥离了飞船的装甲。
- A Discussion on Key Technique for Active Armor Protection System
	- 主动装甲防护系统关键技术探讨
- Love songs trick us into believing in knights in shining armor .
	- 情歌哄骗我们去相信有勇救美人的英雄。
# 形态
- #word_third armors
- #word_done armored
- #word_ing armoring
- #word_past armored
