# 词义
- 英：/iːsˈθɛtɪks/； 美：/ɛˈsθɛtɪks/
- #n (审)美学
# 例句
- These concepts belong to the field of aesthetics .
	- 这些概念属于美学范畴。
- A study in the British Journal of Aesthetics suggests that the exposure effect doesn 't work the same way on everything , and points to a different conclusion about how canons are formed .
	- 《英国美学杂志》上的一项研究表明,曝光效应对所有事物的作用并不相同,并且对名作目录的形成方式得出了不同的结论。
- The benefits of conservation are both financial and aesthetic .
	- 保护自然环境在经济上和美化环境上都有好处。
# 形态
- #word_proto aesthetic
