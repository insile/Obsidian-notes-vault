# 词义
- 英：/ˈɑːtɪfækt/； 美：/ˈɑːrtɪfækt/
- #n 人工制品；(尤指具有历史或文化价值的)手工制品，手工艺品
# 例句
- The kilogram is the only unit of measurement still based on a man-made artifact .
	- 千克是目前唯一一个以人工制品为参照标准的计量单位。
- It is older than any human artifact ,
	- 它比任何一个人工制品都要古老，
- Research on CT Image Metal Artifact Reduction Using Optimal Hybrid Methods
	- 优化CT图像金属伪影消除算法研究
