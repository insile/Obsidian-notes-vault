# 词义
- 英：/əˈskraɪb/； 美：/əˈskraɪb/
- #v 把…归咎于；归因；认为…具有；认为…是…所说(或所为)；认为是…的特点
# 例句
- Part 05 ...... ascribe to He ascribes his success to skill and hard work .
	- 第五部分……v.将……归因于……他把他的成功归因于熟练和辛苦地工作。
- To what do you ascribe the phenomenal success of your new album , lloyd ?
	- 劳埃德，你把你新的歌曲集的巨大成功归因于什么？
- We do not ascribe a superior wisdom to government or the state .
	- 我们并不认为政府或是国家有超凡的智慧。
# 形态
- #word_third ascribes
- #word_ing ascribing
- #word_done ascribed
- #word_past ascribed
