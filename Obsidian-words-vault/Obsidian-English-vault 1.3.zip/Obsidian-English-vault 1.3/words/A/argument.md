# 词义
- 英：/ˈɑːɡjumənt/； 美：/ˈɑːrɡjumənt/
- #n 论点；争论；论据；理由；辩论；争吵；争辩
# 例句
- The same argument does not hold good in every case .
	- 同样的论点并非在所有的情况下都正确。
- His argument was that public spending must be reduced .
	- 他的论点是公共开支必须减缩。
- No one can get the better of her in an argument .
	- 辩论起来没人能辩过她。
# 形态
- #word_pl arguments
