# 词义
- 英：/ˌæntibaɪˈɒtɪk/； 美：/ˌæntibaɪˈɑːtɪk/
- #n 抗生素(如青霉素)；抗菌素
- #adj 抗生素的；抗菌的；抗菌作用的；抗生的
# 例句
- They expect the antibiotic products to be exported to Southeast Asia and Africa
	- 他们希望向东南亚和非洲出口抗生素产品。
- Our doctor diagnosed a throat infection and prescribed antibiotic and junior aspirin
	- 我们的医生诊断是喉部感染，并且开了一些抗生素和小剂量阿司匹林。
- The doctor put me on antibiotics .
	- 医生要我服用抗生素。
# 形态
- #word_pl antibiotics
