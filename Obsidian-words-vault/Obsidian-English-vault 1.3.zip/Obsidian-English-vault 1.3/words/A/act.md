# 词义
- 英：/ækt/； 美：/ækt/
- #n 行为，行动，所为；(议会通过的)法案，法令；表演，假装；一幕；表演者；一段表演
- #v 行为；行动；充当；表演，假装；扮演；举止；做事；（对…）有作用，有影响
- #abbr 同“Association of Classroom Teachers”
# 例句
- It seems like an act of monumental folly .
	- 这似乎是一种非常愚蠢的行为。
- Language interpretation is the whole point of the act of reading
	- 阅读行为中关键在于对语言的理解。
- She acts well but she hasn 't got star quality .
	- 她演得不错，但缺少成为一个明星的素质。
# 形态
- #word_third acts
- #word_ing acting
- #word_done acted
- #word_pl acts
- #word_past acted
