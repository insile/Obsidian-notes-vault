# 词义
- 英：/əˈkaʊntənt/； 美：/əˈkaʊntənt/
- #n 会计；会计师
# 例句
- He 's not a bad chap — quite human for an accountant
	- 这个家伙人不坏——就会计来说已经很有人情味了。
- I won 't know how successful it is until an accountant has gone over the books .
	- 要等到会计核查完账簿，我才会知道盈利状况如何。
- She has been an accountant all her working life .
	- 她在整个职业生涯中一直是会计师。
# 形态
- #word_pl accountants
