# 词义
- 英：/əˈlɒŋ/； 美：/əˈlɔːŋ/
- #prep 沿着；顺着；靠着…边；沿着…的某处(或旁边)
- #adv (与某人)一道，一起；越来越(好)；向前
# 例句
- You 'll find his office just along the corridor .
	- 沿着走廊你就可以找到他的办公室。
- Keep left along the wall .
	- 沿着墙靠左边走。
- Are you getting along all right in your new job ?
	- 你的新工作顺利吗？
