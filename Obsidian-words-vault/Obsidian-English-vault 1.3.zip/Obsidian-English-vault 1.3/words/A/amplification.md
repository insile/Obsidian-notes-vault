# 词义
- 英：/ˌæmplɪfɪˈkeɪʃn/； 美：/ˌæmplɪfɪˈkeɪʃn/
- #n 放大；扩大（充）；膨胀
# 例句
- That comment needs some amplification .
	- 这个评论需要进一步充实。
- The Optimization Design Method for Tolerance Amplification and Its Applications
	- 公差放大优化设计法及其应用
- Test and Research of Flow Amplification Valve Characteristics
	- 流量放大阀特性试验研究
