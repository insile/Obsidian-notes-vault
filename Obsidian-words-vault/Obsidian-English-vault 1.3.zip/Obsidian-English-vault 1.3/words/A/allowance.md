# 词义
- 英：/əˈlaʊəns/； 美：/əˈlaʊəns/
- #n 津贴；补贴；补助；免税额；限额；定量
- #v 给…发津贴；按定量供给
# 例句
- His monthly allowance is 800 yuan .
	- 他每月津贴为800元。
- The scholarship includes an allowance of $ 100 for books .
	- 奖学金包括100美元书籍费津贴。
- The plan makes no allowance for people working at different rates .
	- 这个计划没有把人们工作速度不同考虑在内。
# 形态
- #word_pl allowances
