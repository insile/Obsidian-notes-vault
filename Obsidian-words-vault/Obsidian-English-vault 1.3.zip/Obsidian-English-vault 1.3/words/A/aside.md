# 词义
- 英：/əˈsaɪd/； 美：/əˈsaɪd/
- #adv 在一边；留；在旁边；存；到旁边；(用于名词后)除…以外
- #n 旁白；低声说的话；离题话
# 例句
- He finished the tea and laid the cup aside
	- 他喝完茶后把杯子搁在一边。
- She took up a slice of bread , broke it nervously , then put it aside
	- 她拿起一片面包，焦虑不安地把它掰碎，又放在一边。
- These areas are set aside for public recreational use .
	- 这些地方已经划出来用于公共娱乐。
# 形态
- #word_pl asides
