# 词义
- 英：/əˈpiːz/； 美：/əˈpiːz/
- #vt 安抚；绥靖(满足另一国的要求以避免战争)；抚慰
# 例句
- The move was widely seen as an attempt to appease critics of the regime .
	- 普遍认为，这一举措是试图安抚批评政权的人。
- The government tried to appease discontented workers .
	- 政府试图安抚不满的工人们。
- Gandhi was accused by some of trying to appease both factions of the electorate
	- 一些人指责甘地试图安抚两派选民。
# 形态
- #word_third appeases
- #word_ing appeasing
- #word_done appeased
- #word_past appeased
