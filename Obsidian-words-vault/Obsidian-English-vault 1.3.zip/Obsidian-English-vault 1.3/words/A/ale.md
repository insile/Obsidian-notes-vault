# 词义
- 英：/eɪl/； 美：/eɪl/
- #n (泛指)啤酒；麦芽酒；麦芽啤酒；一杯(或一瓶、一罐)麦芽啤酒
# 例句
- Just a light ale for me , please .
	- 请给我来点淡麦芽酒。
- Lead cups were used to drink ale or whiskey .
	- 铅制的杯子用来喝麦芽酒或威士忌。
- I live mostly on coffee and ginger ale .
	- 我主要喝咖啡和姜汁汽水。
# 形态
- #word_pl ales
