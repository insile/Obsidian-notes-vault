# 词义
- 英：/ˈæpl/； 美：/ˈæpl/
- #n 苹果
# 例句
- Have an apple to keep you going till dinner time .
	- 吃个苹果就能挨到吃晚饭了。
- She took a dainty little bite of the apple .
	- 她文雅地咬了一小口苹果。
- Apples come in a great many varieties .
	- 苹果的品种繁多。
# 形态
- #word_pl apples
