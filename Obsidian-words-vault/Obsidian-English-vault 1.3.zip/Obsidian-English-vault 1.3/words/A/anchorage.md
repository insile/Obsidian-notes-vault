# 词义
- 英：/ˈæŋkərɪdʒ/； 美：/ˈæŋkərɪdʒ/
- #n (船的)锚地，停泊处；固定处；扣牢处；系牢点
# 例句
- The ship remained in anchorage for a month .
	- 船在锚地停了一个月。
- Behind me was the sea , in front the anchorage .
	- 我的身后是大海，前面是锚地。
- The vessel yesterday reached anchorage off Dubai .
	- 船昨天到达了迪拜附近的泊地。
# 形态
- #word_pl anchorages
