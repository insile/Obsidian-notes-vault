# 词义
- 英：/æʃ/； 美：/æʃ/
- #n 灰；灰烬，废墟；骨灰；梣，梣木；*æ
- #v 撒灰于；把…烧成灰烬
# 例句
- The volcano erupted , raining hot ash over a wide area .
	- 火山喷发，将炽热的火山灰洒落在一大片地域上。
- Volcanic ash showered down on the town after the eruption .
	- 火山喷发后，小城落了一层火山灰。
- Can a new party rise from the ashes of the old one ?
	- 在旧政党的灰烬中会诞生出一个新的政党吗？
# 形态
- #word_pl ashes
