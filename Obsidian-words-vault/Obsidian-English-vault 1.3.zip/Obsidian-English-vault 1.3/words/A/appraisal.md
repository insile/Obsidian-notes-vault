# 词义
- 英：/əˈpreɪzl/； 美：/əˈpreɪzl/
- #n 评价；鉴定；估价；估计；工作表现评估；(上司对雇员的)工作鉴定会
# 例句
- We need to make a proper appraisal of his work .
	- 对于他的工作我们需要做出适当的评价。
- Study on the Appraisal of New and High Technology Special Industry Base
	- 高新技术特色产业基地的评价问题研究
- He had read many detailed critical appraisals of her work .
	- 他读了许多详细评论她的作品的文章。
# 形态
- #word_pl appraisals
