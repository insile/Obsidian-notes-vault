# 词义
- 英：/ˈɑːkɪtektʃə(r)/； 美：/ˈɑːrkɪtektʃər/
- #n (总体、层次)结构；体系结构；建筑设计；建筑风格；建筑学
# 例句
- He studied classical architecture and design in Rome .
	- 他在罗马学习了古典建筑学和设计。
- Finally she obtained a diploma in architecture .
	- 最终她获得了建筑学的学位证书。
- You 'll find this style of architecture all over the town .
	- 全城到处可见这种风格的建筑。
# 形态
- #word_pl architectures
