# 词义
- 英：/ˈænsestə(r)/； 美：/ˈænsestər/
- #n 祖先；祖宗；(机器的)原型；(动物的)原种
# 例句
- Direct descent from a particular ancestor ; ancestry .
	- 血统；血情；源自于同一祖宗或父母血统。
- Celebration , relatives , event , tradition , custom , ancestor , flavor , frosting .
	- 庆祝，亲戚，事件，传统，风俗习惯，祖宗，风味，糖霜。
- The three species evolved from a single ancestor .
	- 这三种生物从同一祖先进化而来。
# 形态
- #word_pl ancestors
