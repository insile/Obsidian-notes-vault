# 词义
- 英：/əˈdɔːrəbl/； 美：/əˈdɔːrəbl/
- #adj 可爱的；讨人喜爱的
# 例句
- What an adorable child !
	- 多可爱的小孩呀！
- We have three adorable children .
	- 我们有3个可爱的孩子。
- ' How adorable ! ' she trills .
	- “真可爱！”她尖声说。
