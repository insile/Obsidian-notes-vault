# 词义
- 英：/ˌæljəˈmɪniəm/； 美：/ˌæljəˈmɪniəm/
- #n 铝
# 例句
- The aluminium body is 12 % lighter than if built with steel .
	- 用铝制作比用钢制作重量要轻12%。
- All parts are machined from top grade , high tensile aluminium .
	- 所有零件都是用顶级高强度铝加工而成。
- Aluminium is rapidly oxidized in air
	- 铝会在空气中迅速氧化。
# 形态
- #word_pl aluminia
