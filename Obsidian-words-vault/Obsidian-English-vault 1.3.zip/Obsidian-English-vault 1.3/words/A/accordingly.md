# 词义
- 英：/əˈkɔːdɪŋli/； 美：/əˈkɔːrdɪŋli/
- #adv 因此；相应地；所以；照着
# 例句
- We have to discover his plans and act accordingly .
	- 我们得找出他的计划，照着办。
- Please pay attention to it and do it accordingly .
	- 请注意它并且照着做它。
- Watch out for sharp bends and adjust your speed accordingly .
	- 当心急转弯并相应调整车速。
