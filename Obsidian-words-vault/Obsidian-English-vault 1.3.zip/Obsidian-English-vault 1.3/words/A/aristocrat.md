# 词义
- 英：/ˈærɪstəkræt/； 美：/əˈrɪstəkræt/
- #n (一位)贵族
# 例句
- It was not the aristocrat but the yeoman who determined the nation 's policies .
	- 决定国家政策的不是贵族，而是自由民。
- A doctor was called in to see a rather testy aristocrat .
	- 一个性格相当暴躁的贵族召来了一位医生为他检查。
- He is setting an example which other aristocrats and leading Britons should follow .
	- 他为其他贵族和伦敦要人们树立了榜样。
# 形态
- #word_pl aristocrats
