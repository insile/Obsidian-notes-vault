# 词义
- 英：/ˈæktə(r)/； 美：/ˈæktər/
- #n 男演员
# 例句
- Did you always want to be an actor ?
	- 你以前一直想当演员吗？
- A career as an actor requires one hundred per cent commitment .
	- 干演员这一行需要百分之百的投入。
- He numbers among the best classical actors in Britain .
	- 他被看作是英国最好的古典剧目演员之一。
# 形态
- #word_pl actors
