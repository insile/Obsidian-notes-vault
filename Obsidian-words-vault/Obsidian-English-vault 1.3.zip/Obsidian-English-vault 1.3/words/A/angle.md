# 词义
- 英：/ˈæŋɡl/； 美：/ˈæŋɡl/
- #n 角度；角；斜角；观点
- #v 从(某角度)报道；钓鱼；垂钓；斜置；以(某观点)提供信息；斜移
# 例句
- The boat is now leaning at a 30 degree angle .
	- 船正以30度角倾斜。
- An infra-red eye is said to detect the movement of any animal within an angle of 110 degrees at up to 10 metres .
	- 据说红外眼能够探测到110度角范围内远至10米的任何动物的活动。
- You can look at the issue from many different angles .
	- 你可以从很多不同的角度看这个问题。
# 形态
- #word_third angles
- #word_ing angling
- #word_done angled
- #word_pl angles
- #word_past angled
