# 词义
- 英：/əˈplaɪəns/； 美：/əˈplaɪəns/
- #n (家用)电器；器具
# 例句
- This is an appliance for opening cans .
	- 这是一件开罐器具。
- So it is a positive type measuring appliance .
	- 因此它是一种被动式测量器具。
- They sell a wide range of domestic appliances ─ washing machines , dishwashers and so on .
	- 他们出售各种家用电器——洗衣机、洗碗机等等。
# 形态
- #word_pl appliances
