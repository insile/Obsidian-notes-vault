# 词义
- #adv 艺术地；艺术地，在艺术上；美术地
# 例句
- Efficiently and artistically strengthening teaching is helpful to the better complement of teaching-learning process .
	- 有效、艺术地运用教学强化，有利于教学过程的更好完成。
- The film reproduced artistically the true history . Historical changes have taken place in the pattern of population reproduction .
	- 这部影片艺术地再现了历史的真实。人口再生产类型实现历史性转变。
- America is the most intellectually , artistically and politically effervescent of nations .
	- 美国是学术、艺术和政治氛围最活跃的国家。
