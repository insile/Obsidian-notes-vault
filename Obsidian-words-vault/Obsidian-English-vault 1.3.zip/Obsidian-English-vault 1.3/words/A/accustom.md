# 词义
- 英：/əˈkʌstəm/； 美：/əˈkʌstəm/
- #v 使习惯(于)；习惯于；使适应
# 例句
- You 'll have to accustom yourself to the new conditions .
	- 你得使自己习惯于新的情况。
- I can accustom myself to cold weather .
	- 我能习惯于冷天气。
- My eyes slowly grew accustomed to the dark .
	- 我的眼睛慢慢适应了黑暗。
# 形态
- #word_third accustoms
- #word_ing accustoming
- #word_done accustomed
- #word_past accustomed
