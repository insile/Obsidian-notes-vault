# 词义
- 英：/əˈbʌndəns/； 美：/əˈbʌndəns/
- #n 大量；充裕；丰盛
# 例句
- There is an abundance of love in the world .
	- 有大量的爱充满这个世界。
- It will produce an abundance of intermediate data and need multiple data transmission .
	- 该模式产生大量的中间数据，需要进行多次数据传输，效率较低。
- Fruit and vegetables grew in abundance on the island .
	- 该岛盛产水果和蔬菜。
