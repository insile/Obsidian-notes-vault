# 词义
- 英：/əˌkɒməˈdeɪʃn/； 美：/əˌkɑːməˈdeɪʃn/
- #n 住宿；住处；膳宿；和解；调解；调和；办公处；停留处
# 例句
- There 's loads of cheap accommodation within cooee of the airport .
	- 机场附近有很多便宜住处。
- The accommodation is simple but spacious .
	- 住处简朴但宽敞。
- The building plans include much needed new office accommodation .
	- 建筑规划包括紧缺的新办公用房在内。
# 形态
- #word_pl accommodations
