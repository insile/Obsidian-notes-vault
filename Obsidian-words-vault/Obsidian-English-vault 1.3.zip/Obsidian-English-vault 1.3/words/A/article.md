# 词义
- 英：/ˈɑːtɪkl/； 美：/ˈɑːrtɪkl/
- #n 文章；(协议、契约的)条款；(报刊上的)论文；报道；物件(尤指整套中的一件)；冠词
- #vi 签订协议；以协议（或契约）约束；使受协议条款的约束；定约雇用进行控告；订约将…收为学徒（或徒弟）；提出罪状（或指责）(against)
# 例句
- Her article is a discussion of the methods used in research .
	- 她这篇文章论述的是研究中使用的方法。
- This article will form the basis for our discussion .
	- 这篇文章将作为我们讨论的基点。
- Did you get your article done in time ?
	- 你的论文按时完成了吗？
# 形态
- #word_third articles
- #word_ing articling
- #word_done articled
- #word_pl articles
- #word_past articled
