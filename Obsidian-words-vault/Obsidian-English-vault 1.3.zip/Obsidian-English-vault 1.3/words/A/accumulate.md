# 词义
- 英：/əˈkjuːmjəleɪt/； 美：/əˈkjuːmjəleɪt/
- #v 积累；积聚；(数量)逐渐增加；(数额)逐渐增长
# 例句
- Households accumulate wealth across a broad spectrum of assets
	- 家庭在以各种各样的资产形式积累财富。
- The true test of an economy is not how much wealth its princes can accumulate in tax havens , but how well off the typical citizen is .
	- 对一个经济体来说,真正的考验不是王子们能在避税天堂积累多少财富,而是普通公民的富裕程度。
- I seem to have accumulated a lot of books .
	- 我好像已经收集了很多书。
# 形态
- #word_third accumulates
- #word_ing accumulating
- #word_done accumulated
- #word_past accumulated
