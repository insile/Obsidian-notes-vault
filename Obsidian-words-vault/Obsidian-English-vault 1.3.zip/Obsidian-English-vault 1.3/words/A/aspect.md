# 词义
- 英：/ˈæspekt/； 美：/ˈæspekt/
- #n 方面；层面；（动词的）体（如表示动作等发生一次或多次、已完成或正在进行）；外观；方位；外表；朝向；样子
# 例句
- This was one aspect of her character he hadn 't seen before .
	- 这是他过去没有了解到的她的性格的一个方面。
- Religion informs every aspect of their lives .
	- 宗教影响着他们生活的各个方面。
- The book aims to cover all aspects of city life .
	- 这本书旨在涵盖城市生活的各个方面。
# 形态
- #word_pl aspects
