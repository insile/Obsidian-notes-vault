# 词义
- 英：/ˈeɪmiəbl/； 美：/ˈeɪmiəbl/
- #adj 和蔼可亲；亲切友好的
# 例句
- Her parents seemed very amiable .
	- 她的父母好像很和蔼可亲。
- He is an amiable old man .
	- 他是一个和蔼可亲的老头。
- He is an educated , amiable and decent man .
	- 他是个有教养、和蔼可亲的正人君子。
# 形态
- #word_est most amiable
- #word_er more amiable
