# 词义
- 英：/əˌprɒksɪˈmeɪʃn/； 美：/əˌprɑːksɪˈmeɪʃn/
- #n 近似值；粗略估算；类似事物
# 例句
- That 's just an approximation , you understand .
	- 你知道那仅仅是近似值。
- The problem is that the statistics aren 't an objective measure of reality ； they are simply a best approximation .
	- 问题是,统计数据并不是对现实的客观衡量；它们只是一个最佳的近似值。
- Our results should be a good approximation to the true state of affairs .
	- 我们的结果应该和实际情况相当接近。
# 形态
- #word_pl approximations
