# 词义
- 英：/əˈdʒeɪsnt/； 美：/əˈdʒeɪsnt/
- #adj 相邻；邻近的；与…毗连的
# 例句
- The house adjacent to ours is under repairs .
	- 与我家相邻的房子正在修缮。
- The last is perfect our country environment adjacent relation of thinking .
	- 最后是完善我国环境相邻关系的思考。
- Our farm land was adjacent to the river .
	- 我们的农田在河边。
