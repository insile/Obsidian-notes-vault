# 词义
- 英：/ˌɑːbɪˈtreɪʃn/； 美：/ˌɑːrbɪˈtreɪʃn/
- #n 仲裁；公断
# 例句
- Both sides in the dispute have agreed to go to arbitration .
	- 争执双方已同意提请仲裁。
- The matter is likely to go to arbitration .
	- 这件事很有可能要提请仲裁。
- The judge said that arbitration was a fair and expeditious decision-making process .
	- 法官说仲裁是公平且迅速有效的判决过程。
# 形态
- #word_pl arbitrations
