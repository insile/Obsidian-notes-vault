---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/əˈdɒpʃn/； 美：/əˈdɑːpʃn/
- #词性/n  (想法、计划、名字等的)采用；收养；领养；(候选人的)选定，推选，推举
# 例句
- There is increasing worldwide adoption of the same name for each therapeutic substance .
	- 在世界范围内对一药物有逐渐采用同一个药名的趋势。
- Every different level of adoption has its own unique needs .
	- 采用的每个不同的级别都与它自己的唯一的要求。
- She put the baby up for adoption .
	- 她提出要让人收养那个婴儿。
# 形态
- #形态/word_pl adoptions
