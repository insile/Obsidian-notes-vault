---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/əˈfɔːd/； 美：/əˈfɔːrd/
- #词性/v  提供；给予；(有时间)做，能做；买得起；承担得起(后果)
# 例句
- How on earth can she afford that ?
	- 她怎么可能负担得起呢？
- If I 've got my sums right , I should be able to afford the rent .
	- 要是我算对了的话，我应该负担得起这笔租金。
- There 's no way we could afford that sort of money .
	- 我们无论如何都花不起那种钱。
# 形态
- #形态/word_third affords
- #形态/word_ing affording
- #形态/word_done afforded
- #形态/word_past afforded
