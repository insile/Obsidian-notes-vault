---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈkjuːt/； 美：/əˈkjuːt/
- #词性/adj  (疾病)急性的；严重的；锐角的；敏锐的；灵敏的
# 例句
- The war has aggravated an acute economic crisis
	- 战争加剧了原本已很严重的经济危机。
- He collapsed from acute renal failure
	- 他的身体因为严重的肾衰竭而垮掉了。
- There is an acute shortage of water .
	- 水严重短缺。
