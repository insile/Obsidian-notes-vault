---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性/v  生长；附加；增大；堆（累）积；粘（附）着；愈合
- #词性/adj  合生的
# 例句
- The results show that from top to bottom , the PAL and POD activities of the shoots progressively increase and their contents of cellulose and lignin also accrete ;
	- 结果表明：从顶部到基部，竹笋各区段部位PAL和POD活性逐渐增强，纤维素和木质素含量增大；
- It analyzes the concrete reason that the hole-digging grouting pile 's roughness has an influence to carrying capacity , summarizes the constructive measures that accrete hole wall roughness . Introduces the concrete construction technique of pressure grouting , and propounds the calculation formula of carrying capacity .
	- 分析了钻孔灌注桩的孔壁粗糙度对其承载力产生影响的具体原因，并总结了一些增大孔壁粗糙度的施工措施，介绍了压力灌浆的具体施工工艺，并提出承载力计算公式。
- There exists one kind of natural and accrete relationship between city commercial bank and small business .
	- 城市商业银行与小企业有着天然的、共生共荣的联系。
# 形态
- #形态/word_third accretes
- #形态/word_done accreted
- #形态/word_ing accreting
- #形态/word_past accreted
