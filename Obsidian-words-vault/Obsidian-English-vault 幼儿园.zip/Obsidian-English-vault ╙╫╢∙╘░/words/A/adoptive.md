---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈdɒptɪv/； 美：/əˈdɑːptɪv/
- #词性/adj  收养的；有收养关系的
# 例句
- At six weeks Alice was give to her adoptive family .
	- 六周大时，爱丽丝被送到收养的家庭。
- Difficult to place in an adoptive home .
	- 难以放在收养的家庭里。
- He was brought up by adoptive parents in London .
	- 他由养父母在伦敦抚养长大。
