---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌæɡərəˈfəʊbɪk/； 美：/ˌæɡərəˈfoʊbɪk/
- #词性/n  广场恐怖症患者；公共场所恐惧症患者
- #词性/adj  恐旷症的；广场恐怖的；旷野恐怖的；陌生环境恐怖的
# 例句
- She said that the reason she doesn 't go out much is because she 's agoraphobic .
	- 她说她不太出去的原因是由于害怕恐旷患者。
- She writes some pretty ballsy stuff for an agoraphobic .
	- 她写了一些广场恐惧症不好的东西。
- The avid comic book reader considers himself a borderline agoraphobic with mild-to-severe anxiety issues who wishes he were a superhero himself .
	- 他同时是一个超级漫画迷，并认为自己有边缘恐旷症，和时轻时重的焦虑问题，他想成为一个超级英雄。
# 形态
- #形态/word_pl agoraphobics
