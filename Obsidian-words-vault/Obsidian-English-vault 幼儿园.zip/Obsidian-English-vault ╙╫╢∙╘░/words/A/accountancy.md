---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈkaʊntənsi/； 美：/əˈkaʊntənsi/
- #词性/n  会计工作；会计学；会计职业
# 例句
- He 's sitting his final exams in accountancy .
	- 他正参加会计学的期末考试。
- Earning management is the core issue of current study on accountancy .
	- 盈余管理是目前会计学研究的核心问题之一。
- Accountancy just isn 't sexy .
	- 会计工作实在乏味。
