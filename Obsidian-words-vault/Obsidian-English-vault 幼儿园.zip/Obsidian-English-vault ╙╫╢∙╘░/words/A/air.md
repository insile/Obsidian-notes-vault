---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/eə(r)/； 美：/er/
- #词性/n  空气；(飞行的)空中；天空；感觉；摆架子；曲调
- #词性/v  (使)通风，透风；播出；晾干；晾；公开发表
# 例句
- Ensure there is a free flow of air around the machine .
	- 要确保机器周围空气畅通。
- Let 's go and get some fresh air .
	- 咱们出去呼吸点新鲜空气。
- During the birth she was given gas and air .
	- 她分娩时用了麻醉混合气体。
# 形态
- #形态/word_third airs
- #形态/word_ing airing
- #形态/word_done aired
- #形态/word_pl airs
- #形态/word_past aired
