---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˌæbəˈləʊni/； 美：/ˌæbəˈloʊni/
- #词性/n  鲍鱼
# 例句
- The Analysis of Elements Content of abalone from different places
	- 不同产地鲍鱼中若干元素含量的分析
- As the water quality good , Australia is famous for high-quality abalone .
	- 由于水质好，澳大利亚鲍鱼以高质量而闻名。
- Dynamic variation of water quality in flowing system for abalone culture
	- 工厂化流水养鲍系统水质动态变化
# 形态
- #形态/word_pl abalones
