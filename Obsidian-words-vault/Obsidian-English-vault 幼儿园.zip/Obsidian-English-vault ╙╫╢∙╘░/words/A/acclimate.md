---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈækləmeɪt/； 美：/ˈækləmeɪt/
- #词性/v  适应；驯化；顺应；使适应新环境；使（植物）逐步变得耐寒
# 例句
- How much time does she need to acclimate ?
	- 她需要多少时间才能适应？
- I help them acclimate to living in the U.S.
	- 我帮助他们适应在美国的生活。
- This guide will help acclimate you to OT 's culture .
	- 这个指南将帮助你适应OT论坛文化。
