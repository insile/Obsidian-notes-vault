---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈædvəkəsi/； 美：/ˈædvəkəsi/
- #词性/n  支持；提倡；(对某思想、行动方针、信念的)拥护；(律师)出庭辩护；律师的工作
# 例句
- She is renowned for her advocacy of human rights .
	- 她以提倡人权而闻名。
- Further Advocacy of Autonomous Learning in College English Teaching
	- 大学英语教学应进一步提倡自主学习
- I support your advocacy of free trade .
	- 我支持你自由贸易的主张。
# 形态
- #形态/word_pl advocacies
