---
tags:
  - 首字母/A
  - 级别/雅思
掌握: false
模糊: false
---
# 词义
- #词性缺失 适应
# 例句
- This year he has left for St Louis early to acclimatise himself
	- 今年他早早地前往圣路易斯以便适应新环境。
- If I went by train I could acclimatise to the altitude on the way there .
	- 如果坐火车，我就能在路上逐渐适应那里的海拔了。
- They have been travelling for two days and will need some time to acclimatise .
	- 他们在旅途中奔波了两天，需要时间调整。
