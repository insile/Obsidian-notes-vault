---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- #词性/n  无球粒陨石
# 例句
- Of or related to an achondrite .
	- 无球粒陨石的或与之相关的。
