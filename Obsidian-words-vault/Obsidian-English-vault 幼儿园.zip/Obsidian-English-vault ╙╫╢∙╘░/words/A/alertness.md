---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/əˈlɜːtnəs/； 美：/əˈlɜːrtnəs/
- #词性/n  警觉；清醒；机警
# 例句
- Produces changes in brain activity associated with decreased alertness ;
	- 影响中枢活动，警觉能力下降；
- I know him well in that mood of alertness and suspicion .
	- 我对他这种警觉和猜疑的情绪是很熟悉的。
- The presence of non-task-oriented ideas is a sign of broad interest , concern , and alertness on the part of the employees .
	- 一些非有关部门工作的建议的产生，标志了在部分职工中的广泛兴趣、机智和关心企业的精神素质。
