---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbet/； 美：/əˈbet/
- #词性/vt  教唆；怂恿；煽动；唆使
# 例句
- Monetary policy goals are to aid and abet solid economic growth along with rising living standards .
	- 货币政策目标是援助和教唆坚实经济增长与上升的生存标准一起。
- Research on Determining the Nature of the Crime that Persons with Certain Identity Abet or Help Others without the Identity
	- 身份者教唆、帮助不具有该身份者实施身份犯罪的定性研究
- She stands accused of aiding and abetting the crime .
	- 她被控帮助和教唆犯罪。
# 形态
- #形态/word_third abets
- #形态/word_ing abetting
- #形态/word_done abetted
- #形态/word_past abetted
