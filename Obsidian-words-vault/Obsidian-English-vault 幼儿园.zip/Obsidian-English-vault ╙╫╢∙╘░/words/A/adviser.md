---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ədˈvaɪzə(r)/； 美：/ədˈvaɪzər/
- #词性/n  顾问；提供意见者
# 例句
- Ring four two double two double two if you 'd like to speak to our financial adviser .
	- 如果想和我们的财务顾问通话，拨打422222。
- An adviser said there was no reason why the two countries should remain at odds .
	- 一位顾问说这两个国家不会一直这样争执下去。
- He is one of the prime minister 's closest advisers .
	- 他是首相最亲信的顾问之一。
# 形态
- #形态/word_pl advisers
