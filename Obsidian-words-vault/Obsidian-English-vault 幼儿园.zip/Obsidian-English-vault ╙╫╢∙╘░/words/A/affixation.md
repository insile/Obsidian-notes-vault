---
tags:
  - 首字母/A
  - 级别/六级
掌握: false
模糊: false
---
# 词义
- #词性/n  词缀；添加
# 例句
- A Brief Analysis on Affixation Rhetorical Function of Chinese Words
	- 浅析汉语词语的附加修辞功能
- The rhetorical function of Chinese words is very abundant , the affixation rhetorical function is one of them .
	- 汉语词语的修辞功能是较丰富的，词语的附加修辞功能只是词语的语言修辞功能的一个方面。
- An affixation compound is composed of a substantive morpheme and an empty morpheme .
	- 在词的构成成分中，实语素叫词根，虚语素叫词缀
