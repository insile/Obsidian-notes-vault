---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbriːvieɪt/； 美：/əˈbriːvieɪt/
- #词性/vt  缩写；把(词语、名称)缩写(成…)；缩略
# 例句
- This also is world car market the abbreviate of intense competition occasion .
	- 这也是世界汽车市场激烈竞争场面的缩写。
- I like to abbreviate my name because it 's easier for people to remember .
	- 我喜欢缩写我的名字，因为这样人们更容易记忆。
- He abbreviated his first name to Alec .
	- 他将自己的名字缩写为亚历克。
# 形态
- #形态/word_third abbreviates
- #形态/word_ing abbreviating
- #形态/word_done abbreviated
- #形态/word_past abbreviated
