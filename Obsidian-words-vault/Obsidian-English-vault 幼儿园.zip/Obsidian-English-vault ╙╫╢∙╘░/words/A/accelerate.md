---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əkˈseləreɪt/； 美：/əkˈseləreɪt/
- #词性/v  加速；(使)加速；加快
# 例句
- Growth will accelerate to 2.9 per cent next year
	- 明年的增长会加快到2.9%。
- We need to accelerate the pace of change in our backward country .
	- 我们应当为落后的祖国加快变革的脚步。
- The runners accelerated smoothly around the bend .
	- 赛跑运动员在转弯处顺畅地加速。
# 形态
- #形态/word_third accelerates
- #形态/word_ing accelerating
- #形态/word_done accelerated
- #形态/word_past accelerated
