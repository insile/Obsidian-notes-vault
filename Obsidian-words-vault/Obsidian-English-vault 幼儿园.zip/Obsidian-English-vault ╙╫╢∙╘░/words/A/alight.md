---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈlaɪt/； 美：/əˈlaɪt/
- #词性/vi  从(公共汽车、火车等)下来；点燃；降落；飞落
- #词性/adj  燃烧；着火；兴奋；容光焕发
# 例句
- This was alight moments ago . They 're still here !
	- 这是不久前点燃的，他们还在这儿！
- In three weeks of protests , roads have been blocked and municipal buildings set alight .
	- 在为期三周的抗议中，道路被封锁，市政建筑被点燃。
- A cigarette set the dry grass alight .
	- 一支香烟把干草点燃了。
# 形态
- #形态/word_third alights
- #形态/word_ing alighting
- #形态/word_done alighted
- #形态/word_past alighted
