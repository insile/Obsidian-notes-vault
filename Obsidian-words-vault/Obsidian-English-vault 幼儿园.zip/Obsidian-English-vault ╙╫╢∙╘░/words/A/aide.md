---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/eɪd/； 美：/eɪd/
- #词性/n  (尤指从政者的)助手
# 例句
- An aide was already spinning the senator 's defeat as ' almost as good as an outright win ' .
	- 一名助手已经开始将那位参议员的失败描述成“几乎是大获全胜”。
- Development and Application of Drilling Engineers Aide System
	- 钻井工程师助手系统的开发应用
- The President met with senior White House aides .
	- 总统会见了白宫的高级助手。
# 形态
- #形态/word_pl aides
