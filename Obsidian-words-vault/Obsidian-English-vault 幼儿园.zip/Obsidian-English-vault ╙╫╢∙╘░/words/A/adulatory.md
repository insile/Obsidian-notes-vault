---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌædjuˈleɪtəri/； 美：/ˈædʒələtɔːri/
- #词性/adj  谄媚的；奉承的；恭维的
# 例句
- Husband ( one face is adulatory ) : Hey , do not want to eat .
	- 老公（一脸谄媚）：嘿嘿，不想吃。
- Many of these adulatory characterizations were attributed to unnamed sources .
	- 在这些献媚取宠的特写当中，很多材料来源不清。
- There will be adulatory profiles of startup founders and VC firms who first backed them – firms like Union Square ventures and andreessen-horowitz .
	- 人们会对初创公司的创始人们大献谀词，而像合广投资（UnionSquareVentures）和安德森霍洛维茨公司（Andreessen-Horowitz）这些最早资助Facebook的风投机构的形象也会变得光辉起来。
