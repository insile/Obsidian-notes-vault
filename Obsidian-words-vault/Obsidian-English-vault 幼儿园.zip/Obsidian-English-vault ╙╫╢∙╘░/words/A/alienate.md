---
tags:
  - 首字母/A
  - 级别/考研
  - 级别/六级
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈeɪliəneɪt/； 美：/ˈeɪliəneɪt/
- #词性/vt  使疏远；使(与某群体)格格不入；离间；使不友好
# 例句
- His attempts to alienate the two friends failed because they had complete faith .
	- 他离间那两个朋友的企图失败了，因为他们彼此完全信任。
- To make hostile , unsympathetic , or indifferent ; alienate .
	- 使疏远使怀有敌意，使不友善或使疏远；离间。
- Very talented children may feel alienated from the others in their class .
	- 天才出众的孩子可能觉得与班上的同学格格不入。
# 形态
- #形态/word_third alienates
- #形态/word_ing alienating
- #形态/word_done alienated
- #形态/word_past alienated
