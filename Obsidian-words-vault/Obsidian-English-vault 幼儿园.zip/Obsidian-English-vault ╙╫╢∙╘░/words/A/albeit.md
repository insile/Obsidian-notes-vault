---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌɔːlˈbiːɪt/； 美：/ˌɔːlˈbiːɪt/
- #词性/conj  尽管；虽然
# 例句
- He finally agreed , albeit reluctantly , to help us .
	- 尽管勉强，他最后还是同意帮助我们。
- Charles 's letter was indeed published , albeit in a somewhat abbreviated form .
	- 尽管有所删节，查尔斯的信确实被刊登出来了。
- Albeit fictional , she seemed to have resolved the problem .
	- 虽然是虚构的，但是在她看来好像是解决了问题。
