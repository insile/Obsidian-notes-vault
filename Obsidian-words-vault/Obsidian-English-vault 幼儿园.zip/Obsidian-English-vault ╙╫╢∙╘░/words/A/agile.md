---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈædʒaɪl/； 美：/ˈædʒl/
- #词性/adj  (动作)敏捷的；灵活的；(思维)机敏的；机灵的
# 例句
- Agile projects are built around this kind of great communication .
	- 敏捷的项目正是围绕这种出色的交流而建立。
- Is your team coping with working in an Agile way ?
	- 你的团队以敏捷的方式在工作吗？
- At 20 years old he was not as agile as he is now .
	- 20岁时他并不如现在这般矫健。
