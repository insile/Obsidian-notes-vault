---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈiːən/； 美：/ˈiːən/
- #词性/n  千万年；极漫长的时期；宙(地质学上的年代分期，下分代)
# 例句
- On the development front , Aeon has a robust pipeline .
	- 关于发展方面，永旺拥有强大的管道。
- At this point , a new aeon with a low entropy state will begin .
	- 如此一来，一个新的低熵宇宙将开始。
- It will do so through yet another subsidiary , Beijing Aeon Co.
	- 它将通过另一家子公司，北京永旺公司来执行。
# 形态
- #形态/word_pl aeons
