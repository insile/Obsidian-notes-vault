---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ədˈventʃə(r)/； 美：/ədˈventʃər/
- #词性/n  冒险；奇遇；冒险经历；冒险的刺激；大胆开拓
- #词性/v  <旧>探险；<旧>冒险；大胆说出
# 例句
- Their cultural backgrounds gave them a spirit of adventure .
	- 他们的文化背景赋予了他们一种冒险精神。
- I set off for a new adventure in the United States on the first day of the new year .
	- 新年第一天，我在美国开始了一次新的冒险。
- He was a romantic at heart and longed for adventure .
	- 他骨子里是一位浪漫的人，渴望历险。
# 形态
- #形态/word_third adventures
- #形态/word_ing adventuring
- #形态/word_pl adventures
- #形态/word_past adventured
