---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈkuːstɪks/； 美：/əˈkuːstɪks/
- #词性/n  声学；(房间、戏院的)传声效果，音响效果
# 例句
- The place is big enough , but the acoustics are no good for a concert .
	- 这个场子够大，可是音响效果不好，不适合用来开音乐会。
- Poor acoustics spoilt the performance .
	- 音响效果不好，使演出大为减色。
- The acoustics of the new concert hall are excellent .
	- 新音乐厅的传声效果极佳。
# 形态
- #形态/word_proto acoustic
