---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ədˈventʃərə(r)/； 美：/ədˈventʃərər/
- #词性/n  冒险家；冒险者；投机分子
# 例句
- Very well , very well . I will find a real adventurer , who is not afraid of helping people !
	- 很好，很好。我会去找一个真正的冒险者，一个助人为乐的冒险者！
- The adventurer recked little of the danger and hardships .
	- 冒险者对危险和困苦毫不在意。
- When we think of adventurers , many of us conjure up images of larger-than-life characters trekking to the North Pole .
	- 一想到探险者，我们很多人脑海中浮现的便是长途跋涉前往北极的非凡人物形象。
# 形态
- #形态/word_pl adventurers
