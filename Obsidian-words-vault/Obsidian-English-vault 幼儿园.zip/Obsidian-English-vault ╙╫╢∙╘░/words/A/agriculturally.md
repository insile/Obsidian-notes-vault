---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- #词性缺失 农业上
# 例句
- It seems like it makes sense to me to say we are going to help you become more agriculturally self-sustaining .
	- 依我所见，告诉他们：我们将帮助你们在农业上更加自立，这是合理可行的办法。
- In some countries , especially France , gypsum is used agriculturally as a structure-improving agent for the soil .
	- 在某些国家中，尤其是法国，石膏在农业上用作为土壤结构改良剂。
- A programming idea of agriculturally ecological economic system
	- 农业生态经济系统的规划思路
