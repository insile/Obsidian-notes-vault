---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/'æktɪvli/； 美：/'æktɪvli/
- #词性/adv  积极地；主动地；活跃地
# 例句
- Despite his illness , he remained actively engaged in translating documents .
	- 虽然生病了，他还是积极地参与文件的翻译。
- Are you actively preserving the present , or selectively forgetting the past , or boldly creating the future ?
	- 你是在积极地维持现状，选择性地遗忘过去，还是大胆地创造未来呢?
- The company is being actively considered as a potential partner .
	- 这家公司正在被积极考虑为可能的合作伙伴。
