---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbreɪʒn/； 美：/əˈbreɪʒn/
- #词性/n  磨损；(表层)磨损处；(皮肤、表皮)擦伤处
# 例句
- Diamonds have extreme resistance to abrasion .
	- 钻石极抗磨损。
- Because there is no abrasion between the concave and convex , the nut is reusable .
	- 因为凹面与凸面没有磨损，螺母可以重复使用。
- The rivet heads are in good condition and without abrasion .
	- 铆钉钉头状况良好，并无过度磨损。
# 形态
- #形态/word_pl abrasions
