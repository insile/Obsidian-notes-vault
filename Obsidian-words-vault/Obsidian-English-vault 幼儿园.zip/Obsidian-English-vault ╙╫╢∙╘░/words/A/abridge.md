---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbrɪdʒ/； 美：/əˈbrɪdʒ/
- #词性/vt  删节，节略(书籍、剧本等)
# 例句
- Article 33 Book publishers may modify or abridge works with the license of authors .
	- 第三十三条图书出版者经作者许可，可以对作品修改、删节。
- We have to abridge the movie because it is too long .
	- 我们不得不删节这个电影因为它太长了。
- A long story can be abridged by leaving out unimportant parts .
	- 可将一个冗长故事中无关紧要的部分删去以减少篇幅。
# 形态
- #形态/word_third abridges
- #形态/word_ing abridging
- #形态/word_done abridged
- #形态/word_past abridged
