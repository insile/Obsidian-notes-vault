---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/æɡˈnɒstɪk/； 美：/æɡˈnɑːstɪk/
- #词性/n  不可知论者(认为上帝存在与否是不可知的)
- #词性/adj  不可知论（者）的
# 例句
- Vasari claimed with horror that he was , if not an atheist , then an agnostic .
	- 瓦萨里惊恐地说他若非无神论者，就是不可知论者。
- An agnostic is a doubter .
	- 不可知论者即是怀疑论者。
- You grew up in an agnostic household and have never been able to bring yourself to believe in God .
	- 你在一个信奉不可知论的家庭里长大，一直都无法信仰上帝。
# 形态
- #形态/word_pl agnostics
