---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əbˈhɔː(r)/； 美：/əbˈhɔːr/
- #词性/vt  (尤指因道德原因而)憎恨，厌恶，憎恶
# 例句
- Today , many people abhor the name of God .
	- 今天，很多人憎恨上帝之名。
- Countries in difficulty have accepted austerity that their citizens abhor .
	- 陷入困境的国家接受了本国民众憎恨的紧缩措施。
- He was a man who abhorred violence and was deeply committed to reconciliation
	- 他是一个憎恶采用暴力而坚决主张和解的人。
# 形态
- #形态/word_third abhors
- #形态/word_ing abhorring
- #形态/word_done abhorred
- #形态/word_past abhorred
