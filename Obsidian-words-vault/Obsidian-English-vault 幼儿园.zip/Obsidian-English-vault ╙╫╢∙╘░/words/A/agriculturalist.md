---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˌæɡrɪˈkʌltʃərəlɪst/； 美：/ˌæɡrɪˈkʌltʃərəlɪst/
- #词性/n  农学家；农艺师；农业技术员
# 例句
- Animal growth or product yield is the ultimate concern of the agriculturalist .
	- 牲畜的生长或其产品的生产量是农学家最关心的问题。
- Students were also trained as economists , architects , agriculturalists , social welfare workers , and teachers .
	- 学生们还被培训成为经济学家、建筑师、农学家、社会工作人员以及教师。
- The results show that management organizations in charge of agriculturalists in Western Hunan Region are far from perfect , especially those at the village level .
	- 研究结果表明，湘西地区农民体育的组织管理机构，特别是村一级的组织管理机构还很不健全。
# 形态
- #形态/word_pl agriculturalists
