---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性/n  灵感
# 例句
- The Third Way to Get Acquainted with the Essence of Afflatus
	- 试论认识灵感本质的第三条途径
- So the afflatus of clothing design must be pursued from all-around and multiple directions .
	- 因此要从多角度、多层次、多方位去寻求服装设计的灵感。
- Afflatus a professional " brand interpretation " become the most influential design of communication agencies .
	- 灵觉以专业的“品牌演绎”成为国内最具影响力的设计传播机构之一。
