---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈædɪdʒ/； 美：/ˈædɪdʒ/
- #词性/n  格言；谚语
# 例句
- An old adage says : " There is no smoke without fire . "
	- 古老的谚语说：“无风不起浪。”
- Remember the adage Every cloud has a silver lining .
	- 记住，谚语，每一片云彩都有明亮的一面。
- But the old adage that men grow into office has not proved true in my experience .
	- 但是，根据我的经验，人们所谓的工作岗位造就人材这句古话并不正确。
# 形态
- #形态/word_pl adages
