---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˈædmərəl/； 美：/ˈædmərəl/
- #词性/n  海军上将；舰队司令；海军将官
# 例句
- He was hand-picked for this job by the Admiral
	- 他是由海军上将精心挑选出来担任这项工作的。
- He had never met a real live admiral
	- 他从来没遇到过一位真正的海军上将。
- The admiral visited the ships under his command .
	- 舰队司令视察了他所统率的军舰。
# 形态
- #形态/word_pl admirals
