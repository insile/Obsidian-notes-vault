---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈkɔːdns/； 美：/əˈkɔːrdns/
- #词性/n  符合；一致；给予；赋予；和谐
# 例句
- Environmental protection 's goal is in accordance with economy increase .
	- 环境保护与经济增长在目标上是一致的。
- The development was in accordance with the economic and cultural prosperity .
	- 刻书业的发展与经济、文化的繁荣是相一致的。
- Most people believe they conduct their private and public lives in accordance with Christian morality .
	- 大多数人认为他们是依照基督教的道德体系来处理自己的私生活和公共事务的。
