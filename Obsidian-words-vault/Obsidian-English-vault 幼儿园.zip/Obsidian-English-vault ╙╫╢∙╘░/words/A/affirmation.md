---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˌæfɜːˈmeɪʃ(ə)n/； 美：/ˌæfərˈmeɪʃən/
- #词性/n  肯定；确认；证实；断言；主张
# 例句
- She nodded in affirmation .
	- 她肯定地点了点头。
- It was less a plea for immediate action than for an affirmation of purpose .
	- 这并不在于要求它立即采取行动，而是要求确认它的意图。
- A Study of the Affirmation by Law and the Insurance Patterns
	- 环境权的法律确认与保障方式研究
# 形态
- #形态/word_pl affirmations
