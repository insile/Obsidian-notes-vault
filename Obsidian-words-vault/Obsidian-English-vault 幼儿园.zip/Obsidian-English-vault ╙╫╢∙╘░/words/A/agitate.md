---
tags:
  - 首字母/A
  - 级别/考研
  - 级别/六级
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈædʒɪteɪt/； 美：/ˈædʒɪteɪt/
- #词性/v  搅动；使激动；使不安；(尤指为法律、社会状况的改变而)激烈争论，鼓动，煽动；摇动(液体等)；激怒
# 例句
- Add 1 ml solution C ( Nessler 's reagent ) to 25 ml water sample . Agitate the mixture for 20 sec .
	- 加1亳升的C溶液（奈氏试剂）进25亳升的样本中，把混合液摇动20秒。
- All you need to do is gently agitate the water with a finger or paintbrush
	- 你只需要用手指或刷子轻轻地搅动水。
- I could not distinguish her words , but she sounded agitated .
	- 我听不清她说的话，但听得出她很紧张不安。
# 形态
- #形态/word_third agitates
- #形态/word_ing agitating
- #形态/word_done agitated
- #形态/word_past agitated
