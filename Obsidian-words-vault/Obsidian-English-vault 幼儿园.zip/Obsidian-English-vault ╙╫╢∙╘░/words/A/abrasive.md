---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbreɪsɪv/； 美：/əˈbreɪsɪv/
- #词性/n  (用来擦洗表面或使表面光滑的)磨料
- #词性/adj  研磨的；粗鲁的；生硬粗暴的；有研磨作用的；伤人感情的
# 例句
- Cutting with abrasive water jet is a new technology under development .
	- 磨料水射流切割是一项正在发展的新技术。
- Design and Application of Cutting Device of Portable Abrasive Water Jet
	- 便携式磨料射流切割装置的设计与应用
- Women sometimes damage their skin by going overboard with abrasive cleansers
	- 女性有时因过度使用磨砂膏而损伤了皮肤。
# 形态
- #形态/word_pl abrasives
