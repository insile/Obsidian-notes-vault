---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈdendəm/； 美：/əˈdendəm/
- #词性/n  补遗；(尤指书籍的)补篇
# 例句
- Addendum to the Teaching Method of Modern Chinese
	- 《现代汉语》教法补遗
- The Addendum to the Factors Influencing the Sediment Solubility in Analytical Chemistry
	- 对分析化学中有关沉淀溶解度影响因素的补遗
- Please propose amendments and addenda to the first draft of the document .
	- 请对这个文件的初稿提出修改和补充意见。
# 形态
- #形态/word_pl addenda
