---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˌfɔːdəˈbɪlɪti/； 美：/əˌfɔrdəˈbɪləti/
# 例句
- Affordability has been a key concern in the assessment process .
	- 负担能力一直是评估过程中遇到的关键问题。
- Analysis of the housing affordability for middle-low income families and policy suggestions
	- 我国中低收入家庭住宅负担能力分析及政策建议
- Performance-Based Logistics Affordability : Can We Afford Categorical Conversion to Performance-Based Acquisition ?
	- 基于性能的后期的可承受性：能否担负得起向基于性能的采办的无条件的转变？
