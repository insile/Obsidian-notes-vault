---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌækwiˈesns/； 美：/ˌækwiˈesns/
- #词性/n  默许；默认；顺从；默然接受
# 例句
- There was general acquiescence in the UN sanctions .
	- 普遍默认了联合国的制裁。
- Through changing the navigation frame of acquiescence , it can avoid repeated work ;
	- 通过改变默认的导航框架，避免重复工作；
- Fear of rapid social change made temporary acquiescence in slavery tolerable in the South .
	- 对飞速的社会变革的恐惧使得南部对奴隶制暂时的默许变得可以忍受。
