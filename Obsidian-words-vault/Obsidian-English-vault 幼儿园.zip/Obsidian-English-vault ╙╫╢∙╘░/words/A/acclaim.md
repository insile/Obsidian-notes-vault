---
tags:
  - 首字母/A
  - 级别/考研
  - 级别/六级
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈkleɪm/； 美：/əˈkleɪm/
- #词性/vt  宣称；称誉某人 / 事物(为…)；给予高度评价
- #词性/n  (尤指对艺术成就的)称誉，高度评价
# 例句
- The film met with considerable critical and public acclaim
	- 该影片受到了影评人和公众的高度评价。
- A BBC show about a BBC show , " The Office " earned critical acclaim after landing in the U.S.
	- 《办公室风云》是一部关于BBC电视节目的BBC电视剧，在美国播出后获得高度评价。
- In her day she never received the critical acclaim she deserved .
	- 她一生从未受到过评论家应当给她的赞扬。
# 形态
- #形态/word_third acclaims
- #形态/word_ing acclaiming
- #形态/word_done acclaimed
- #形态/word_past acclaimed
