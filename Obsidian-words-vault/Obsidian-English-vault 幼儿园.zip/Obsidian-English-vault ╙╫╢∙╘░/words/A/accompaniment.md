---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/əˈkʌmpənimənt/； 美：/əˈkʌmpənimənt/
- #词性/n  (音乐)伴奏；伴随物；佐餐物；伴随发生的事情
# 例句
- He sang ' My Funny Valentine ' to a piano accompaniment .
	- 他在钢琴的伴奏下演唱了《我可爱的情人》。
- The pianist improvised an accompaniment to the song .
	- 那位钢琴家为那首歌即席伴奏。
- High blood pressure is a common accompaniment to this disease .
	- 这种病通常伴随有高血压。
# 形态
- #形态/word_pl accompaniments
