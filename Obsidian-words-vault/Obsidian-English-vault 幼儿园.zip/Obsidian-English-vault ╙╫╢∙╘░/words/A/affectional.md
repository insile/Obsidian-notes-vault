---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- #词性缺失 感情的；爱情；情感性的；情感性；情感上
# 例句
- The bonds of marriage and family life are no longer functional , but affectional .
	- 婚姻和家庭生活的纽带不再是功能性的，而是情感性的了。
- Therefore , affectional education is very important in the period of primary English teaching .
	- 因此，在小学英语教学中情感教育就显的尤其重要。
- Affectional Factors ( N 、 C \/ N 、 Temperature and Water Content ) of Root Decomposition
	- 影响根系分解因素（N、C\/N、温度和水分）的研究
