---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈæfluəns/； 美：/ˈæfluəns/
- #词性/n  富裕；富足
# 例句
- Pockets of affluence coexist with poverty
	- 少数富裕地区与贫困地区并存。
- Realizing Common Affluence as the Important Value of the Socialist Society
	- 实现共同富裕：社会主义社会的重要价值
- For them , affluence was bought at the price of less freedom in their work environment .
	- 对他们来说，富足是以减少在工作场所的自由为代价才获得的。
