---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/əˈbændənmənt/； 美：/əˈbændənmənt/
- #词性/n  放弃；抛弃；遗弃；离弃；中止
# 例句
- Chronic fear of abandonment and panic when forced to be alone .
	- 长期的离弃恐惧感和当迫于孤独时的痛苦感。
- Bearing of Meanings and Abandonment of Aesthetics-On the Plot Predicament of Bei Cun s Novels about Love and Marriage ; To agree to take ( a duty or responsibility ) .
	- 意义担当与审美的离弃&北村婚恋小说的情节困境承担同意承担（义务或责任）
- Constant rain forced the abandonment of the next day 's competitions .
	- 连绵阴雨致使翌日各项赛事被迫中止。
