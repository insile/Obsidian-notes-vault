---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈælkəʊv/； 美：/ˈælkoʊv/
- #词性/n  壁龛(房内墙壁凹进空间)；凹室；壁凹
# 例句
- On your left there will be a small alcove past a bird walking around .
	- 在您的左边会有一个小壁龛过去一走动鸟。
- When going through the door , look up and right and you 'll see an alcove .
	- 进门之后向右上方看，你将找到一个壁龛。
- The bookcase fits neatly into the alcove .
	- 书架正好放得进壁凹。
# 形态
- #形态/word_pl alcoves
