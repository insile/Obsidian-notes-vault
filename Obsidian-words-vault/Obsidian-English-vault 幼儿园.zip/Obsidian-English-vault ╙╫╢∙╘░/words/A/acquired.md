---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈkwaɪəd/； 美：/əˈkwaɪərd/
- #词性/v  (通过努力、能力、行为表现)获得；得到；购得
- #词性/adj  已获得的；习得的；已成习惯的
# 例句
- She soon acquired a reputation as a first-class cook .
	- 她不久就获得了顶级厨师的名声。
- He acquired a law degree by taking classes at night
	- 他通过读夜校获得了法律学位。
- She has acquired a good knowledge of English .
	- 她英语已经学得很好。
# 形态
- #形态/word_proto acquire
