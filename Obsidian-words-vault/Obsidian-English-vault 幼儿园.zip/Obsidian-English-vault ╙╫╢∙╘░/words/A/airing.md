---
tags:
  - 首字母/A
  - 级别/雅思
掌握: false
模糊: false
---
# 词义
- 英：/ˈeərɪŋ/； 美：/ˈerɪŋ/
- #词性/n  晾；晾晒；透风；(意见等的)公开发表，公开讨论
- #词性/v  (使)通风，透风；晾干；晾；公开发表
# 例句
- The sheets for your bed will want airing , I suppose .
	- 我想，你的床单需要晾晒一下了。
- The slip-preventing hook is used for airing clothes in daily life .
	- 本实用新型用于日常生活晾晒衣服上。
- Ensure there is a free flow of air around the machine .
	- 要确保机器周围空气畅通。
# 形态
- #形态/word_proto air
