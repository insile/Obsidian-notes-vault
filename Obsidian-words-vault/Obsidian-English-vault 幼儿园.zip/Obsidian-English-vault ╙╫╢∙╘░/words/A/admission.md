---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ədˈmɪʃn/； 美：/ədˈmɪʃn/
- #词性/n  (尤指对过错、罪行的)承认，招认，招供；入场费；准许进入；门票费；(机构、组织等的)准许加入，加入权，进入权
# 例句
- The company 's silence on the subject has been taken as an admission of guilt .
	- 在外界看来，公司在这个问题上保持沉默便是承认有罪。
- The minister 's resignation was an admission that she had lied .
	- 这位部长辞职等于承认她自己撒过谎。
- Hospital admission is not necessary in most cases .
	- 大多数情况下，病人无须住院。
# 形态
- #形态/word_pl admissions
