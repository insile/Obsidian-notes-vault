---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈædvɜːt/； 美：/ˈædvɜːrt/
- #词性/v  注意
- #词性/n  广告；宣传；(电视上的)广告时间
- #词性/vi  提到；引起注意
# 例句
- Imaginary beam settings must advert the issue in structural analysis
	- 结构分析中虚梁设置必须注意的问题
- Application and Advert Proceeding of Cutting Tool Radius Compensatory Function
	- 刀具半径补偿功能的应用及注意事项
- A quick trawl through the newspapers yielded five suitable job adverts .
	- 快速翻阅一下报纸便找到五则适合的招聘广告。
# 形态
- #形态/word_third adverts
- #形态/word_ing adverting
- #形态/word_done adverted
- #形态/word_pl adverts
- #形态/word_past adverted
