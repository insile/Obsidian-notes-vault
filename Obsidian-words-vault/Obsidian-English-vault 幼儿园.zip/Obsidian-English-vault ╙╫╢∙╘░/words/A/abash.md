---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性/v  使惭愧；使羞愧；使困窘；使局促不安
- #词性/n  窘迫；尴尬
# 例句
- " All right ," said the latter , somewhat abashed , it might be well to do it .
	- “好吧，”导演有点窘迫地说，这样也好。
- He was not at all abashed by his position .
	- 他一点儿也不为自己的处境感到窘迫。
- He looked abashed , uncomfortable .
	- 他看起来有点困窘，很不自在。
# 形态
- #形态/word_third abashes
- #形态/word_done abashed
- #形态/word_ing abashing
- #形态/word_past abashed
