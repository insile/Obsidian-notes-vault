---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈɡɒɡ/； 美：/əˈɡɑːɡ/
- #词性/adj  兴奋；急切了解；兴奋期待
- #词性/adv  渴望；极度兴奋
# 例句
- The city was agog with rumours last night that the two had been executed .
	- 那两人已被处决的传言昨晚搞得全城沸沸扬扬。
- We waited agog for the next part of his story .
	- 我们急切地等他讲下一段故事。
- They are all agog to know the news about the World Cup .
	- 他们都渴望获知有关世界杯足球赛的消息。
