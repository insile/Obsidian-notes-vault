---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/əˈtʃiːv/； 美：/əˈtʃiːv/
- #词性/v  实现；(凭长期努力)达到(某目标、地位、标准)；完成；成功
# 例句
- The college 's aim is to help students achieve their aspirations .
	- 大学的目标是帮助学生实现他们的抱负。
- There are many who will work hard to achieve these goals
	- 有志之士将会共同为实现这些目标而努力。
- They had achieved a lot in a short space of time .
	- 他们在短时间内取得了很大的成绩。
# 形态
- #形态/word_third achieves
- #形态/word_ing achieving
- #形态/word_done achieved
- #形态/word_past achieved
