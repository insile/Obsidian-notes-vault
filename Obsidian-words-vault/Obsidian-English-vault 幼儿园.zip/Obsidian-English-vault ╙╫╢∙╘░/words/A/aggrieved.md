---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈɡriːvd/； 美：/əˈɡriːvd/
- #词性/adj  受害的；委屈；愤愤不平的；感到受委屈的
- #词性/v  使委屈；侵害；使悲痛；冤枉；侵犯…的合法权利
# 例句
- I really feel aggrieved at this sort of thing .
	- 我真为这种事感到委屈。
- She is the aggrieved person whose fiance & 1 & did not show up for their wedding .
	- 她很委屈，她的未婚夫未出现在他们的婚礼上
- His tone was by turns angry and aggrieved .
	- 他的语气时而透着愤怒，时而流露出哀怨。
# 形态
- #形态/word_proto aggrieve
