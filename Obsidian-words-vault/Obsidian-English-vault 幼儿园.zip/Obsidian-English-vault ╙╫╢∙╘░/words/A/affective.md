---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈfektɪv/； 美：/əˈfektɪv/
- #词性/adj  情感的；感情的
# 例句
- The classroom teaching effect of teachers ' affective factors were analyzed on the basis of in classroom teaching , negative affective into the causes are analyzed and summarized .
	- 本部分在对课堂教学中影响教师感情的因素进行分析的基础上，对课堂教学中教师消极感情形成的具体原因进行了剖析和归纳。
- Affective Functions and Roles in Foreign Language Learning
	- 情感的功能及其在语言学习中的作用
- He 'd like ' happiness ' to be given a new and more scientifically descriptive label , to wit ' Major affective disorder , pleasant type ' .
	- 他想给“幸福”一个更为科学的新称谓，准确地说即“愉悦型重度情感障碍”。
