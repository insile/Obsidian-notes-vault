---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- #词性/adj  声学的；有声的；传音的；音响的；听觉的
# 例句
- Walls tilted for acoustical reasons may cause glare .
	- 对声学的原因可能会造成眩光墙倾斜。
- Research of acoustical environment of classrooms is a current hotspot in architectural acoustics .
	- 教室室内声学问题是当前建筑声学的一个研究热点。
- This system can set up acoustical resonances .
	- 这种系统能产生共鸣
