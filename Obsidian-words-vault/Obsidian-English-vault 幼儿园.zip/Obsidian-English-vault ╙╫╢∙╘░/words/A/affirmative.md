---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈfɜːmətɪv/； 美：/əˈfɜːrmətɪv/
- #词性/adj  肯定的；积极的；同意的
- #词性/n  肯定；同意；肯定词；赞成的一方
- #词性/int  是的；对的
# 例句
- She answered in the affirmative .
	- 她作出了肯定的答复。
- He asked me if I was ready . I answered in the affirmative .
	- 他问我是否准备好了，我给出肯定的回答。
- Seventy-nine voted in the affirmative , and none in the negative .
	- 79人投赞成票，没有人投反对票。
# 形态
- #形态/word_pl affirmatives
