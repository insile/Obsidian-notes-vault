---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈdʒendə/； 美：/əˈdʒendə/
- #词性/n  议程；议事日程；(会议的)议程表
# 例句
- The next item on the agenda is the publicity budget .
	- 议程表上的下一项是宣传预算。
- I suggest we skip to the last item on the agenda .
	- 我建议我们跳到议程的最后一项。
- In our company , quality is high on the agenda .
	- 我们公司高度重视质量。
# 形态
- #形态/word_proto agendum
- #形态/word_pl agendas
