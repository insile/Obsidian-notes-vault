---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈdɑːdʒiəʊ/； 美：/əˈdɑːdʒioʊ/
- #词性/n  柔板；柔板乐章
- #词性/adv  【乐】缓慢地
- #词性/adj  【乐】缓慢的
# 例句
- The tempo marking in most cases is andante , adagio , or largo .
	- 大多数第一乐章的速度标记是行板、柔板或广板。
- It has the most unusual first solo entrance , not with the allegro main theme , but with an adagio introduction , unfolding a lovely new musical idea .
	- 独奏者的第一次加入最不寻常，他演奏的不是快板的主题，而是一个柔板的引子，这就展开了一个优美的新音乐理念。
- Preparation and Properties of TiO_2 Powder for Adagio Display Display Devices
	- 柔版显示器件用TiO2粉体的制备与性能
# 形态
- #形态/word_pl adagios
