---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈfɔːdəbl/； 美：/əˈfɔːrdəbl/
- #词性/adj  负担得起的；价格合理的；买得起的
# 例句
- Exorbitant housing prices have created an acute shortage of affordable housing for the poor .
	- 过高的房价已经造成了穷人能够买得起的住房严重短缺。
- Affordable housing ; an affordable risk .
	- 买得起的住房；承担得起的风险。
- Homes are more affordable than at any time in the past five years
	- 现在住宅比过去5年里的任何时候都要便宜。
