---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- #词性缺失 倡导者；拥护者；提倡者；鼓吹者；辩护者
# 例句
- The officials were the advocator and guide of Han culture .
	- 流官是汉文化的倡导者、引导者。
- America is an advocator of hegemonic stability model .
	- 美国是霸权稳定模式的积极倡导者。
- Shenzhen Government , Advocator of Enterprises ' Social Responsibility
	- 深圳政府推动企业履行社会责任
