---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈækrənɪm/； 美：/ˈækrənɪm/
- #词性/n  缩略语；首字母缩略词(如Aids系由acquired immune deficiency syndrome的首字母组成)
# 例句
- The acronym MINT was popularized by Jim O ' Neill , a British economist5 best known for coining its predecessor6 , the term BRIC .
	- MINT这个缩略语由首创“金砖四国”（BRIC）提法的英国经济学家吉姆·奥尼尔提出并广泛传播。
- you know , I think it 's very cool how it 's also an acronym , you know ,
	- 这居然还是个缩略语，真是太酷了
- TSDF is an acronym for Treatment , Storage and Disposal Facilities.TSDF
	- 是处理，储存和处置设施的一个缩写。
# 形态
- #形态/word_pl acronyms
