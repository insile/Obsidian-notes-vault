---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈæktrəs/； 美：/ˈæktrəs/
- #词性/n  女演员
# 例句
- He was very frank about his relationship with the actress .
	- 他对自己和那位女演员的关系直言不讳。
- The actress described the photographs of her as an invasion of privacy .
	- 那位女演员认为她的这些照片是对隐私权的侵犯。
- She has that indefinable something that makes an actress a star .
	- 她具备了那种使演员成为明星的说不出的特质。
# 形态
- #形态/word_pl actresses
