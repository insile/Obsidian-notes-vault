---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˌkædəˈmɪʃn/； 美：/ˌækədəˈmɪʃn/
- #词性/n  院士；学会会员
# 例句
- A Study of the Academician System of Social Sciences in New China
	- 关于新中国社会科学院士制度问题的研究
- Learning from America and Reforming the Chinese Academician System
	- 借鉴美国经验改革我国院士制度
- So many academicians do much work in this field and make many achievements .
	- 因此无数学者对文本聚类和分类做了大量的研究工作，取得了不错的成绩。
# 形态
- #形态/word_pl academicians
