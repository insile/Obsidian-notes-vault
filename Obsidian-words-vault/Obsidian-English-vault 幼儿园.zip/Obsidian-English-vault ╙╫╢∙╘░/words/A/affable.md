---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈæfəbl/； 美：/ˈæfəbl/
- #词性/adj  和蔼可亲；平易近人的
# 例句
- She is affable to everyone .
	- 她对每一个人都和蔼可亲。
- He is composed , urbane , and affable .
	- 他举止大方，文质彬彬，和蔼可亲。
- He was affable at one moment , choleric the next .
	- 他一会儿还和蔼可亲，可一转眼就火冒三丈。
