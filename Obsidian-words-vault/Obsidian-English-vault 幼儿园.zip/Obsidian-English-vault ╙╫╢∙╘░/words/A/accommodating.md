---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈkɒmədeɪtɪŋ/； 美：/əˈkɑːmədeɪtɪŋ/
- #词性/adj  乐于助人的；与人方便的
- #词性/v  容纳；考虑到；顾及；为…提供空间；为(某人)提供住宿(或膳宿、座位等)
# 例句
- In my breed we are becoming hard pressed to find intact males living with accommodating owners .
	- 在我们这一带繁殖的种群当中已经很难找到健全的公犬与乐于助人的犬主了。
- All sites are capable of accommodating a spa resort development .
	- 所有地点均可容纳一个水疗及消闲度假设施发展项目。
- I needed to accommodate to the new schedule .
	- 我需要适应新的时间表。
# 形态
- #形态/word_proto accommodate
