---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ədˈmɪnɪstrətɪv/； 美：/ədˈmɪnɪstreɪtɪv/
- #词性/adj  行政的；管理的
# 例句
- An Analysis of the Current Reform of Ideas of the Public Administrative Management in China
	- 论当前中国公共管理的观念变革
- These are in subjects like computer programming , public relations and administrative work .
	- 这些一般是计算机编程，公共关系和管理的课程。
- I spend a lot of my time on administrative duties .
	- 我在行政管理事务上花了大量时间。
