---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ədˈvɜːsəti/； 美：/ədˈvɜːrsəti/
- #词性/n  逆境；困境
# 例句
- They had to struggle against all kinds of adversity
	- 他们不得不同一切困境做斗争。
- The fire is the test of gold ; adversity of strong man .
	- 烈火炼真金，困境出好汉。
- He overcame many personal adversities .
	- 他克服了多次个人不幸。
# 形态
- #形态/word_pl adversities
