---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˈɔːldə(r)/； 美：/ˈɔːldər/
- #词性/n  桤木(多见于北方国家潮湿地区)
# 例句
- He gave john some alder bark .
	- 他给了约翰一些桤木树皮。
- The Impact of PEG Treatment on Seed Vigor of Two Alder Species
	- PEG处理对两种桤木种子发芽的影响
- Study on Prepare Process for Alder Wood Polymer Composite
	- 西南桤木木塑复合材料处理工艺的研究
# 形态
- #形态/word_pl alders
