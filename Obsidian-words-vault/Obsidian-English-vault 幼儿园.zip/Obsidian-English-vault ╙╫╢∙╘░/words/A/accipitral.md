---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性缺失 鹰的；鹰似的；贪婪凶猛的
# 例句
- Accipitral renascence , it is the environment that a business fits internationalization actually , it is a natural decay , be a kind of new capacity build , still be among this process .
	- 鹰的重生，实际上是一个企业适应国际化的环境，是一个自然的蜕变，是一种新的能力的建立，还在这个过程当中。
- Leon 's boss , the Facebook good friend that also is him turns this information of Leon to accipitral team manager of a client , the result is Leon was fried squid .
	- 利昂的老板，也是他的Facebook好友把利昂的这条信息转给了鹰队一位客户经理，结果是利昂被炒了鱿鱼。
