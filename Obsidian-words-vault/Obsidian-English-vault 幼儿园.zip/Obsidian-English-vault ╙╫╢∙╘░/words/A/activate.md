---
tags:
  - 首字母/A
  - 级别/考研
  - 级别/六级
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈæktɪveɪt/； 美：/ˈæktɪveɪt/
- #词性/vt  使活动；激活；使活化
# 例句
- Now they are trying to figure out what molecular signaling processes activate those seed-building genes in resurrection plants — and how to reproduce them in crops .
	- 如今，她们正试图弄清楚哪些分子信号转导过程激活了复苏植物的种子发育基因——以及如何将其复制到农作物上。
- Once you have enough obsidian , activate the idols .
	- 一旦你有足够的黑曜石，激活神像。
- The gene is activated by a specific protein .
	- 这种基因由一种特异性蛋白激活。
# 形态
- #形态/word_third activates
- #形态/word_ing activating
- #形态/word_done activated
- #形态/word_past activated
