---
tags:
  - 首字母/A
  - 级别/考研
  - 级别/六级
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈædvent/； 美：/ˈædvent/
- #词性/n  (重要事件、人物、发明等的)出现；到来；将临节，基督降临节(圣诞节前的四个星期)
# 例句
- The advent of war led to a greater austerity .
	- 战争的到来使形势更为严峻。
- Deptford had come alive with the advent of the new priest at St Paul 's.
	- 圣保罗教堂新牧师的到来使德特福德变得生机勃勃。
- Since the advent of jet aircraft , travel has been accelerated .
	- 自喷气式飞机出现以来，旅行的速度得到提高。
