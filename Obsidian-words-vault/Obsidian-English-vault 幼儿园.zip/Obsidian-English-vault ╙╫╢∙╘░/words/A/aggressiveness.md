---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- #词性/n  侵略性；腐蚀性；进攻性，侵占性，（杂草）侵入；（家畜行为）霸道，侵犯
# 例句
- 4 ) A new signaling frame , Beam Pattern Change ( BPC ) frame , is adopted in order to release the protocol aggressiveness .
	- 4）增加了一条新的信令帧BPC（BeamPatternChange）帧，用于进一步释放协议积极性。
- We had , she said , inadvertently brought out Nina 's aggressiveness .
	- 她说，我们浑然不觉地激发出了妮娜的进攻性。
- Nerve , ideas , aggressiveness , how these counted when one had luck !
	- 一个人交运的时候，勇气，主意，进取心这些东西是何等重要啊！
