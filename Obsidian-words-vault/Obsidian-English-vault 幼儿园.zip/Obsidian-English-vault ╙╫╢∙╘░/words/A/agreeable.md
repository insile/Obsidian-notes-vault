---
tags:
  - 首字母/A
  - 级别/考研
  - 级别/六级
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈɡriːəbl/； 美：/əˈɡriːəbl/
- #词性/adj  令人愉快的；宜人的；讨人喜欢的；愉悦的；适合的；可以接受的；欣然同意
# 例句
- For my part , I think they are vastly agreeable , provided they dress smart and behave civil .
	- 对我来说，我认为如果他们穿着漂亮，举止文明，倒是非常令人愉快的。
- My idea of an agreeable person is a person who agrees with me .
	- 我认为“令人愉快的人”就是与我合得来的人。
- Do you think they will be agreeable to our proposal ?
	- 你认为他们会爽快同意我们的提议吗？
