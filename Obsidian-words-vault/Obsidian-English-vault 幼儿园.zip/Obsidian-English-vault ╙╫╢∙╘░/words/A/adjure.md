---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈdʒʊə(r)/； 美：/əˈdʒʊr/
- #词性/vt  要求；命令
# 例句
- I adjure you to tell the truth before this court .
	- 我要求你对本庭说实话。
- He adjured them to tell the truth .
	- 他要求他们讲真话。
- For water injection oilfield , water injection profile date is very important to dynamic analyzing and adjuring water injection .
	- 对于注水开发油田，吸水剖面是油田动态分析和注水调整的重要依据。
# 形态
- #形态/word_third adjures
- #形态/word_ing adjuring
- #形态/word_done adjured
- #形态/word_past adjured
