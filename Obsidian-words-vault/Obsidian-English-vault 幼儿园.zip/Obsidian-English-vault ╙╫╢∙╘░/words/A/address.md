---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/əˈdres/； 美：/əˈdres/
- #词性/n  (互联网等的)地址；住址；演讲；演说；称呼；通信处
- #词性/vt  演讲；演说；称呼（某人）；致函；设法解决；向…说话；写(收信人)姓名地址
# 例句
- Print your name and address clearly in the space provided .
	- 请用印刷体在空白处填写你的姓名和住址。
- Make sure you get your mail redirected to your new address .
	- 注意一定要让你的邮件改投到你的新住址。
- We must address ourselves to the problem of traffic pollution .
	- 我们必须设法解决交通污染问题。
# 形态
- #形态/word_third addresses
- #形态/word_ing addressing
- #形态/word_done addressed
- #形态/word_pl addresses
- #形态/word_past addressed
