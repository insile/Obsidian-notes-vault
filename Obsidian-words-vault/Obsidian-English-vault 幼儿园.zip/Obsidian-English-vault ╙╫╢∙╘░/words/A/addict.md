---
tags:
  - 首字母/A
  - 级别/考研
  - 级别/六级
  - 级别/雅思
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈædɪkt/； 美：/ˈædɪkt/
- #词性/n  瘾君子；吸毒成瘾的人；对…入迷的人
- #词性/vt  使沉溺；使上瘾；使自己沾染（某些恶习）
# 例句
- She was a drug addict .
	- 她是个吸毒成瘾的人。
- He 's only 24 years old and a drug addict .
	- 他只有24岁，却是个瘾君子。
- He 's addicted to computer games .
	- 他迷上了电脑游戏。
# 形态
- #形态/word_third addicts
- #形态/word_ing addicting
- #形态/word_done addicted
- #形态/word_pl addicts
- #形态/word_past addicted
