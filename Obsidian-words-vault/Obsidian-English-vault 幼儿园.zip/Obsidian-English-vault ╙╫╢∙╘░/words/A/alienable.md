---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˈeɪliənəbl/； 美：/ˈeɪliənəbl/
- #词性/adj  可转让的；可让渡的
# 例句
- And legal translation , to some extent , is a kind of cultural exchange between alienable legal systems .
	- 法律翻译不仅是异域法律语言的符号转换，而且在某种程度上也是不同法律文化之间的交流。
- At common law , the right of re-entry is not alienable , assignable , or devisable .
	- 普通法上，收回权是不可流转、转让或遗赠的。
- This article that is based on it studies the alienable phenomena of human association and the reasons more deeply , and tries to pursue an ultimate gateway to eliminate the alienation of human association in Chinese contemporary society .
	- 本文正是以此为基点，进一步探讨了人情交往的异化现象及其成因，并试图为当代中国社会寻求一条消解人情交往异化的根本途径。
