---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbeɪtmənt/； 美：/əˈbeɪtmənt/
- #词性/n  减少；减轻；减弱
# 例句
- The abatement of the headache gave him a moment of rest .
	- 头痛减轻给他片刻的休息。
- Analysis of the effect of noise abatement in urban green areas
	- 城市绿地减弱噪声效果分析
- Research on Air Pollution Abatement Cost Function of Industrial Enterprise
	- 工业企业大气污染治理费用函数的研究
