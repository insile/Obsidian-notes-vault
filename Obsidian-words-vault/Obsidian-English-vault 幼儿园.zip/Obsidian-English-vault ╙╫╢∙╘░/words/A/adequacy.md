---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈædɪkwəsi/； 美：/ˈædɪkwəsi/
- #词性/n  充足；适当；足够；恰当
# 例句
- I am very critical of the adequacy of Britain 's race laws
	- 我对英国种族法律的适当性颇有微词。
- It is in these areas where the adequacy of our performance must be measured .
	- 正是在这些领域中，必须评价我们业绩的适当性。
- The adequacy of the security arrangements has been questioned .
	- 有人质疑安全措施是否充分。
# 形态
- #形态/word_pl adequacies
