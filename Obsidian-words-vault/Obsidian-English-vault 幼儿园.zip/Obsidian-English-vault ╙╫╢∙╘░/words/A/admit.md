---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ədˈmɪt/； 美：/ədˈmɪt/
- #词性/v  承认(过错、罪行)；招认；准许…进入(某处)；招供；准许…加入（俱乐部、组织）；接收入院
# 例句
- I must admit I was surprised it cost so little .
	- 我得承认，这么便宜，真让我惊讶。
- They freely admit they still have a lot to learn .
	- 他们坦率承认，他们要学的东西还很多。
- Women were only admitted into the club last year .
	- 这家俱乐部去年才接纳女会员。
# 形态
- #形态/word_third admits
- #形态/word_ing admitting
- #形态/word_done admitted
- #形态/word_past admitted
