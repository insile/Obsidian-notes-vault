---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/æbˈstræktɪd/； 美：/æbˈstræktɪd/
- #词性/adj  出神的；心神专注的
- #词性/v  提取；抽取；分离；把…抽象出；写出(书等的)摘要
# 例句
- In the end he abstracted the most important point from his long speech .
	- 最后他从自己的长篇演说中提取出最重要的几点。
- First , the image edge information is abstracted and the coefficient is modified .
	- 先提取图像的边缘信息，进行系数修正；
- We may talk of beautiful things but beauty itself is abstract .
	- 我们尽可谈论美的事物，但美本身却是抽象的。
# 形态
- #形态/word_proto abstract
