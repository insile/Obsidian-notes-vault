---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈæbdɪkeɪt/； 美：/ˈæbdɪkeɪt/
- #词性/v  退位；放弃(职责)；逊位；失(职)
# 例句
- His declining health added weight to speculation that the king would soon abdicate .
	- 国王日益恶化的健康状况加强了人们对他即将退位的猜测。
- He chose to abdicate rather than mar the image of the monarchy .
	- 因此，为了维护统治者的形象，爱德华选择了退位。
- She was forced to abdicate the throne of Spain .
	- 她被迫让出西班牙的王位。
# 形态
- #形态/word_third abdicates
- #形态/word_ing abdicating
- #形态/word_done abdicated
- #形态/word_past abdicated
