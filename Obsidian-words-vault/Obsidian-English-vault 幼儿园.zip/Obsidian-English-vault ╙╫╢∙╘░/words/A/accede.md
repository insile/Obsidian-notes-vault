---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əkˈsiːd/； 美：/əkˈsiːd/
- #词性/v  同意(请求、建议等)；就任；(尤指君主)即位；就职
# 例句
- Britain would not accede to France 's request .
	- 英国不肯同意法国的要求。
- I never understood why he didn 't just accede to our demands at the outset .
	- 我一直搞不懂他为什么不一开始就同意我们的要求。
- Queen Victoria acceded to the throne in 1837 .
	- 维多利亚女王于1837年即位。
# 形态
- #形态/word_third accedes
- #形态/word_ing acceding
- #形态/word_done acceded
- #形态/word_past acceded
