---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈkaʊntɪŋ/； 美：/əˈkaʊntɪŋ/
- #词性/n  会计
- #词性/v  认为是；视为
# 例句
- Most large companies now use computers for accounting and housekeeping operations .
	- 多数大公司现在用计算机进行会计运算和内务操作。
- An understanding of accounting techniques is a major requisite for the work of the analysts .
	- 懂得会计知识是从事分析员工作的一个必要条件。
- I 'd like to pay some money into my account .
	- 我想在我的账户里存一些钱。
# 形态
- #形态/word_proto account
