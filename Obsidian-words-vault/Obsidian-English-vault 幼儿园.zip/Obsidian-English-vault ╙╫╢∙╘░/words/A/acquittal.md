---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈkwɪtl/； 美：/əˈkwɪtl/
- #词性/n  无罪释放；宣告无罪；无罪的判决
# 例句
- Robinson 's acquittal was met with public outrage . Many felt that the legal system , in the end , viewed Robinson 's life as one of more value than that of Helen 's.
	- 罗宾逊的无罪释放激起了公愤，很多人认为，法律最终将罗宾逊的性命看得比海伦的重要。
- In the end , a jury voted for acquittal , and Maria walked free .
	- 最终陪审团投票决定将其无罪释放，玛利亚也重获自由。
- The case resulted in an acquittal .
	- 此案件最终作出无罪判决。
# 形态
- #形态/word_pl acquittals
