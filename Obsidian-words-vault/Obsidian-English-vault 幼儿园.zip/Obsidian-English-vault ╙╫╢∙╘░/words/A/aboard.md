---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈbɔːd/； 美：/əˈbɔːrd/
- #词性/adv #词性/prep  在(船、飞机、公共汽车、火车等)上；上(船、飞机、公共汽车、火车等)；在船上
# 例句
- They were all aboard the ship last night .
	- 昨天夜里他们都在船上。
- The data are normally measured aboard by transmitting them via an electric cable .
	- 一般用一条电缆做传输系统，就可以在船上进行数据测量。
- He was already aboard the plane .
	- 他已经登机了。
