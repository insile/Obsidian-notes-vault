---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˌækəˈdemɪk/； 美：/ˌækəˈdemɪk/
- #词性/adj  学术的(与实践性、技术性相对)；学业的；教学的(尤指与学校教育有关)；纯理论的；学习良好的
- #词性/n  高等院校教师；高校科研人员
# 例句
- The author has settled for a more academic approach
	- 那位作者已确定采用更为学术的方法。
- Different schools teach different types of syllabus , from the highly academic to the broadly vocational .
	- 不同的学校有不同的教学计划，从高度学术的到普通职业教育的，不一而足。
- She doesn 't fit the traditional mould of an academic .
	- 她不像一个传统的学者。
# 形态
- #形态/word_pl academics
