---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈkɔːdɪŋ tə/； 美：/əˈkɔːrdɪŋ tə/
- #词性/prep  根据；按照；按(…所报道)；依照；据(…所说)
# 例句
- According to Mick , it 's a great movie .
	- 据米克说，这是一部了不起的电影。
- According to observers , the plane exploded shortly after take-off .
	- 据目击者说，飞机起飞后不久就爆炸了。
- Number the car 's features from 1 to 10 according to importance .
	- 将车的特征从1到10编号按重要性一一列出。
