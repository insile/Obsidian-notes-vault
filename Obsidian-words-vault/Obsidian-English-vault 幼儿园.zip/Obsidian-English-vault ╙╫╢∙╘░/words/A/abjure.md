---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əbˈdʒʊə(r)/； 美：/əbˈdʒʊr/
- #词性/vt  放弃；公开保证放弃；声明放弃(信念、行为、活动)
# 例句
- They were compelled to abjure their faith .
	- 他们被迫发誓放弃自己的信仰。
- The conqueror tried to make the natives abjure their religion .
	- 征服者试著让当地人宣誓放弃他们的宗教。
- He abjured the Protestant faith and became King in 1594 .
	- 他放弃了新教信仰，于1594年登基为王。
# 形态
- #形态/word_third abjures
- #形态/word_ing abjuring
- #形态/word_done abjured
- #形态/word_past abjured
