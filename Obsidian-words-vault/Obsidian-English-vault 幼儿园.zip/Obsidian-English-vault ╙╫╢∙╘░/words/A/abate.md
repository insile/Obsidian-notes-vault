---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbeɪt/； 美：/əˈbeɪt/
- #词性/v  (使)减弱，减退，减轻，减少；撤销, 废除, 消除
# 例句
- The doctor gave him some medicine to abate the powerful pain .
	- 医生给了他一些药，以减弱那剧烈的疼痛。
- Today , these primary endowment way appeared function abate in different degrees .
	- 如今，这些养老方式不同程度的出现了功能减弱。
- Steps are to be taken to abate pollution .
	- 应该采取措施减少污染。
# 形态
- #形态/word_third abates
- #形态/word_ing abating
- #形态/word_done abated
- #形态/word_past abated
