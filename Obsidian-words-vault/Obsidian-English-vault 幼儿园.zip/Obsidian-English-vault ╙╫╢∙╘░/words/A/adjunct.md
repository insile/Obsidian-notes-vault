---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈædʒʌŋkt/； 美：/ˈædʒʌŋkt/
- #词性/n  辅助；附件；附属物；附加语；修饰成分
- #词性/adj  附属的 (to；of)
# 例句
- Physical therapy is an important adjunct to drug treatments
	- 物理疗法是戒毒治疗中的一种重要辅助性疗法。
- This course will be an important adjunct to the professional training .
	- 这门课是职业训练的重要的辅助课。
- The memory expansion cards are useful adjuncts to the computer .
	- 内存扩充卡是计算机很有用的附件。
# 形态
- #形态/word_pl adjuncts
