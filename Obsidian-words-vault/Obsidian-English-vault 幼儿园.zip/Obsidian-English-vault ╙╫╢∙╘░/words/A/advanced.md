---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ədˈvɑːnst/； 美：/ədˈvænst/
- #词性/adj  先进的；高级的；(发展)晚期的，后期的；高等的
- #词性/v  (知识、技术等)发展，进步；(为了进攻、威胁等)前进，行进；促进；推动
# 例句
- All the more technically advanced countries put a high value on science
	- 所有技术上较先进的国家都高度重视科学。
- The top secret documents had to do with the most advanced military equipment
	- 绝密文件涉及最先进的军事装备。
- There were only three of us on the advanced course .
	- 只有我们三人学高级课程。
# 形态
- #形态/word_proto advance
- #形态/word_est most advanced
- #形态/word_er more advanced
