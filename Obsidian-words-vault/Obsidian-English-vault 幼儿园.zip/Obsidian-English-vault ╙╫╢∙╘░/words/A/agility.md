---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈdʒɪlɪti/； 美：/əˈdʒɪləti/
- #词性/n  灵敏性；敏捷；灵活；机敏；敏捷性
# 例句
- He had the agility of a man half his age .
	- 他的敏捷赶得上岁数比他小一半的人。
- With her speed and agility , cage cut out all her competitors in the hurdle race .
	- 凯奇跨栏时速度快，动作敏捷，击败了其他所有选手。
- Walking up last to the boy , he felt of his arms , straightened his hands , and looked at his fingers , and made him jump , to show his agility .
	- 最后，走到孩子面前，摸摸他的胳膊，扳开他的手掌来看了看他的手指头，又叫他跳了几下，试试他灵活不灵活。
