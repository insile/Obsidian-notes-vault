---
tags:
  - 首字母/A
  - 级别/考研
  - 级别/六级
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈædvɜːs/； 美：/ədˈvɜːrs/
- #词性/adj  不利的；有害的；反面的
# 例句
- It was an adverse verdict .
	- 这是一个不利的判决。
- However , the use of colour information has some adverse effects on the segmentation .
	- 但颜色信息对实际的分割结果也有不利的影响。
- Modern farming methods can have an adverse effect on the environment .
	- 现代农业耕作方法可能对环境造成负面影响。
