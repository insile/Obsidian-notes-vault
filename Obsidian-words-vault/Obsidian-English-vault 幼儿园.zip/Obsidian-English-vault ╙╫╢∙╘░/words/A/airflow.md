---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˈeəfləʊ/； 美：/ˈerfloʊ/
- #词性/n  (运行中的飞机或汽车周围的)气流
# 例句
- Snoring happens when your airflow becomes partially1 blocked .
	- 当呼吸气流局部受阻，你就会打呼。
- Study on the Airflow Level Posture Sensor with Three Wire Structure
	- 三丝结构气流式水平姿态传感器的研究
- The design of the low - temperature airflow center system
	- 中央空调低温送风的系统设计方法
# 形态
- #形态/word_pl airflows
