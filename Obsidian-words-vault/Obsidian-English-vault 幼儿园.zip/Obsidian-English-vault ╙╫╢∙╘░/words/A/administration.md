---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ədˌmɪnɪˈstreɪʃn/； 美：/ədˌmɪnɪˈstreɪʃn/
- #词性/n  (企业、学校等的)行政；管理；（尤指美国）政府；执行；(企业、学校等的)行政部门；(企业、学校等的)管理部门；（药物的）施用；施行
# 例句
- He has a Master 's in Business Administration .
	- 他获得了工商管理硕士学位。
- I work in the Sales Administration department .
	- 我在销售管理部门工作。
- I 'm afraid our needs do not rate very high with this administration .
	- 我们的需求恐怕不会受到这届政府的多大重视。
# 形态
- #形态/word_pl administrations
