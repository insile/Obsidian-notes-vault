---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˈeəstriːm/； 美：/ˈerstriːm/
- #词性/n  (尤指强烈的)气流
# 例句
- Numerical simulation on influence of diffusion performance on airstream distribution in a room
	- 风速对室内气流分布影响的数值仿真
- A rather cold north west airstream will cover our province .
	- 一股偏冷的西北气流将覆盖我省。
- Parameter evaluation for a high density airstream transport at vacuum condition
	- 真空密相气力输送参数估值
