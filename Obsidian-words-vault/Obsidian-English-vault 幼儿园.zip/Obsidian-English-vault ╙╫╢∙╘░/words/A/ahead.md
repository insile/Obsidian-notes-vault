---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈhed/； 美：/əˈhed/
- #词性/adv #词性/adj  提前，预先；在前面，朝前面；领先，占优势；在将来，今后；赢，有盈余；超前地，超出预期地
# 例句
- We can 't let those goons get too far ahead .
	- 我们不能让那些呆子向前地太远。
- He then sailed ahead in a light vessel but was killed by a stray arrow .
	- 他然后在一艘轻的船中向前地航行但是被一支迷途箭杀了。
- Who took the decision to go ahead with the project ?
	- 是谁决定继续这项工程的？
