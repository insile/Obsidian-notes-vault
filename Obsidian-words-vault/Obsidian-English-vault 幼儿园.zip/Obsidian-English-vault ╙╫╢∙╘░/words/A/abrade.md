---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbreɪd/； 美：/əˈbreɪd/
- #词性/vt  磨损(岩石等)；擦伤(皮肤等)
# 例句
- The skin after trip is met abrade one chunk .
	- 摔倒后皮肤就会擦伤一大块。
- Inside of pockets is to have a surface which will not abrade other printed materials inserted within by end users .
	- 口袋的内部将有将不擦伤在里面被使用者所插入的其他的印刷材料的一个表面。
- The skin of her leg was abraded by the sharp rocks .
	- 她腿上的皮肤被锐利的岩石擦伤了。
# 形态
- #形态/word_third abrades
- #形态/word_ing abrading
- #形态/word_done abraded
- #形态/word_past abraded
