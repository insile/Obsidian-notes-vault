---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈkʌstəmd/； 美：/əˈkʌstəmd/
- #词性/adj  习惯的；习惯于；通常的；惯常的
- #词性/v  使习惯(于)；使适应
# 例句
- But they say don 't go and jump in a cold river hoping to reduce your dementia risk - swimming in cold water can be dangerous for those not accustomed to it .
	- 但是他们说不要跳进冰冷的河里，希望这样可以降低你患痴呆症的风险，因为在冰冷的水中游泳对那些不习惯的人来说是很危险的。
- When we cross cultural barriers in dining , we may miss our accustomed stop signals and end up feeling either hungry or overstuffed .
	- 当我们跨文化就餐时，也许未察觉自己习惯的结束暗示，结果或是没吃饱或是吃得过饱。
- My eyes slowly grew accustomed to the dark .
	- 我的眼睛慢慢适应了黑暗。
# 形态
- #形态/word_proto accustom
