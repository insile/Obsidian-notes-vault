---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/əˈdrenəlɪn/； 美：/əˈdrenəlɪn/
- #词性/n  肾上腺素(情绪激动时肾上腺分泌的一种化学物质，能加快心跳并产生更多能量)
# 例句
- Afterwards , both sets of heart cells were more sensitive to adrenaline , they wrote in the journal Cardiovascular Research .
	- 他们在《心血管研究》杂志发表的文章中称，随后发现，这两组心脏细胞对肾上腺素更敏感。
- The center of these glands manufactures adrenaline .
	- 这些腺的中心分泌肾上腺素
- It 's all that adrenaline rush .
	- 这都是肾上腺冲动造成的。
