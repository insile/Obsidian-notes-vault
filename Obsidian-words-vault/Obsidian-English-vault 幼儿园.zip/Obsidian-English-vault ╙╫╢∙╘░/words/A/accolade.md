---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈækəleɪd/； 美：/ˈækəleɪd/
- #词性/n  荣誉；赞扬；奖励；表扬；奖赏
# 例句
- His new book received accolade from the papers .
	- 他的新书受到报纸的热烈赞扬。
- Tonight , three thousand miles from home , the accolade had resurfaced to haunt him at the lecture he had given .
	- 今晚在离家三千英里处，在他作报告时的赞扬令他惶惶不安。
- The Nobel prize has become the ultimate accolade in the sciences
	- 诺贝尔奖已成为科学界的最高荣誉。
# 形态
- #形态/word_pl accolades
