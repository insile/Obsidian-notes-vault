---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/əˈbʌndəntli/； 美：/əˈbʌndəntli/
- #词性/adv  十分清楚；大量地；充裕地；丰盛地；非常明白；十分地
# 例句
- You 've made yourself abundantly clear .
	- 你已经说得非常明白了。
- Obviously , food , clothing and shelter could be produced abundantly , there is enough scientific knowledge to supply the demand ;
	- 显然，食物、衣物和住所可以充裕地生产，科学知识也使得我们能够充分提供这些生活必需品；
- Calcium is found most abundantly in milk .
	- 奶含钙最丰富。
