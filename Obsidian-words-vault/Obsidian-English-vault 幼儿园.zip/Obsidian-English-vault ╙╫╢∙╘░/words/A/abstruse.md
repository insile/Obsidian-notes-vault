---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əbˈstruːs/； 美：/əbˈstruːs/
- #词性/adj  深奥的；难解的
# 例句
- Facing various abstruse mathematical theories and complex problem-solving methods , laymen have to draw back .
	- 面对各种深奥的数学理论和复杂的数学方法，门外汉往往只好望而却步。
- While Marx philosophical thought is great and profundity , also freedom is an abstruse problem in academic fields .
	- 但由于马克思哲学思想的博大精深，加之由于自由问题是一个学术上较为深奥的问题。
- The involved and abstruse passage makes several interpretations possible .
	- 这段艰涩的文字可以作出好几种解释。
