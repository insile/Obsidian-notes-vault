---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˌækwɪˈzɪʃn/； 美：/ˌækwɪˈzɪʃn/
- #词性/n  收购；(知识、技能等的)获得，得到；购置；收购的公司；购置物；(多指贵重的)购得物；购置的产业
# 例句
- Knowledge acquisition is to students as production is to workers .
	- 获得知识对于学生来说就像生产对于工人一样重要。
- A Study of Teachers ' Knowledge Based on Teaching Expertise and Acquisition
	- 教师知识的再认识&来自教学专长及其获得研究的启示
- How did you go about making this marvellous acquisition then ?
	- 那么你是怎么买到这一绝品的？
# 形态
- #形态/word_pl acquisitions
