---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/ˈeəpleɪn/； 美：/ˈerpleɪn/
- #词性/n  飞机
# 例句
- They arrived in Belgium by airplane .
	- 他们乘飞机到达比利时。
- The insured value of the airplane was greater than its book value .
	- 该飞机的投保价值高于它的实际账面价值。
- One company is giving its employees airplane tickets in the event they need to make a hasty escape .
	- 一家公司正在给自己的员工发机票，万一需要就紧急撤离。
# 形态
- #形态/word_pl airplanes
