---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈeətaɪt/； 美：/ˈertaɪt/
- #词性/adj  密封的；不透气的
# 例句
- Food will last longer if kept in an airtight container .
	- 如果贮藏在密封的容器里，食物能保持比较久的时间。
- Close airtight lid after each use .
	- 每次使用后关上密封的盖子。
- Store the cake in an airtight container .
	- 把蛋糕存放在密封容器里。
