---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈæbəkəs/； 美：/ˈæbəkəs/
- #词性/n  算盘
# 例句
- The simplest example of this type is the abacus , which has been used in many parts of the world since ancient times .
	- 这一类型中最简单的实例就是世界各地自古以来使用算盘。
- You will have a fun time learning to play the abacus .
	- 您将会非常喜欢学习如何使用算盘。
- The Necessity of Strengthening Calculation with Abacus in High Vocational Education
	- 论加强高职教育中珠算教育的必要性
# 形态
- #形态/word_pl abacuses
