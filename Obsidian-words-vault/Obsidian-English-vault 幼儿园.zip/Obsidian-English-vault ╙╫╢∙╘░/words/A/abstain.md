---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əbˈsteɪn/； 美：/əbˈsteɪn/
- #词性/vi  (投票时)弃权；戒；回避　；戒除；离开
# 例句
- In other words , the country would abstain from a resolution favouring a cease-fire in place .
	- 换言之，对于一项赞同就地停火的协议，那个国家将投弃权票。
- He may abstain or even vote to make abortion illegal .
	- 他可能弃权，尤有甚者投票支持堕胎违法。
- Ten people voted in favour , five against and two abstained .
	- 十人投票赞成，五人反对，两人弃权。
# 形态
- #形态/word_third abstains
- #形态/word_ing abstaining
- #形态/word_done abstained
- #形态/word_past abstained
