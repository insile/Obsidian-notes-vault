---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈdɔːn/； 美：/əˈdɔːrn/
- #词性/vt  装饰；装扮；使生色；使更美观
# 例句
- The pretty girl doesn 't like to adorn herself with jewels .
	- 这位美丽的姑娘不喜欢用珠宝来装饰自己。
- I 'd rather break my heart than adorn your dream .
	- 英文“愿意心痛苦也不装饰你的梦”怎么说？
- The children adorned themselves with flowers .
	- 孩子们佩戴着鲜花。
# 形态
- #形态/word_third adorns
- #形态/word_ing adorning
- #形态/word_done adorned
- #形态/word_past adorned
