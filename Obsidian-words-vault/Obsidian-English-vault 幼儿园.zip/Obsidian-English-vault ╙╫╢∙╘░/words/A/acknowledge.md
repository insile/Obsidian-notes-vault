---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əkˈnɒlɪdʒ/； 美：/əkˈnɑːlɪdʒ/
- #词性/vt  承认(权威、地位)；（公开）感谢；（微笑、挥手等）致意；告知收悉
# 例句
- I did not acknowledge that he had done anything wrong .
	- 我没有承认他犯了什么错。
- She refuses to acknowledge the need for reform .
	- 她拒不承认改革的必要性。
- I would like to acknowledge my debt to my teachers .
	- 我想向我的老师表达我的感激之情。
# 形态
- #形态/word_third acknowledges
- #形态/word_ing acknowledging
- #形态/word_done acknowledged
- #形态/word_past acknowledged
