---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈædʒɪktɪv/； 美：/ˈædʒɪktɪv/
- #词性/n  形容词
- #词性/adj  形容词(性)的；附属的；有关程序的
# 例句
- In " the black cat " the adjective " black " modifies the noun " cat " .
	- 在“theblackcat”这一词组中，形容词“black”修饰名词“cat”。
- This is an adjective .
	- 这是形容词。
- Some adjectives can only be used attributively .
	- 有些形容词只能用作定语。
# 形态
- #形态/word_pl adjectives
