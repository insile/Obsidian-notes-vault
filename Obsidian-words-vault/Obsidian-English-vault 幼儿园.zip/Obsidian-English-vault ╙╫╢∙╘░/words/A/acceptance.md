---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əkˈseptəns/； 美：/əkˈseptəns/
- #词性/n  接受(礼物、邀请、建议等)；同意；认可；接纳(为成员、会员等)；无怨接受（逆境、困境等）
# 例句
- I didn 't know whether to interpret her silence as acceptance or refusal .
	- 我不知该把她的沉默看作是接受还是拒绝。
- Her uncritical acceptance of everything I said began to irritate me .
	- 我说什么她都不论对错一概接受，这倒惹我不耐烦起来。
- Your acceptance into the insurance plan is guaranteed .
	- 你参加保险计划一事已有保证。
# 形态
- #形态/word_pl acceptances
