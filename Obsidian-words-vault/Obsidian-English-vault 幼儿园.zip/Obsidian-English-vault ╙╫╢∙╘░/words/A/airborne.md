---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈeəbɔːn/； 美：/ˈerbɔːrn/
- #词性/adj  空降的；空气传播的；空运的；升空
# 例句
- For one thing , the airborne share of trade is declining as the efficiency of seaborne trade grows .
	- 首先，随着海运贸易效率的提高，空运的贸易份额正在下降。
- Do not leave your seat until the plane is airborne .
	- 飞机升空时不要离开座位。
- Many people are allergic to airborne pollutants such as pollen .
	- 许多人对空气传播的污染物过敏，比如花粉。
