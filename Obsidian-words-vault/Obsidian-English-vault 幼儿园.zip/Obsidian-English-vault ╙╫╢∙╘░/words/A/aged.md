---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/eɪdʒd/； 美：/eɪdʒd/
- #词性/adj  …岁；(统称)老人；年迈的
- #词性/v  (使)成熟，变陈；变老；使变老；使苍老；使显老
- #词性/n  （统称）老人
# 例句
- They have two children aged six and nine .
	- 他们有两个小孩，一个六岁，一个九岁。
- The body is that of a white male aged about 40 .
	- 尸体是一名40岁上下的白人男子。
- They were both only 20 years of age .
	- 他们两人都只有20岁。
# 形态
- #形态/word_proto age
