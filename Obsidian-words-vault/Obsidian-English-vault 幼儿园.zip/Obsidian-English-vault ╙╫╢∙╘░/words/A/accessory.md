---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/əkˈsesəri/； 美：/əkˈsesəri/
- #词性/n  附件；配件；(衣服的)配饰；从犯；附属物；同谋；帮凶
- #词性/adj  辅助的；副的
# 例句
- The Experiment Stress Analysis Method in the Improvement Design of Cable Accessory
	- 改进电缆附件设计的实验应力分析法
- Effect of Value Engineering on the Expense for Developing Fuel Accessory
	- 开展价值工程降低燃油附件研制费用
- The shop is devoted to a new range of accessories .
	- 该商店专营新的一系列配件。
# 形态
- #形态/word_pl accessories
