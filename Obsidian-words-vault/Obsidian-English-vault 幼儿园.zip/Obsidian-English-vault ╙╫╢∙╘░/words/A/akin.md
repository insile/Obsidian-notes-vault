---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈkɪn/； 美：/əˈkɪn/
- #词性/adj  类似的；相似的
# 例句
- One of two or more things that are closely akin .
	- 关系密切的事物：两个或多个同类相似的事物之一。
- And in its stead Rutherford proposed something akin to a planetary system .
	- 而卢瑟福提出的，和行星系统相似的原子结构取而代之。
- What he felt was more akin to pity than love .
	- 他感受到的更像怜悯，而不是爱。
