---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈædvəkeɪt , ˈædvəkət/； 美：/ˈædvəkeɪt , ˈædvəkət/
- #词性/vt  提倡；支持；拥护
- #词性/n  支持者；拥护者；提倡者；辩护律师；出庭辩护人
# 例句
- He was a strong advocate of free market policies and a multi-party system .
	- 他是自由市场政策和多党派制度的坚决拥护者。
- He is a keen advocate of park-and-ride schemes .
	- 他是“停车再换乘”计划的热情拥护者。
- The group does not advocate the use of violence .
	- 该团体不支持使用暴力。
# 形态
- #形态/word_third advocates
- #形态/word_ing advocating
- #形态/word_done advocated
- #形态/word_pl advocates
- #形态/word_past advocated
