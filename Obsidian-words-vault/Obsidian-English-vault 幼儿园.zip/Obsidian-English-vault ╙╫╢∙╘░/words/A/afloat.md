---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/əˈfləʊt/； 美：/əˈfloʊt/
- #词性/adj  (在水上)漂浮；能维持下去；有偿债能力
- #词性/adv  漂浮；传播；在海上；在船上
# 例句
- Three hours is a long time to try to stay afloat in these conditions .
	- 在这样的条件下漂浮3个小时是够久的。
- They talked modestly of their valiant efforts to keep the tanker afloat
	- 他们说起自己设法使油轮漂浮的英勇之举时非常谦虚。
- I had to battle hard just to stay afloat .
	- 我得用力挣扎才能勉强浮住。
