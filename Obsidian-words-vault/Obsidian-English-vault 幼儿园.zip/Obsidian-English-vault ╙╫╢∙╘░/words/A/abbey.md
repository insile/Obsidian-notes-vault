---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˈæbi/； 美：/ˈæbi/
- #词性/n  (曾为大隐修院的)大教堂；(大)隐修院
# 例句
- The Abbey bell tolled for those killed in the war .
	- 大教堂为战争中的死难者鸣钟。
- Elizabeth was crowned in Westminster Abbey on 2 June 1953
	- 伊丽莎白于1953年6月2日在威斯敏斯特大教堂加冕。
- The abbey had been plundered of its valuables .
	- 寺院的珍宝被洗劫一空。
# 形态
- #形态/word_pl abbeys
