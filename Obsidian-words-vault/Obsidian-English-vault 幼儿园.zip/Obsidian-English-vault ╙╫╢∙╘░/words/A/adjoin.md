---
tags:
  - 首字母/A
  - 级别/考研
  - 级别/六级
  - 级别/雅思
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/əˈdʒɔɪn/； 美：/əˈdʒɔɪn/
- #词性/v  邻接；毗连；紧挨
# 例句
- If the enclosing sides adjoin each other , the area should be properly vented .
	- 如果封闭的侧面彼此邻接，该区域要有适当的通风。
- Section of an integrated chip . Adjoin with other sections . Number of inputs , outputs , and pins can be specified .
	- 集成芯片的部分。与其他部分邻接。可以指定输入、输出数目和针脚数。
- The fire rapidly spread to adjoining buildings .
	- 大火迅速蔓延到了邻近的建筑物。
# 形态
- #形态/word_third adjoins
- #形态/word_ing adjoining
- #形态/word_done adjoined
- #形态/word_past adjoined
