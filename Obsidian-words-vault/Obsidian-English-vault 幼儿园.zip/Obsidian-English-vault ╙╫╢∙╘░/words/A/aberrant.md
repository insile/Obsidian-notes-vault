---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/æˈberənt/； 美：/æˈberənt/
- #词性/adj  异常的；反常的；违反常规的
# 例句
- I saw that the insects and spiders were displaying the same kind of aberrant behavior .
	- 我看到昆虫和蜘蛛正在表现出相同反常的行为。
- Many Europeans would certainly like to believe that Iraq was the product of aberrant neo-conservative ideas about foreign policy and that a traditional America lies just around the corner .
	- 许多欧洲人一定希望认为，伊拉克是美国外交政策方面反常的新保守主义观点的产物，偏离了美国的传统。
- Ian 's rages and aberrant behavior worsened .
	- 伊恩的怒气越来越大，反常行为也愈发恶劣。
