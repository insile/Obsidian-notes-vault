---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈkædəmi/； 美：/əˈkædəmi/
- #词性/n  学院；(艺术、文学、科学等的)研究院，学会；(美国)私立学校；专科院校；(苏格兰)中等学校
# 例句
- He went off to the Amsterdam Academy to improve his technique .
	- 他动身前往阿姆斯特丹学院去进修技艺。
- The British Academy of Film and Television Arts .
	- 英国电影和电视艺术学院
- The movie won nine Academy Awards , including Best Picture .
	- 这部电影荣获九项奥斯卡金像奖，包括最佳影片奖。
# 形态
- #形态/word_pl academies
