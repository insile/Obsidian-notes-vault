---
tags:
  - 首字母/A
  - 级别/考研
  - 级别/六级
  - 级别/雅思
掌握: false
模糊: false
---
# 词义
- 英：/aɪl/； 美：/aɪl/
- #词性/n  过道；(教堂、戏院、火车等座位间或超级市场货架间的)走道
# 例句
- The best seats are in the aisle and as far forward as possible
	- 最好的座位在过道处，越靠前越好。
- Caroline floated up the aisle on her father 's arm .
	- 卡罗琳挽着父亲的手臂从过道上优雅地走过。
- She soon had us rolling in the aisles .
	- 她很快就让我们笑个不停。
# 形态
- #形态/word_pl aisles
