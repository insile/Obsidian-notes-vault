---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌeərəˈnɔːtɪks/； 美：/ˌerəˈnɔːtɪks/
- #词性/n  航空学；飞行术；飞行学
# 例句
- My dream is to go to UCLA and study aeronautics .
	- 我的梦想是去加利福尼亚大学洛杉机分校学航空学。
- With regards to military technology , space programs go beyond simple aeronautics and computer-simulation models .
	- 航天只要涉及到军事技术，就远远不止航空学、算机模拟这么简单了。
- That 's why exercise is considered so vital that National Aeronautics and Space Administration ( NASA ) puts it right on the workday schedule .
	- 所以运动才如此受重视,以至于美国国家航空航天局（NASA）把它放在了工作日的日程上。
