---
tags:
  - 首字母/A
  - 级别/六级
掌握: false
模糊: false
---
# 词义
- 英：/əˈlæs/； 美：/əˈlæs/
- #词性/int  (表示悲伤或遗憾)哎呀，唉
# 例句
- Alas , it 's not that simple .
	- 哎呀，事情不是那么简单的。
- Alas the day ! We have lost such a good chance .
	- 哎呀！我们失去了这么好的一次机会。
- For many people , alas , hunger is part of everyday life .
	- 唉，对很多人来说，挨饿是家常便饭。
