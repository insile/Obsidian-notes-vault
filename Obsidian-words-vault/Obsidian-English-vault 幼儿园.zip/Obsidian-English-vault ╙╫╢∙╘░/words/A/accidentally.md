---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˌæksɪˈdɛntəli/； 美：/ˌæksəˈdɛntəli/
- #词性/adv  意外地；出其不意地；不知不觉地
# 例句
- It appears the names were accidentally erased from computer disks .
	- 看起来那些名字被意外地从计算机磁盘上删除了。
- Every time you make a change to a file , you run the risk of accidentally making more mistakes .
	- 每次你更改文件，你也冒着意外地增加更多的错误的风险。
- As I turned around , I accidentally hit him in the face .
	- 我转身时不经意撞了他的脸。
