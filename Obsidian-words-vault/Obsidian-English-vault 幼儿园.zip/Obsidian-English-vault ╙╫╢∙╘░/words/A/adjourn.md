---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈdʒɜːn/； 美：/əˈdʒɜːrn/
- #词性/v  休会；延期；休庭
# 例句
- I am afraid the court may not adjourn until three or even later .
	- 我担心法庭要到3点或更晚时才会休庭。
- The court will adjourn for lunch . day student who has lunch at school
	- 法庭午餐时间休庭.提供午餐的走读学生
- The trial was adjourned following the presentation of new evidence to the court .
	- 新证据呈到庭上后，审讯就宣告暂停。
# 形态
- #形态/word_third adjourns
- #形态/word_ing adjourning
- #形态/word_done adjourned
- #形态/word_past adjourned
