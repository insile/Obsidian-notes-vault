---
tags:
  - 首字母/A
  - 级别/小学
掌握: false
模糊: false
---
# 词义
- 英：/əˈbaʊt/； 美：/əˈbaʊt/
- #词性/prep  关于；( 时间上 ) 在…前后，在…左右；对于；围绕；为了；在…附近；目的是；从事于；在…到处；在…四处；忙于；涉及…方面
- #词性/adv  大约；左右；几乎；到处；将近；各处；处处；在某地；闲着；凌乱地；沿反方向
- #词性/adj  在附近的；即将（做…）的；快要（发生…）的；在手头的, 现成的, 能得到的；在起作用的；四处走动的；在流行中的
# 例句
- Talking about my problems doesn 't come easy to me .
	- 要讲关于自己的问题，对我来说并不容易。
- Did you see her piece about the Internet in the paper today ?
	- 你看了今天报纸上她写的关于互联网的文章没有？
- It 's about this high .
	- 大约有这么高。
