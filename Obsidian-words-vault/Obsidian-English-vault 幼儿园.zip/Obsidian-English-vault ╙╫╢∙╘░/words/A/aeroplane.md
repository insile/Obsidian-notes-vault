---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈeərəpleɪn/； 美：/ˈerəpleɪn/
- #词性/n  飞机
# 例句
- The aeroplane will travel at twice the speed of sound .
	- 这架飞机的速度将是音速的两倍。
- The company was considered as a possible subcontractor to build the aeroplane .
	- 该公司被视为能够承担该飞机制造任务的潜在分包商之一。
- The airlines still have 2,500 new aeroplanes on order .
	- 这家航空公司尚有2,500架新飞机在订购中。
# 形态
- #形态/word_pl aeroplanes
