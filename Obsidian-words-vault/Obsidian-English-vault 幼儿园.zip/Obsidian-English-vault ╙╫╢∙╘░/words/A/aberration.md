---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌæbəˈreɪʃn/； 美：/ˌæbəˈreɪʃn/
- #词性/n  异常行为；反常现象；脱离常规
# 例句
- Anything else would be an aberration .
	- 任何其它情况都属于反常现象。
- But if you look at the long arc of economic history , such performance would be a remarkable aberration .
	- 但是，如果看看经济历史的长期走势，就会知道这种表现是一种罕见的反常现象。
- Single people are treated as an aberration and made to pay a supplement .
	- 独身者被当成异类，而且要付一笔额外的费用。
# 形态
- #形态/word_pl aberrations
