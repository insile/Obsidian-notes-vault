---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˌæksɪˈdentl/； 美：/ˌæksɪˈdentl/
- #词性/adj  意外的；偶然的
- #词性/n  偶然；次要方面
# 例句
- Accidental inhalation of the powder can be harmful
	- 意外的粉尘吸入可能有害。
- He can face the accidental trouble .
	- 他能够面对意外的困难。
- Information must be stored so that it is secure from accidental deletion .
	- 必须把资料保存起来，这样才不至于无意中删除。
# 形态
- #形态/word_pl accidentals
