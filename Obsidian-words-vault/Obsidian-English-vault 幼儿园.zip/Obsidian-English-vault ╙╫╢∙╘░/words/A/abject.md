---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈæbdʒekt/； 美：/ˈæbdʒekt/
- #词性/adj  卑鄙；下贱的；凄惨的；自卑的；卑躬屈节的；悲惨绝望的
# 例句
- All the people in the city knew that he was an abject liar .
	- 这城里所有的人都知道他是个卑鄙的说谎者。
- Our cruel and unrelenting enemy leaves us the choice of brave resistence or the most abject submission .
	- 句子：我们残酷而无情的敌人留给我们两个选择：勇敢抵抗，或者最卑鄙地屈服。敌人残酷无情，我们必须顽强抵抗，否则只能屈膝投降。
- He looked back at the abject , silent girl and repeated his question .
	- 他转过头看着这个噤若寒蝉的女孩，又重复了一遍他的问题。
