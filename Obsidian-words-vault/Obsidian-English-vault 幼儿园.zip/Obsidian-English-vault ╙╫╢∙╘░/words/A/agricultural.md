---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˌæɡrɪˈkʌltʃərəl/； 美：/ˌæɡrɪˈkʌltʃərəl/
- #词性/adj  农业的；农用的；(地区或社会)以农业为主的，农业高度发达的
# 例句
- Use Intellectual Property System and promote the agricultural development of our country
	- 运用知识产权制度促进我国农业的发展
- Study on Building Agricultural High-resolution Remote Sensing Image Information Extract Technology
	- 设施农业的高分辨率遥感影像信息提取方法的研究
- His analysis of urban use of agricultural land has been proved essentially correct
	- 他有关城市占用农业用地的分析已被证明大体上是正确的。
