---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/eɪs/； 美：/eɪs/
- #词性/n  王牌；(对手接不到发球的)发球得分；A纸牌(亦称“爱司”)；爱司球；擅长…的人；精于…的人
- #词性/adj  第一流的；极好的
- #词性/vt  发球得分；击败；得高分；彻底打败；顺利通过考试
# 例句
- It seems as if he has an ace up his sleeve .
	- 他似乎手中握有王牌。
- I 've still got one ace up my sleeve .
	- 我还有一张王牌可用。
- We had an ace time .
	- 我们过得真痛快。
# 形态
- #形态/word_third aces
- #形态/word_ing acing
- #形态/word_done aced
- #形态/word_pl aces
- #形态/word_past aced
