---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈædɪkwət/； 美：/ˈædɪkwət/
- #词性/adj  足够的；充足的；合格的；合乎需要的
# 例句
- We cannot guarantee adequate supplies of raw materials .
	- 我们不能保证提供充足的原料。
- Adequate housing is possible in developed , mixed economies wherein the interests of the poor have prevailed .
	- 在发达的混合经济体中，充足的房源供给是可能的，在那里贫困阶层的利益较有保障。
- The space available is not adequate for our needs .
	- 现有的空间不能满足我们的需要。
