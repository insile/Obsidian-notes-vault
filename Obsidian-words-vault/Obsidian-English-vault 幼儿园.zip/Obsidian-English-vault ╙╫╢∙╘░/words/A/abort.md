---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/雅思
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/əˈbɔːt/； 美：/əˈbɔːrt/
- #词性/v  使流产；中止(尤指很可能失败的事情)；(使)夭折
- #词性/n  流产；放弃；未成形的计划；未做好的打算
# 例句
- The decision was made to abort the mission
	- 决定中止这项任务。
- The captain instructed them to abort the mission .
	- 上尉指示他们中止执行任务。
- We had no option but to abort the mission .
	- 我们别无选择，只有取消这项任务。
# 形态
- #形态/word_third aborts
- #形态/word_ing aborting
- #形态/word_done aborted
- #形态/word_past aborted
