---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈɡrɒnəmɪst/； 美：/əˈɡrɑːnəmɪst/
- #词性/n  农学家
# 例句
- She has elected to become an agronomist .
	- 她决心做一个农学家。
- The agronomist suggested growing rice on the dried river bed .
	- 那位农学家建议在干涸的河床上种水稻。
- Agronomists and farmers use the pictures to study crops .
	- 农学家和农民利用图片来研究庄稼
# 形态
- #形态/word_pl agronomists
