---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈeəmeɪl/； 美：/ˈermeɪl/
- #词性/n  航空邮件；航空邮递
- #词性/vt  航空邮寄；<谑>投；抛；掷
# 例句
- By airmail they notify the bank in Australia that $ 1000 may be withdrawn .
	- 他们用航空邮件通知澳大利亚的银行支付一千英镑。
- Tutorial assistance may be available via regular airmail , telephone , facsimile machine , teleconferencing and over the Internet .
	- 教师的辅导可以通过定期的航空邮件、电话、传真和电话会议以及因特网等方式进行。
- She sent the letter by airmail .
	- 她寄的是航空信。
# 形态
- #形态/word_third airmails
- #形态/word_ing airmailing
- #形态/word_done airmailed
- #形态/word_past airmailed
