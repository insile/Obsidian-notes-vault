---
tags:
  - 首字母/A
  - 级别/六级
掌握: false
模糊: false
---
# 词义
- 英：/əˈdʒʌstəbl/； 美：/əˈdʒʌstəbl/
- #词性/adj  可调节的；可调整的
# 例句
- Dimension line with label that automatically changes to match length . Text position and extension lines are adjustable .
	- 带自动匹配长度的标签的尺寸线。文本位置和延长线是可调整的。
- Elevators ( lifts ) with an excellent shock aBsorBer go up and down steadily . stable but adjustable par value
	- 缓冲好的电梯，上下平稳。稳定但可调整的平价
- The height of the bicycle seat is adjustable .
	- 这辆自行车车座的高度可以调节。
