---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/æbˈstrækʃn/； 美：/æbˈstrækʃn/
- #词性/n  抽象；提取；抽象概念；抽取；分离；出神；心神专注
# 例句
- ' Third World ' is an abstraction , a form of shorthand
	- “第三世界”是个抽象概念，是一种简称。
- Is it worth fighting a big war , in the name of an abstraction like sovereignty ?
	- 在主权之类抽象概念的名义下打一场大战是否值得呢？
- Andrew noticed her abstraction and asked , ' What 's bothering you ? '
	- 安德鲁注意到她在愣神，便问道：“你怎么啦？”
# 形态
- #形态/word_pl abstractions
