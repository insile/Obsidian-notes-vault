---
tags:
  - 首字母/A
  - 级别/考研
  - 级别/六级
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈeəriəl/； 美：/ˈeriəl/
- #词性/n  天线
- #词性/adj  空中的；空气中的；从飞机上的；地表以上的
# 例句
- The aerial doesn 't look very secure to me .
	- 我看这天线不太牢固。
- You 'll need a good aerial to exploit the radio 's performance
	- 你需要弄个好天线来发挥广播的性能。
- Aerial photography has revolutionized the study of archaeology .
	- 航空摄影已经给考古学研究带来了一场革命。
# 形态
- #形态/word_pl aerials
