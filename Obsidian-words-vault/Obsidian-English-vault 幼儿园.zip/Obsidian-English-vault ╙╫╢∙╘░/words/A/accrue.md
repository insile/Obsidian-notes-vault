---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈkruː/； 美：/əˈkruː/
- #词性/v  累积；(逐渐)增长，增加；(使钱款、债务)积累
# 例句
- Changing words can change what we think about the world around us , he said . These tiny moments accrue and become big movements .
	- 他说道：改变用词能够改变我们思考周围世界的方式，这些微小的时刻累积起来会带来巨大的改变。
- Q.Would Star Alliance carriers'FFP members still be able to accrue and redeem miles on Shanghai Airlines flights ?
	- 星盟伙伴的常旅客计划是否依旧可以在乘坐上航航班时累积里程，并且用里程兑换上航航班机票？
- Interest will accrue if you keep your money in a savings account .
	- 如果把钱存入储蓄账户，就会自然生息。
# 形态
- #形态/word_third accrues
- #形态/word_ing accruing
- #形态/word_done accrued
- #形态/word_past accrued
