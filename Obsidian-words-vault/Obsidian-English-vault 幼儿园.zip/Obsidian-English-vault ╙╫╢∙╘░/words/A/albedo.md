---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- #词性/n  反照率；反射率；漫反射系数
# 例句
- A new method of surface albedo inverse model based on energy transmission
	- 基于能量的地表反照率遥感反演方法研究
- Experimental study on the influence of albedo to building thermal environment
	- 反照率影响建筑热环境的实验
- Study on Relationship between Vegetation Index Change and Surface Albedo
	- 植被指数变化与地表反照率的关系研究&以海南岛西部为例
# 形态
- #形态/word_pl albedos
