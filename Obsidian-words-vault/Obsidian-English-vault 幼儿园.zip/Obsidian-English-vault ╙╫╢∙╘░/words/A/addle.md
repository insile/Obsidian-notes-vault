---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈædl/； 美：/ˈædl/
- #词性/vt  使糊涂；麻木；使不能清晰地思考
- #词性/adj  坏的；混乱的；空虚的
# 例句
- Being in love must have addled your brain .
	- 坠入爱河必已使你神魂颠倒。
- I suppose the shock had addled his poor old brain .
	- 我估摸这个打击已经把他那可怜的脑袋瓜搞糊涂了。
- You 're talking like an addled romantic .
	- 你说话像个糊里糊涂耽于幻想的人。
# 形态
- #形态/word_third addles
- #形态/word_ing addling
- #形态/word_done addled
- #形态/word_past addled
