---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性/n  初学者；启蒙老师
- #词性/adj  字母的；初步的
# 例句
- What fund has very big development perspective , help , I am abecedarian .
	- 哪些基金有很大的发展前景，帮帮忙，我是初学者。
- The station that make group , to search index props up optimized abecedarian and Yan Zhanqun is very complex .
	- 制作站群，对搜索引擎优化的初学者而言站群是非常复杂的。
- The article does an abecedarian analysis with respect to this one problem .
	- 本文就这一问题做一个初步的分析。
