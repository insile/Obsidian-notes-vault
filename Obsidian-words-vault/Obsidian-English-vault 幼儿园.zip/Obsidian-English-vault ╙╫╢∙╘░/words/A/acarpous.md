---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性缺失 无果实的
# 例句
- In addition , the enzyme activity of high yield female plant , low yield female plant and acarpous female plant were compared .
	- 此外，还比较了高产、低产、不结果雌株之间同工酶的酶带和活性差别。
