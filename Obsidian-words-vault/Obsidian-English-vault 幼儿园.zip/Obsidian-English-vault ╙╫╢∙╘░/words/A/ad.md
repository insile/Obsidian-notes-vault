---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/æd/； 美：/æd/
- #词性/n  广告
- #词性/abbr  <拉> (= Anno Domini ) 公元
# 例句
- We put an ad in the local paper .
	- 我们在当地报纸上登了一则广告。
- He placed a lonely hearts ad in a magazine .
	- 他在一份杂志上刊登了征友广告。
- The meetings will be held on an ad hoc basis .
	- 会议将根据需要随时举行。
# 形态
- #形态/word_pl ads
