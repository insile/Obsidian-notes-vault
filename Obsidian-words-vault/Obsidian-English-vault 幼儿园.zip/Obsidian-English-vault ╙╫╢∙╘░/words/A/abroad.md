---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/əˈbrɔːd/； 美：/əˈbrɔːd/
- #词性/adv  在国外；到国外；户外；在室外；广为流传
- #词性/adj  往国外的
- #词性/n 海外；异国
# 例句
- She 's moving abroad to make a fresh start .
	- 她要移居国外，开始新的生活。
- I had always been attracted by the idea of working abroad .
	- 我总是向往去国外工作。
- Another trip abroad this year is out of the question .
	- 今年再度出国是绝无可能的。
