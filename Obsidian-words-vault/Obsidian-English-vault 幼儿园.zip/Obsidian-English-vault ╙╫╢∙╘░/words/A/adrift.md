---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/əˈdrɪft/； 美：/əˈdrɪft/
- #词性/adj  漂流；漂浮；随波逐流；漂泊无依；漫无目的；松开；脱开；分数落后
# 例句
- They were spotted after three hours adrift in a dinghy .
	- 他们在小舢板上漂浮了3个小时后才被发现。
- It 's a tiny island adrift in a huge ocean .
	- 这是漂浮在浩瀚汪洋中的一座小岛
- The team are now just six points adrift of the leaders .
	- 现在该队得分比领先的队只落后六分。
