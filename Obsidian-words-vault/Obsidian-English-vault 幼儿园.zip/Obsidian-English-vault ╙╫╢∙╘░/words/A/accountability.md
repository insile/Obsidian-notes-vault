---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˌkaʊntəˈbɪləti/； 美：/əˌkaʊntəˈbɪləti/
- #词性/n  责任；有义务，有责任；（档案）保管责任
# 例句
- Good management in the police cannot be divorced from accountability
	- 对警察队伍的良好管理和应负的责任是分不开的。
- This is within his sphere of accountability .
	- 这在他的责任范围之内。
- Then again , the air of accountability that the camera generates can also work in contractors ' favor .
	- 此外，摄像头所创造的负责任的氛围对他们也有利。
