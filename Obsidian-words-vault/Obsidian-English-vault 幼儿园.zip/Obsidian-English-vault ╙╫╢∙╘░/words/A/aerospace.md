---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/雅思
掌握: false
模糊: false
---
# 词义
- 英：/ˈeərəʊspeɪs/； 美：/ˈeroʊspeɪs/
- #词性/n  航空航天(工业)；航空航天技术
- #词性/adj  航空与航天 ( 空间 ) 的；航空与航天器的；航空与航天器制造的
# 例句
- The world 's entire aerospace industry is feeling the chill winds of recession .
	- 全世界的航空航天工业都感受到了经济衰退的寒意。
- The European Commission ruled that British Aerospace should pay back tens of millions of pounds .
	- 欧洲委员会裁定英国航空航天公司应该偿还数千万英镑。
- British Aerospace has won an order worth 340 million dollars .
	- 英国宇航公司已经赢得了3.4亿美元的订单。
# 形态
- #形态/word_pl aerospaces
