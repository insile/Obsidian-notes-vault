---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈæɡrɪkʌltʃə(r)/； 美：/ˈæɡrɪkʌltʃər/
- #词性/n  农业；农艺；农学
# 例句
- Nowhere is the effect of government policy more apparent than in agriculture .
	- 政府的政策对农业的影响最为显著。
- The number of people employed in agriculture has fallen in the last decade .
	- 过去十年，农业从业人数已经下降。
- A proportion of the land is used for agriculture .
	- 一部分土地作农用。
