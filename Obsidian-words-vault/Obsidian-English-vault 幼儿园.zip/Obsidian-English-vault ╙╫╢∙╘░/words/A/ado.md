---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈduː/； 美：/əˈduː/
- #词性/n  忙乱；费力；艰难
# 例句
- And ( 3 ) glibenclamide ( 5 mg \/ kg , 0 2 ml , iv ), a blocker of ATP sensitive potassium channel , also abolished the effect of Ado .
	- 静脉注射ATP敏感性钾通道阻断剂格列苯脲（5mg\/kg，02ml）后，腺苷的上述效应也被消除。
- ' And now , without further ado , let me introduce our benefactor . '
	- “下面，闲话少说，让我来介绍一下我们的赞助人。”
- The servants likewise used me saucily , and had much ado to keep their hands off me .
	- 有几个仆人对我很无礼，要他们的手不碰我是很难的
