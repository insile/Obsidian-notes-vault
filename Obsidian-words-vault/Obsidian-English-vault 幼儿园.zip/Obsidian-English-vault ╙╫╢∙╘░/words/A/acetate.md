---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˈæsɪteɪt/； 美：/ˈæsɪteɪt/
- #词性/n  醋酸盐；醋酸酯；醋酸纤维素；投影胶片；醋酸透明塑胶片
# 例句
- Measure the peak area for acetate .
	- 测出醋酸盐的峰面积。
- The formation of by-products could be inhibited once adding acetate in the reaction systems .
	- 在反应体系中添加醋酸盐可抑制副产物的生成。
- The present situation of acetate fiber industry and product development
	- 醋酯纤维工业的现状和产品开发
