---
tags:
  - 首字母/A
  - 级别/小学
掌握: false
模糊: false
---
# 词义
- 英：/əˈbʌv/； 美：/əˈbʌv/
- #词性/prep  在(或向)…上面；（音量或清晰度）超过（另一种声音）；(数目、数量、水平、年龄)超过，多于，大于；(重要性、质量)超过，胜过；（因善良或诚实正直而）不至于，不屑于（做某事）
- #词性/adv  在(或向)上面；上文；(数目、数量、水平、年龄)超过，更多，更大；前文；在(或向)较高处
- #词性/adj  上述的；前文述及的
- #词性/n  上；前述；天上
# 例句
- Our classroom is just above .
	- 我们的教室就在上面。
- This little number above there gives you the tempo .
	- 这些在上面的小数字是节奏。
- There are other factors over and above those we have discussed .
	- 除了我们所讨论的之外，还有其他因素。
