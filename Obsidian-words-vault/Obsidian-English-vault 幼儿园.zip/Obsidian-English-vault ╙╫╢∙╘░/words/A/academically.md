---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˌækə'demɪklɪ/； 美：/ˌækə'demɪklɪ/
- #词性/adv  学理上
# 例句
- Academically speaking , the state power to declare emergency is the power authorizing the state to take unconventional emergent countermeasures to resume the normal social order .
	- 从学理上看，国家紧急权是指国家在紧急状态下为了恢复正常的社会秩序而采取非常规的紧急对抗措施的权力。
- This chapter not only academically discussed claims due to safety , capriciousness , concealment claims the problems caused by capital contribution .
	- 该章节不但从学理上探讨了由于债权的不安全性，随意性，隐蔽性造成债权出资存在的问题。
- You have to do well academically to get into medical school .
	- 你得学习成绩优良才能进入医学院。
