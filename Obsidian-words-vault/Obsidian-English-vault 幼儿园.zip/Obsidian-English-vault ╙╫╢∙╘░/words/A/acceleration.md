---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əkˌseləˈreɪʃn/； 美：/əkˌseləˈreɪʃn/
- #词性/n  加速；加速度；加快；(车辆)加速能力，加速的幅度
# 例句
- He has also called for an acceleration of political reforms .
	- 他同时呼吁加快政治改革的步伐。
- The acceleration of economic globalization requires the formulation of the anti-monopoly law and regulations of competition .
	- 经济全球化进程的加快要求我国健全经济法制，尽快制定反垄断法，对竞争领域的有关问题做出规定。
- Acceleration and velocity are both vectors .
	- 加速度和速度都是矢量。
# 形态
- #形态/word_pl accelerations
