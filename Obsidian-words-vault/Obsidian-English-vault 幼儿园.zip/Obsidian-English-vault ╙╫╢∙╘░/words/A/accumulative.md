---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈkjuːmjələtɪv/； 美：/əˈkjuːmjələtɪv/
- #词性/adj  累积的
# 例句
- Severe leakage also occurred on the accumulative nutrient in greenhouse vegetable soil .
	- 大棚菜地土壤中累积的养分还存在严重的淋溶现象。
- Analysis of load-displacement relationship for RC columns under reversed load considering accumulative damage
	- 钢筋混凝土柱考虑损伤累积的反复荷载-位移关系分析
- The consensus is that risk factors have an accumulative effect .
	- 危险因素会与日俱增已成为共识。
