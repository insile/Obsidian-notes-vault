---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈiːdʒɪs/； 美：/ˈiːdʒɪs/
- #词性/n  庇护；庇护，保护；主办，赞助，领导
# 例句
- Only in this way can we get the aegis and blessing of gods .
	- 只有这样，才会受到神的庇护和赐福。
- The new refrigerator would be developed under the aegis of a task force that brought together people from engineering , design , marketing , and sales .
	- 新的产品将在一个工作团队的庇护下得到开发，该团队会聚了工程部，设计部，营销部和销售部的人员。
- The space programme will continue under the aegis of the armed forces
	- 这项太空计划将以武装部队作后盾继续进行。
