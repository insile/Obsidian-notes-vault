---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈkjuːəti/； 美：/əˈkjuːəti/
- #词性/n  敏锐度；(思维、视力、听力的)敏度，敏锐
# 例句
- We work on improving visual acuity .
	- 我们致力于提高视觉的敏锐度。
- A new method of adaptable rendering for interacting in Virtual Environment ( VE ) through the use of different visual acuity equations is proposed .
	- 提出了一种在虚拟环境中利用不同的视觉敏锐度公式进行自适应渲染的新方法。
- The nurse may also measure visual acuity .
	- 护士还可以检查视敏度。
