---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈɡeɪp , ˈæɡəpi/； 美：/əˈɡeɪp , ˈæɡəpi/
- #词性/adj  (嘴巴因吃惊等)大张着
- #词性/n  基督之爱；灵性之爱
- #词性/adv  目瞪口呆；张着
# 例句
- She stood looking at Carmen with her mouth agape .
	- 她站着，张大了嘴看着卡门。
- Nancy 's mouth was agape .
	- 南希目瞪口呆。
- People standing Agape in the light of the flames .
	- 人们张大着嘴站在火光之中。
