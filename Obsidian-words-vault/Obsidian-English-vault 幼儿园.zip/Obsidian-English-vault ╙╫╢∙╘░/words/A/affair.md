---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈfeə(r)/； 美：/əˈfer/
- #词性/n  事件；事情；公共事务；政治事务；(尤指已婚男女的)私通，风流韵事；个人的事；私人业务；不寻常之物
# 例句
- On the Strategies for Establishing Fiscal Input System for Public Paroxysmal Affair
	- 建立突发性公共事务财政投入体系的对策研究
- The base of tax is the national public affair function . including the service function and management function .
	- 税收的根据是国家的公共事务职能，具体包括服务职能和管理职能。
- I must arrange my financial affairs and make a will .
	- 我必须把我的财务安排好，并立下遗嘱。
# 形态
- #形态/word_pl affairs
