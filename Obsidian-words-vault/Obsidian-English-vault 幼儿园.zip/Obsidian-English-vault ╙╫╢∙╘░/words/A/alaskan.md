---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- #词性缺失 阿拉斯加；阿拉斯加人
# 例句
- Alaskan Eskimos believe that every living creature possesses a spirit
	- 阿拉斯加的爱斯基摩人认为每一个活着的生物都有灵魂。
- You can still find gold nuggets in the Alaskan rivers .
	- 你仍可以在阿拉斯加河里找到金块。
- Discussion on two models of Paleoclimatic Records of magnetic susceptibility of Alaskan and Chinese Loess
	- 中国黄土和阿拉斯加黄土磁化率气候记录的两种模式探讨
