---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈeɪkɔːn/； 美：/ˈeɪkɔːrn/
- #词性/n  橡子；橡实
# 例句
- To see the problem here more clearly , let 's look at a different biological system , say , an acorn
	- 为更清晰地理解此处的问题，我们来看一种不同的生物系统，比如说，橡子。
- Each acorn grows in a little cup .
	- 每个橡子都生长在一个小的杯状结构之中，
- Great oaks from little acorns grow .
	- 合抱之树，生于毫末。
# 形态
- #形态/word_pl acorns
