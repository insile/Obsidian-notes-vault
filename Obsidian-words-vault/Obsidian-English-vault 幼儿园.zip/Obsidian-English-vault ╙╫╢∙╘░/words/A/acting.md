---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈæktɪŋ/； 美：/ˈæktɪŋ/
- #词性/n  (戏剧、电影等中的)表演；演艺业
- #词性/adj  临时代理的
- #词性/v  行为；行动；举止；做事；假装
# 例句
- Her acting added warmth and colour to the production .
	- 她的表演给这出戏增添了生气和趣味。
- The script allows full rein to her larger-than-life acting style .
	- 剧本允许她充分展现她那夸张的表演风格。
- The time has come to act .
	- 采取行动的时机到了。
# 形态
- #形态/word_proto act
