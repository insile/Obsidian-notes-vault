---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈfekʃənət/； 美：/əˈfekʃənət/
- #词性/adj  充满深情的；表示关爱的
# 例句
- He is very affectionate towards his children .
	- 他非常疼爱他的孩子。
- He gave her knee an affectionate pat .
	- 他温情地拍了拍她的膝盖。
- She gave me a very long and affectionate hug .
	- 她满怀深情地久久拥抱了我。
