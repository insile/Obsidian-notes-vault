---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˈeɪdʒɪzəm/； 美：/ˈeɪdʒɪzəm/
- #词性/n  年龄歧视；对老年人的歧视
# 例句
- The problem of ageism in the workplace often goes unrecognized .
	- 工作场所的年龄歧视问题常被忽视。
- You 're always talking in isms ─ sexism , ageism , racism .
	- 你张口闭口就是各种歧视——性别歧视、年龄歧视、种族歧视。
- Many women feel ageism is obstructing their career ambitions .
	- 许多女性感到年龄歧视问题正阻碍着她们职业抱负的实现。
