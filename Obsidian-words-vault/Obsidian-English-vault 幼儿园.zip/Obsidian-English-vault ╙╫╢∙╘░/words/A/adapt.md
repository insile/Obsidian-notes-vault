---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈdæpt/； 美：/əˈdæpt/
- #词性/v  适应(新情况)；使适合(新用途、新情况)；改编；改写
# 例句
- We have had to adapt quickly to the new system .
	- 我们不得不迅速适应新制度。
- We must constantly adapt and innovate to ensure success in a growing market .
	- 我们必须不时地适应并创新，以确保在不断扩大的市场中取得成功。
- Three of her novels have been adapted for television .
	- 她的长篇小说中有三部已改编成电视节目。
# 形态
- #形态/word_third adapts
- #形态/word_ing adapting
- #形态/word_done adapted
- #形态/word_past adapted
