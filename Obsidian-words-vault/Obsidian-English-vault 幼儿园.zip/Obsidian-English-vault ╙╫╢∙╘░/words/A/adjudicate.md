---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈdʒuːdɪkeɪt/； 美：/əˈdʒuːdɪkeɪt/
- #词性/v  裁决(争执等)；判决；(比赛中)裁判
# 例句
- Their purpose is to adjudicate disputes between employers and employees .
	- 他们的目的是裁决雇主与雇员之间的纠纷。
- The international court of justice might be a suitable place to adjudicate claims .
	- 国际法庭或许是对所有权作出裁决的合适之地。
- Who is adjudicating at this year 's contest ?
	- 今年比赛谁当裁判？
# 形态
- #形态/word_third adjudicates
- #形态/word_ing adjudicating
- #形态/word_done adjudicated
- #形态/word_pl adjudicates
- #形态/word_past adjudicated
