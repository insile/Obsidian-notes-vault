---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/əˈɡenst/； 美：/əˈɡenst/
- #词性/prep  反对；违反；紧靠；对…不利；与…相反；逆；撞；以防；以…为背景；倚；碰；和…相比；作为…借项，以…抵付；以…为竞争对手
# 例句
- Public sentiment is against any change to the law .
	- 公众的意见是反对对该法律作任何修改。
- The general feeling of the meeting was against the decision .
	- 会议上普遍的意见是反对这个决定。
- New information is matched against existing data in the computer .
	- 新的资料和电脑中已有的数据作了比较。
