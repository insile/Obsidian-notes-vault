---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/ˈeəlaɪn/； 美：/ˈerlaɪn/
- #词性/n  航空公司；航线；空气输送管 ( 给潜水员、风钻等输送空气用 )
# 例句
- The airline has a good safety record .
	- 这家航空公司的安全情况一向很好。
- The airline apologized and bumped us up to first class .
	- 航空公司道歉后把我们掉换到头等舱。
- The airline industry took a hit last year .
	- 去年航空业受到了严重冲击。
# 形态
- #形态/word_pl airlines
