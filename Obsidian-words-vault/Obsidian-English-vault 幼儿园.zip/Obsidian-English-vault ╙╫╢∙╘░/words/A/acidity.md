---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈsɪdəti/； 美：/əˈsɪdəti/
- #词性/n  酸性；酸度；酸味
# 例句
- Effect of Temperature and Acidity on the Determination of Effective Silicon
	- 温度和酸度对有效硅测定的影响初探
- The study on acidity change and inspection method of the formula milk powder
	- 配方乳粉生产过程中酸度变化研究及检测
- Add honey to counterbalance the acidity
	- 加点蜂蜜来调和酸味。
