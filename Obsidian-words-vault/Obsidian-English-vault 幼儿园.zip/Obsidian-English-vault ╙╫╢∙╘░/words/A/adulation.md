---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌædjuˈleɪʃn/； 美：/ˌædʒəˈleɪʃn/
- #词性/n  奉承；吹捧；称赞
# 例句
- History abounds with great men worthy of adulation and emulation .
	- 历史上有很多值得称赞和效法的伟人。
- The attackers normally get the accolades and the adulation so it would be nice to see a defender win it .
	- 攻击球员通常更容易得到提名和称赞，所以如果有个后卫拿奖就太好了。
- The book was received with adulation by critics .
	- 这本书受到了评论人士的吹捧。
