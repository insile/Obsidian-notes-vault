---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌæɡrɪˈɡeɪʃn/； 美：/ˌæɡrɪˈɡeɪʃn/
- #词性/n  聚合；总量；集合体；聚合作用；凝聚；聚集作用
# 例句
- Study on Familial Aggregation of Lung Cancer Among Women in Shanghai
	- 上海市区女性肺癌的家族聚集性研究
- An Aggregation Algorithm Based on Group Numbers
	- 基于分组序号的聚集算法
- The people are a sea of wisdom and the aggregation of strength .
	- 人民是智慧的海洋、力量的总汇。
# 形态
- #形态/word_pl aggregations
