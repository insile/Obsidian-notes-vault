---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/əˈɡresɪv/； 美：/əˈɡresɪv/
- #词性/adj  侵略的；侵略性的；挑衅的；好斗的；气势汹汹的；声势浩大的；富于攻击性的；志在必得的
# 例句
- Rome is still aggressive in modern literature and criticism .
	- 罗马在近代文学和评论中依然是富有侵略性的。
- It 's known that the war is aggressive .
	- 众所周知，这场战争是侵略性的。
- A good salesperson has to be aggressive in today 's competitive market .
	- 在当今竞争激烈的市场上，一个好的销售员应该有进取精神。
# 形态
- #形态/word_est most aggressive
- #形态/word_er more aggressive
