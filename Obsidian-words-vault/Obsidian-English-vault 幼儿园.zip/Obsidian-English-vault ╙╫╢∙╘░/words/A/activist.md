---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈæktɪvɪst/； 美：/ˈæktɪvɪst/
- #词性/n  积极分子；激进分子；活跃分子
# 例句
- The activist worked hard to change the law .
	- 激进分子努力改变法律。
- Another activist for gun control says he believes Mr. Obama will soon make recommendations on the issue .
	- 另一位枪支管制激进分子表示他相信奥巴马会立刻提出建议。
- His research work was attacked by animal rights activists .
	- 他的研究受到了动物权益维护者的抨击。
# 形态
- #形态/word_pl activists
