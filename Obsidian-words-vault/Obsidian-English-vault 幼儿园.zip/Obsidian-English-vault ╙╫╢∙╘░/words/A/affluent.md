---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈæfluənt/； 美：/ˈæfluənt/
- #词性/adj  富裕的
- #词性/n  富裕的人；支流
# 例句
- Luxury goods manufacturers have long tailored products from cars to jeans for affluent Chinese consumers .
	- 奢侈品生产商很早就开始为富裕的中国消费者们定制从汽车到牛仔裤的一系列产品了。
- And among affluent travelers , solo travel has more than doubled , research from Visa shows .
	- 而据维萨公司的研究显示，在经济富裕的旅行者当中，单人旅行的次数更是增长了一倍有余。
- Cigarette smoking used to be commoner among affluent people .
	- 吸烟曾经在富人中间更为普遍。
# 形态
- #形态/word_pl affluents
