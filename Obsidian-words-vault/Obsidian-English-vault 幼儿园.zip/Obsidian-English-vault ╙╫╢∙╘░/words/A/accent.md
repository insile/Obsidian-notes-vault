---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/ˈæksent , ækˈsent/； 美：/ˈæksent , ækˈsent/
- #词性/n  口音；重音；强调；着重点；腔调；变音符号（标在字母上）；土音
- #词性/vt  强调；突出；着重
# 例句
- The way she puts on that accent really irritates me .
	- 她故意操那种口音的样子实在令我恼火。
- Years of living in England had eliminated all trace of her American accent .
	- 她因多年居住在英国，美国口音已荡然无存。
- I wish he wouldn 't affect that ridiculous accent .
	- 但愿他别故意装出那种可笑的腔调。
# 形态
- #形态/word_third accents
- #形态/word_ing accenting
- #形态/word_done accented
- #形态/word_pl accents
- #形态/word_past accented
