---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈbɒlɪʃ/； 美：/əˈbɑːlɪʃ/
- #词性/vt  废除，废止(法律、制度、习俗等)
# 例句
- The following year Parliament voted to abolish the death penalty for murder
	- 议会于翌年表决对谋杀罪废除死刑。
- These reforms will abolish racially discriminatory laws .
	- 这些改革措施将彻底废除带有种族歧视的法律。
- This tax should be abolished .
	- 这种税应该取消。
# 形态
- #形态/word_third abolishes
- #形态/word_ing abolishing
- #形态/word_done abolished
- #形态/word_past abolished
