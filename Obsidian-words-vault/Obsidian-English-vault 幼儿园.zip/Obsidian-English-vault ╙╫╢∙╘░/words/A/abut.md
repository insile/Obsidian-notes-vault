---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbʌt/； 美：/əˈbʌt/
- #词性/v  邻接；紧靠；毗连
- #词性/n  支座；枢轴；接合端
# 例句
- The two lots are abut together .
	- 那两块地毗连着。
- An earthquake hit the area abutting our province .
	- 与我省邻接的地区遭受了一次地震。
- His land abuts onto a road .
	- 他的土地紧靠公路。
# 形态
- #形态/word_third abuts
- #形态/word_ing abutting
- #形态/word_done abutted
- #形态/word_past abutted
