---
tags:
  - 首字母/A
  - 级别/雅思
掌握: false
模糊: false
---
# 词义
- 英：/əˈflɪktɪŋ/； 美：/əˈflɪktɪŋ/
- #词性/v  折磨；使痛苦
- #词性/adj  令人痛苦的；使人忧虑的
# 例句
- A fatal cancer is afflicting her .
	- 致命癌症在折磨着她。
- Increasing food prices are not the only problem afflicting the poor .
	- 粮食价格暴涨并不是折磨穷人的唯一问题。
- Famine and war still afflict mankind .
	- 饥饿和战争仍使人类遭受痛苦。
# 形态
- #形态/word_proto afflict
