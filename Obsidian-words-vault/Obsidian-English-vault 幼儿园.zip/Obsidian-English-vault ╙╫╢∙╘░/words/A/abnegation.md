---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌæbnɪˈɡeɪʃn/； 美：/ˌæbnɪˈɡeɪʃn/
- #词性/n  放弃；克制；拒绝；自制
# 例句
- The flying leaves tell me : the process of accomplishment is also process of abnegation , so I come to relize it 's a self-mockery for my conceit
	- 落叶告诉我完成的过程又是放弃的过程，我开始对对自己的重要性进行自嘲
- The choice and abnegation of cultures are unavoidable and difficult problems in any society revolution .
	- 文化的抉择和拒绝是任何社会革命不可回避的难题。
- Abnegation and Lure : On ROSE DOOR and the Probability of Contemporary Female Writing
	- 拒绝与诱惑&《玫瑰门》与当代女性写作的可能性
