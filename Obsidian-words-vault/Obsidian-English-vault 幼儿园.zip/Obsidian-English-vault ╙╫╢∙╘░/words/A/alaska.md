---
tags:
  - 首字母/A
  - 级别/小学
掌握: false
模糊: false
---
# 词义
- 英：/əˈlæskə/； 美：/əˈlæskə/
- #词性/n  阿拉斯加州
# 例句
- A group of senators plans to filibuster a measure that would permit drilling in Alaska .
	- 一群参议员计划通过发表长篇大论来阻挠一项允许在阿拉斯加州钻探石油的议案获得通过。
- Billboards3 Are Banned In Alaska , Maine , Vermont , And Hawaii
	- 美国的阿拉斯加州、缅因州、佛蒙特州和夏威夷州禁止竖广告牌
- She received a collect phone call from Alaska .
	- 她接到一个从阿拉斯加打来的付费电话。
# 形态
- #形态/word_pl Alaskas
