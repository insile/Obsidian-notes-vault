---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˈæɡənaɪz/； 美：/ˈæɡənaɪz/
- #词性/vi  苦苦思索；焦虑不已
# 例句
- Patrick was known to agonize over questions of policy .
	- 大家都知道帕特里克喜欢苦苦思索政策方面的问题。
- She only made the decision to apply for training after years of agonizing .
	- 多年的苦苦思索之后，她才作出了申请培训的决定。
- I spent days agonizing over whether to take the job or not .
	- 我用了好些天苦苦思考是否接受这个工作。
# 形态
- #形态/word_third agonizes
- #形态/word_ing agonizing
- #形态/word_done agonized
- #形态/word_past agonized
