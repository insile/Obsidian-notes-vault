---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- #词性缺失 有利地；方便地
# 例句
- Its technical indexed were advanced and reasonable . In addition , it was a precursor for a strong applicability , and could advantageously promote the development of the production technology of ferrite materials from iron oxides in our country .
	- 标准的技术指标先进合理，适用性和前瞻性强，将有利地促进我国铁氧体用氧化铁生产和使用技术的进步。
- Further , the top and bottom predictive coders can advantageously include B-frames and multiple prediction motion compensation .
	- 此外，所述上预测性编码器和下预测性编码器可有利地包括B帧和多重预测运动补偿。
- More complex topographic features are treated advantageously by application of relaxation methods .
	- 比较复杂的地物，最好用松弛方法处理。
