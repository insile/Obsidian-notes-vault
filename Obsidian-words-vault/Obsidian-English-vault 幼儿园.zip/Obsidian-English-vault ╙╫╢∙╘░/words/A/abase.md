---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbeɪs/； 美：/əˈbeɪs/
- #词性/vt  贬低；卑躬屈节；表现卑微；屈从
# 例句
- He refused to abase himself in the eyes of others .
	- 他不愿在他人面前被贬低。
- You can never abase a person for a little mistake .
	- 你永远不可以因为一个小小的错误而去贬低一个人的人格。
- A man who betrays a friend abases himself .
	- 出卖朋友的人实际上是自贬身份。
# 形态
- #形态/word_third abases
- #形态/word_ing abasing
- #形态/word_done abased
- #形态/word_past abased
