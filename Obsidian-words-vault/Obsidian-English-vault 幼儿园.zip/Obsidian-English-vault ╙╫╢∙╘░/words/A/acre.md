---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈeɪkə(r)/； 美：/ˈeɪkər/
- #词性/n  英亩(4 840平方码，约为4 050平方米)
# 例句
- But anything that can increase farming efficiency — the amount of crops we can produce per acre of land — will be extremely useful .
	- 但任何能提高农业效率（即我们每英亩土地能生产的作物数量）的东西都将非常有用。
- On a mere 1 \/ 10 of an acre in Los Angeles , Loe and her family grow , can and preserve much of the food they consume .
	- 洛伊和她的家人在洛杉矶仅有0.1英亩的土地上种植,并将他们所食用的大部分食物装入罐头里保存。
- Each house has acres of space around it .
	- 每座房屋四周都有大量空地。
# 形态
- #形态/word_pl acres
