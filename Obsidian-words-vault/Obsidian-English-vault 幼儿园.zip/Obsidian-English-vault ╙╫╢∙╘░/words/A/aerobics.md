---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/eəˈrəʊbɪks/； 美：/eˈroʊbɪks/
- #词性/n  有氧运动(经常分班组伴随音乐进行的增强心肺功能的健身活动)
# 例句
- I 'd like to join an aerobics class to improve my fitness .
	- 我想参加有氧运动训练班来增强体质。
- She teaches swimming , lifesaving and water aerobics .
	- 她教授游泳、救生术和水中有氧运动。
- I don 't do aerobics any more ─ it 's too knackering .
	- 我再不做有氧健身操了——太累人了。
