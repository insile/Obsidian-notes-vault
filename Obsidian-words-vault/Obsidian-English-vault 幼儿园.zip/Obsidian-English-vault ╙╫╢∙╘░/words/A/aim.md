---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/eɪm/； 美：/eɪm/
- #词性/n  目的；目标；瞄准
- #词性/v  旨在，目的是；针对，指向；瞄准，对准；打算，企图
# 例句
- Our main aim is to increase sales in Europe .
	- 我们的主要目标是增加在欧洲的销售量。
- The college 's aim is to help students achieve their aspirations .
	- 大学的目标是帮助学生实现他们的抱负。
- The new management techniques aim to improve performance .
	- 新的管理技术旨在提高效率。
# 形态
- #形态/word_third aims
- #形态/word_ing aiming
- #形态/word_done aimed
- #形态/word_pl aims
- #形态/word_past aimed
