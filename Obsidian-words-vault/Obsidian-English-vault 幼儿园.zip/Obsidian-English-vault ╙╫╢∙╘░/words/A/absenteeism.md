---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˌæbsənˈtiːɪzəm/； 美：/ˌæbsənˈtiːɪzəm/
- #词性/n  (经常性无故的)旷工，旷课
# 例句
- Absenteeism has cost the organization thousands of working days this year .
	- 旷工使该机构损失了数千个工作日。
- Improvements in working conditions helped to reduce levels of absenteeism .
	- 工作条件的改善已令旷工率降低。
- Science has shown a clear correlation between high stress levels in workers and absenteeism , reduced productivity , disengagement and high turnover .
	- 科学表明员工们长时间处于高压力与他们缺勤，生产力降低和高离职率之间有着明显的相关性。
