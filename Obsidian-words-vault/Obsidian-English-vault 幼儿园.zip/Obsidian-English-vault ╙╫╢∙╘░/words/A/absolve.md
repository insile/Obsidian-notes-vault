---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əbˈzɒlv/； 美：/əbˈzɑːlv/
- #词性/vt  赦免；赦免…的罪；宣告…无罪；判定…无责
# 例句
- I absolve you from all your sins .
	- 我赦免你所有的罪过。
- God will absolve you of all your sins .
	- 上帝会赦免你所有的罪过。
- The President absolved his officers and took the blame upon himself .
	- 总统赦免了手下的官员，把过失揽到自己的头上。
# 形态
- #形态/word_third absolves
- #形态/word_ing absolving
- #形态/word_done absolved
- #形态/word_past absolved
