---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/əˈfiːld/； 美：/əˈfiːld/
- #词性/adv  （在）野外；远离；在（向）远处；在战场上
# 例句
- Journalists came from as far afield as China .
	- 新闻记者来自中国等遥远的地方。
- Many of those arrested came from far afield .
	- 那些被捕者有许多来自很远的地方。
- British tour companies are nudging clients to travel further afield .
	- 英国旅游公司正鼓动客户到更远的地方去旅游。
