---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性/adv  美学上；审美地；美学观点上地
# 例句
- Segmental construction contributes toward aesthetically pleasing structures in many different sites .
	- 对于许多不同的现场条件，分段施工都能提供美观，颇有魄力的桥型结构。
- All isolation techniques may be aesthetically unacceptable or even dirty .
	- 所有的隔离方法都有可能在美观方面使人难以接受，或甚至是肮脏的。
- It is essential to design class teaching aesthetically in concrete teaching contents and aspects .
	- 在具体的教学内容和环节上，必须按照美的规律来对课堂教学进行设计。
