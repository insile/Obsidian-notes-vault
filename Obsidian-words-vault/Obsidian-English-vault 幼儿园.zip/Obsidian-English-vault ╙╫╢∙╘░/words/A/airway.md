---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˈeəweɪ/； 美：/ˈerweɪ/
- #词性/n  气道；(飞机的)固定航线
# 例句
- First check that the accident victim doesn 't have an obstructed airway .
	- 首先要确保事故受伤者的气道通畅。
- The Analysis of Airway Resistance with Online Monitoring System
	- 内置在线监测机器人系统的气道阻力分析
- This is the last call for passengers travelling on British Airways flight 199 to Rome .
	- 乘坐英国航空公司199次班机飞往罗马的乘客，这是最后一次通知登机。
# 形态
- #形态/word_pl airways
