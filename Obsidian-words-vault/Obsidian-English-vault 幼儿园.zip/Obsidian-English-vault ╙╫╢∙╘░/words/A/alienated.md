---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈeɪliəneɪtɪd/； 美：/ˈeɪliəneɪtɪd/
- #词性/v  使疏远；使(与某群体)格格不入；离间；使不友好
- #词性/adj  疏远的；被疏远的
# 例句
- But this made the existing conflicts more acute and alienated the tribes further .
	- 但是这个举措使现存的问题更加尖锐并使部落之间更加离间。
- His attempts to alienate the two friends failed because they had complete faith .
	- 他离间那两个朋友的企图失败了，因为他们彼此完全信任。
- Very talented children may feel alienated from the others in their class .
	- 天才出众的孩子可能觉得与班上的同学格格不入。
# 形态
- #形态/word_proto alienate
