---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌækwiˈesnt/； 美：/ˌækwiˈesnt/
- #词性/adj  默许的；默认的；顺从的
# 例句
- Perhaps you are too acquiescent .
	- 可能你太顺从了。
- Far from being unctuous Pat was always loath to appear acquiescent .
	- 由于并不愿意假意奉承，所以帕特总是不愿意表现出勉强顺从的姿态。
- My brother is of the acquiescent rather than the militant type .
	- 我弟弟是属于服从型的而不是好斗型的。
