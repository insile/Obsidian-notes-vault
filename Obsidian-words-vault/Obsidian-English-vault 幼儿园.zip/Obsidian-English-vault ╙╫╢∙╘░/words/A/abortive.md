---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbɔːtɪv/； 美：/əˈbɔːrtɪv/
- #词性/adj  流产的；失败的；不成功的
# 例句
- The structure variety and apoptotic characteristics of abortive Otter rabbit placenta
	- 流产的獭兔胎盘结构变化及细胞凋亡情况研究
- He had weathered too many abortive revolutionaries when only his courage had saved the government .
	- 流产的革命他见过多了，多少次都是靠他的胆识才保全了政府。
- There is no record of the abortive military coup .
	- 没有关于那次未遂的军事政变的记录。
