---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈfɪnəti/； 美：/əˈfɪnəti/
- #词性/n  密切关系；喜爱；密切的关系；类同；喜好
# 例句
- A request 's affinity depends on the Service it 's for and the type of operation .
	- 请求的密切关系取决于它请求的服务和操作类型。
- This is the same as high affinity except the nodeID is optional .
	- 这个值与高密切关系相同，惟一不同的是nodeID是可选的。
- Sam was born in the country and had a deep affinity with nature .
	- 萨姆在乡下出生，特别喜爱大自然。
# 形态
- #形态/word_pl affinities
