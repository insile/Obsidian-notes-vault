---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈæbsəluːt/； 美：/ˈæbsəluːt/
- #词性/adj  绝对的；完全的；肯定的；独立的；全部的；明确的；(英语口语中尤用以强调)道地的，确实的，十足的；无疑的；不受限制的
- #词性/n  绝对真理(指思想或原理)
# 例句
- However , our country in promoting the process of trade liberalization should be clear that trade liberalization does not mean that absolute free trade .
	- 但是，我国在推进贸易自由化的进程中应该明确一点，那就是贸易自由化不等于完全的自由贸易。
- Consequently , she gave me absolute freedom of choice .
	- 结果她给了我完全的选择自由。
- Beauty cannot be measured by any absolute standard .
	- 美是不可能用任何绝对标准来衡量的。
# 形态
- #形态/word_pl absolutes
