---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈdɔːrəbl/； 美：/əˈdɔːrəbl/
- #词性/adj  可爱的；讨人喜爱的
# 例句
- What an adorable child !
	- 多可爱的小孩呀！
- We have three adorable children .
	- 我们有3个可爱的孩子。
- ' How adorable ! ' she trills .
	- “真可爱！”她尖声说。
