---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/eɪk/； 美：/eɪk/
- #词性/vi  疼痛；渴望；隐痛
- #词性/n  (身体某部位的)疼痛
# 例句
- Poor posture can cause neck ache , headaches and breathing problems .
	- 姿势不当会导致颈部疼痛、头痛和呼吸困难。
- Sharpe 's leg and shoulder began to ache , a sure sign of rain
	- 夏普的腿和肩膀开始疼痛，这预示着肯定要下雨了。
- My arms were aching so I shifted position slightly .
	- 我胳膊疼了，所以稍微变了变姿势。
# 形态
- #形态/word_third aches
- #形态/word_ing aching
- #形态/word_done ached
- #形态/word_pl aches
- #形态/word_past ached
