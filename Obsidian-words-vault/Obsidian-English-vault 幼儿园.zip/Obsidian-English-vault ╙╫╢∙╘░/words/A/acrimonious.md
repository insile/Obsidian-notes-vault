---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌækrɪˈməʊniəs/； 美：/ˌækrɪˈmoʊniəs/
- #词性/adj  激烈的；尖刻的；讥讽的
# 例句
- An acrimonious meeting , discussion , atmosphere .
	- 争吵激烈的会议、讨论、气氛。
- They had an acrimonious discussion about money .
	- 他们为钱的事展开了激烈的讨论。
- His parents went through an acrimonious divorce .
	- 他的父母在激烈争吵中离了婚。
