# 词义
- 英：/əˌpɒləˈdʒetɪk/； 美：/əˌpɑːləˈdʒetɪk/
- #adj 道歉的，谢罪的，愧疚的；辩护的，辩解的
- #n （为信仰、事业等所作的）辩护（书）
# 例句
- As I reproached him , he heard me in silence , gave me finally an apologetic smile .
	- 当我责备他的时候，他静静听著，最后报以道歉的微笑。
- The results are more like the apologetic robot rebel Sonny from the film I , Robot , starring Will Smith , than the homicidal machines of Terminator , but they demonstrate an important principal .
	- 相比那些会杀人的终结者机器人，这个试验的结果更像是威尔·史密斯主演的《我与机器人》中的那个会道歉的机器人索尼，但是它们都遵守重要的原则。
- ‘ Sorry , ’ she said , with an apologetic smile .
	- “对不起。”她说，歉然一笑。
