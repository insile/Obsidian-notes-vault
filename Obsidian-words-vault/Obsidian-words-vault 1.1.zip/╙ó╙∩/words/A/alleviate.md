# 词义
- 英：/əˈliːvieɪt/； 美：/əˈliːvieɪt/
- #vt 减轻；缓解；缓和
# 例句
- Nowadays , a great deal can be done to alleviate back pain .
	- 如今，减轻背部疼痛可以有许多方法。
- Nothing could alleviate his distress .
	- 什么都不能减轻他的痛苦。
- A number of measures were taken to alleviate the problem .
	- 采取了一系列措施缓解这个问题。
# 形态
- #word_third alleviates
- #word_ing alleviating
- #word_done alleviated
- #word_past alleviated
