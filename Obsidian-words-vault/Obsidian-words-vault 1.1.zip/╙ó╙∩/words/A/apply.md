# 词义
- 英：/əˈplaɪ/； 美：/əˈplaɪ/
- #v 应用；(通常以书面形式)申请，请求；使用；有关；涂；施；敷；手压；勤奋工作
# 例句
- What 's the form when you apply for a research grant ?
	- 申请科研补助金按常规应该怎么办？
- You can apply for citizenship after five years ' residency .
	- 居住五年后可申请公民资格。
- A large number of people have applied for the job .
	- 许多人申请了这工作。
# 形态
- #word_third applies
- #word_ing applying
- #word_done applied
- #word_past applied
