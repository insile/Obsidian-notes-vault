# 词义
- 英：/ˈæbsənt , æbˈsent/； 美：/ˈæbsənt , æbˈsent/
- #adj 不在的；不存在；缺席的；缺少；心不在焉的；出神的
- #vt 不在；缺席；不参加
- #prep 没有；缺乏
# 例句
- It 's the manager 's job to organize cover for staff who are absent .
	- 安排他人顶替缺席的员工是经理的工作。
- The number of students absent is two today .
	- 今天学生缺席的人数是两个。
- You 've been absent six times according to our records .
	- 根据我们的记录，你已经缺席六次了。
# 形态
- #word_third absents
- #word_ing absenting
- #word_done absented
- #word_past absented
