# 词义
- 英：/ænˈtɪsɪpeɪt/； 美：/ænˈtɪsɪpeɪt/
- #vt 预期；预见，预计(并做准备)；预料；期望；期盼；先于…做
# 例句
- We anticipate that sales will rise next year .
	- 我们预料明年销售量将会增加。
- We don 't anticipate any major problems .
	- 我们预料不会发生什么大问题。
- We need someone who can anticipate and respond to changes in the fashion industry .
	- 我们需要一个能预见时装业变化并做相应安排的人。
# 形态
- #word_third anticipates
- #word_ing anticipating
- #word_done anticipated
- #word_past anticipated
