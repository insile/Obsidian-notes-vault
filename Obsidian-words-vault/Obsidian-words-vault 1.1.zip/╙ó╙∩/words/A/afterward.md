# 词义
- 英：/ˈɑːftə(r)wə(r)d/； 美：/ˈæftərwərd/
- #adv 之后；后来
# 例句
- Afterward he changed the research direction from the country the residential society .
	- 后来他把研究方向从国家转向了市民社会。
- The State Department afterward intervened frequently on a diplomatic level .
	- 后来，国务院在外交事务方面颇加干涉。
- Not long afterward she received five calls in one day .
	- 不久之后，她一天内就接到了5个电话。
