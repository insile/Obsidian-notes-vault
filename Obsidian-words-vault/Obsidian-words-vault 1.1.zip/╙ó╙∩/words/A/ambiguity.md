# 词义
- 英：/ˌæmbɪˈɡjuːəti/； 美：/ˌæmbɪˈɡjuːəti/
- #n 歧义；不明确；模棱两可；一语多义；含混不清的语句
# 例句
- It 's a work full of paradox and ambiguity .
	- 这部作品充满了似非而是及模棱两可之处。
- The course teaches students to avoid ambiguity and obscurity of expression .
	- 这门课程教学生避免表达上的模棱两可、含混不清。
- You must understand the ambiguity of my position .
	- 你必须理解我处的位置不明确。
# 形态
- #word_pl ambiguities
