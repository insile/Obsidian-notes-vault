# 词义
- 英：/əˈbrest/； 美：/əˈbrest/
- #adv 并排；并肩；并列
- #adj 并列；平等
# 例句
- The bridge can take four lorries abreast .
	- 这座大桥可容4辆卡车并列通行。
- He must keep abreast of new resources for international financing that arise from improvements in the financial services industry .
	- 他必须保持国际金融和金融服务工业在经济资源上的并列发展。
- A police car drew abreast of us and signalled us to stop .
	- 一辆警车开过来与我们并排，示意我们停下来。
