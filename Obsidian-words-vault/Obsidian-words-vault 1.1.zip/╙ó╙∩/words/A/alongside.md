# 词义
- 英：/əˌlɒŋˈsaɪd/； 美：/əˌlɔːŋˈsaɪd/
- #prep 与…一起；在…旁边；与…同时；沿着
- #adv 在…旁边；与…并排；在…的侧面
# 例句
- A variety of heavy industries grew up alongside the port .
	- 各种重工业沿着港口逐渐发展起来。
- He crossed the street and walked alongside Central Park
	- 他穿过街道，沿着中央公园走。
- Traditional beliefs still flourish alongside a modern urban lifestyle .
	- 现代城市生活方式盛行的同时，传统信念仍然大行其道。
