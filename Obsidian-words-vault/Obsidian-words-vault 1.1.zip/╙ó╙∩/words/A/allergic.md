# 词义
- 英：/əˈlɜːdʒɪk/； 美：/əˈlɜːrdʒɪk/
- #adj (对…)变态反应的，变应的，过敏的；过敏性的；变应性的；变态反应性的；厌恶；对…十分反感
# 例句
- The rice bran protein is known as high quality vegetable protein through the world , it has not only the high nutritional value , but also the low allergic characteristic .
	- 米糠蛋白是世界公认的优质植物蛋白，它不但营养价值高且具有低过敏性的特点。
- Find which food you are allergic to by a process of elimination .
	- 用排除法找出你对哪种食物过敏。
- Dairy products may provoke allergic reactions in some people .
	- 乳制品可能会引起某些人的过敏反应。
