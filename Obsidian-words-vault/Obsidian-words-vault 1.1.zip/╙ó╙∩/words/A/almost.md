# 词义
- 英：/ˈɔːlməʊst/； 美：/ˈɔːlmoʊst/
- #adv 几乎，差不多
# 例句
- That one mistake almost cost him his life .
	- 那一个差错几乎使他丧命。
- The pain was almost more than he could bear .
	- 这种痛苦几乎使他无法忍受。
- It 's almost time to go .
	- 是差不多该走的时候了。
