# 词义
- 英：/ˈænjuəl/； 美：/ˈænjuəl/
- #adj 年度的；每年的；一年的；一年一次的
- #n 年报；一年生植物；年鉴；年刊；一季生植物
# 例句
- How much is the annual ground rent ?
	- 每年的地租是多少？
- Japan 's annual trade surplus is in the region of 100 billion dollars .
	- 日本每年的贸易顺差额在1,000亿美元左右。
- How much annual leave do you get ?
	- 你们的年假有多长？
# 形态
- #word_pl annuals
