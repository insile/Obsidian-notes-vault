# 词义
- 英：/əbˈsɜːd/； 美：/əbˈsɜːrd/
- #adj 荒谬的；荒唐的；荒诞派的；怪诞不经的
- #n 荒诞的事物；悖理的东西
# 例句
- The policy was followed to an absurd extreme .
	- 这项政策被执行到了极端荒谬的程度。
- No doubt it is very absurd .
	- 这无疑是十分荒谬的。
- He has a good sense of the absurd .
	- 他对荒诞事物有较强的识别能力。
