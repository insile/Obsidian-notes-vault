# 词义
- 英：/ˈɑːməmənt/； 美：/ˈɑːrməmənt/
- #n 军备；武器；武装；战备
# 例句
- The fears have prompted several countries to embark on massive armament plans .
	- 几个国家开始实施大规模的军备计划，以防患于未然。
- In 1937 he was seconded to the Royal Canadian Air Force in Ottawa as air armament adviser
	- 1937年他被临时调往渥太华的加拿大皇家空军担任军备顾问。
- A factory making armaments had been bombed the night before and a residential area not far away had been pulverized .
	- 前天晚上，一家兵工厂被炸，不远处的居民区也被夷为平地。
# 形态
- #word_pl armaments
