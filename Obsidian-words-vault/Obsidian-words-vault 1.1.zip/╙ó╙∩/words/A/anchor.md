# 词义
- 英：/ˈæŋkə(r)/； 美：/ˈæŋkər/
- #n 锚；支柱，靠山；固定桩，系缚物；主持（电视或电台节目，尤指新闻节目）
- #v 把…系住（或扎牢、粘住），使固定；抛锚，下锚；使扎根，使基于；主持
# 例句
- We sailed into the bay and dropped anchor in five fathoms of water .
	- 我们驶进海湾，将锚抛进5英寻深的水里。
- Secure the anchor by lashing it to the rail
	- 把锚系到栏杆上拴牢。
- She anchored the evening news for seven years .
	- 她主持了七年晚间新闻报道。
# 形态
- #word_third anchors
- #word_ing anchoring
- #word_done anchored
- #word_pl anchors
- #word_past anchored
