# 词义
- 英：/ˈælədʒi/； 美：/ˈælərdʒi/
- #n 过敏；变态反应
# 例句
- I have an allergy to animal hair .
	- 我对动物毛过敏。
- Allergy to cats is one of the commonest causes of asthma .
	- 对猫类过敏是哮喘病发作最常见的诱因之一。
- This type of allergy can very occasionally be fatal .
	- 这类过敏症在极个别情况下有可能是致命的。
# 形态
- #word_pl allergies
