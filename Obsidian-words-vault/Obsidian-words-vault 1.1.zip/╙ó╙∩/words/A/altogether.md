# 词义
- 英：/ˌɔːltəˈɡeðə(r)/； 美：/ˌɔːltəˈɡeðər/
- #adv (用以强调)完全；总共；(表示总数或总额)一共；全部；总之；总而言之
- #n 整个；〈口〉裸体
# 例句
- There are altogether 40 students in this class .
	- 这个班总共有40名学生。
- After shipment , it will be altogether four to five weeks before the goods can reach our retailers .
	- 从交货到零售商收到货物总共需要4至5个星期。
- It was an altogether different situation .
	- 这完全是另外一种情况。
