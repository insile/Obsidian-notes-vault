# 词义
- 英：/ˌɑːtɪˈfɪʃl/； 美：/ˌɑːrtɪˈfɪʃl/
- #adj 人工的，人造的，人为的；假的，假装的，矫揉造作的，模拟的；非原地产的，人工栽培的
# 例句
- The crystal is natural , not artificial .
	- 这块水晶是天然的，不是人造的。
- Conversely , " artificial " gets equated with unhealthy .
	- 反之，“人造的”就等同于不健康的。
- A job interview is a very artificial situation .
	- 求职面试是一个非常不自然的场面。
