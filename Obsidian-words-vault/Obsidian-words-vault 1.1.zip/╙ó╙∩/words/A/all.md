# 词义
- 英：/ɔːl/； 美：/ɔːl/
- #det 所有；全部；一切；(与单数名词连用，表示某事在某段时间内持续发生)全部的，整个的；全体；唯一；极度；无论什么
- #pron 所有；全部；一切；全体；所有的事物；唯一的事物
- #adv 完全；非常；太；十分；过分；每方
- #adj 一切；全；整个；全体
- #n 全部；一切；全体
# 例句
- He got to try out all the new software .
	- 他得以试用了所有的新软件。
- She seems to be well in with all the right people .
	- 她似乎和所有大人物都关系很好。
- People came from all over the world to view her work .
	- 观众从世界各地涌来欣赏她的作品。
