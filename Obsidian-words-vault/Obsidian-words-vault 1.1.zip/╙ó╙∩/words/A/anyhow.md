# 词义
- 英：/ˈenihaʊ/； 美：/ˈenihaʊ/
- #adv 无论如何；随便地；杂乱无章地
# 例句
- It may be risky but we will chance it anyhow .
	- 这可能有危险，但我们无论如何要冒一冒险。
- Anyhow , knowing how to use the Internet is important .
	- 无论如何,知道如何使用互联网是很重要的。
- She piled the papers in a heap on her desk , just anyhow .
	- 她把文件在桌上随便搁成一堆。
