# 词义
- 英：/ɑːk/； 美：/ɑːrk/
- #n 电弧；弧；弧形
- #vi 作弧形运动；形成电弧
# 例句
- The rainbow formed a beautiful arc in the sky .
	- 虹在天空中形成了一个美丽的弧。
- Numerical control air plasma arc cutting technology and its application
	- 数控空气等离子弧切割技术及应用
- Joan of Arc was burnt at the stake .
	- 圣女贞德被处以火刑。
# 形态
- #word_third arcs
- #word_ing arcing
- #word_done arced
- #word_past arced
