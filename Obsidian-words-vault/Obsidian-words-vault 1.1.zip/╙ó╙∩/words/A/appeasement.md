# 词义
- 英：/əˈpiːzmənt/； 美：/əˈpiːzmənt/
- #n 平息;安抚;绥靖
# 例句
- He denied there is a policy of appeasement
	- 他否认有绥靖政策存在。
- They have already been accused of appeasement by more militant organisations .
	- 已有更多的好战组织谴责他们采取姑息态度。
- Appeasement has come home to roost
	- 绥靖政策的恶果已经显现出来了。
