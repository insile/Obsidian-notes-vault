# 词义
- 英：/əˈtʃiːvmənt/； 美：/əˈtʃiːvmənt/
- #n 达到；成就；成绩；完成；功绩
# 例句
- It was no small achievement getting her to agree to the deal .
	- 能让她同意那笔交易可是个不小的成就。
- It was a spectacular achievement on their part .
	- 这是他们取得的一项了不起的成就。
- 2004 was a year of solid achievement .
	- 2004年是颇有成绩的一年。
# 形态
- #word_pl achievements
