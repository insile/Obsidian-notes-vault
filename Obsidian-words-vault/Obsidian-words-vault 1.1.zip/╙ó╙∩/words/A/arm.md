# 词义
- 英：/ɑːm/； 美：/ɑːrm/
- #n 臂；手臂；扶手；上肢；袖子；分部；臂状物；狭长港湾
- #v 武装；装备；备战；准备发射；给…装上引信；打开…的保险；使(炸弹等)随时爆炸
# 例句
- They walked along arm in arm .
	- 他们臂挽着臂一路走着。
- His collar bone only hurt when he lifted his arm .
	- 他的锁骨只有在抬臂时才感觉到痛。
- He doesn 't invest in the arms industry on principle .
	- 他根据自己的信条，不投资军火工业。
# 形态
- #word_third arms
- #word_ing arming
- #word_done armed
- #word_pl arms
- #word_past armed
