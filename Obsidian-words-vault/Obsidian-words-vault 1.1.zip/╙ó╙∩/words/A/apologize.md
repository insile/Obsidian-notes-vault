# 词义
- 英：/əˈpɒlədʒaɪz/； 美：/əˈpɑːlədʒaɪz/
- #vi 道歉；谢罪
# 例句
- And , would you believe , he didn 't even apologize !
	- 而且，可气的是，他连个道歉都没有！
- The best thing to do would be to apologize .
	- 最恰当的做法应该是道歉。
- We would like to apologize for the delay .
	- 我们愿对延迟表示歉意。
# 形态
- #word_third apologizes
- #word_ing apologizing
- #word_done apologized
- #word_past apologized
