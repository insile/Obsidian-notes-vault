# 词义
- 英：/ˌɔːltəˈreɪʃn/； 美：/ˌɔːltəˈreɪʃn/
- #n 改变；更改；变化；改动
# 例句
- Like other threats , a computer virus can cause the loss or alteration of programs or data .
	- 象其它威胁一样的是，计算机病毒可以引起程序或数据的丢失或改变。
- One obvious impact is the radical alteration of the land surface .
	- 一种显而易见的影响是大地表面剧烈的改变。
- The alterations should give us extra floor space .
	- 这些改动应该使我们有更大的居住面积。
# 形态
- #word_pl alterations
