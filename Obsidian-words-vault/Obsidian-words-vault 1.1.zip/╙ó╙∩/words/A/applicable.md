# 词义
- 英：/əˈplɪkəbl/； 美：/ˈæplɪkəbl/
- #adj 适用；合适；可应用的
# 例句
- There are several variables applicable to a visualization pattern .
	- 对可视化模板有一些可应用的变量。
- Nor is there a vast pool of applicable analytical or quantitative methods we could use .
	- 大量的可应用的分析或者定量的方法也是不存在的。
- Much of the form was not applicable to me .
	- 表格中很多部分不适用于我。
