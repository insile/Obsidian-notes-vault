# 词义
- 英：/əˈmɪd/； 美：/əˈmɪd/
- #prep 在…中；在…之中；在…过程中；四周是
# 例句
- Oil shares advanced amid economic recovery hopes .
	- 在一片经济复苏的希望中石油股票价格上涨。
- The trial took place amid a blaze of publicity .
	- 审讯在全面曝光的情况下进行。
- The product was launched amid much fanfare worldwide .
	- 这个产品在世界各地隆重推出。
