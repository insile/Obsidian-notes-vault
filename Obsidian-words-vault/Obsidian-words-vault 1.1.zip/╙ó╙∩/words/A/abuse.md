# 词义
- 英：/əˈbjuːs , əˈbjuːz/； 美：/əˈbjuːs , əˈbjuːz/
- #n 滥用；虐待；辱骂；恶语；妄用
- #vt 滥用，妄用(权力、所知所闻)；滥用(以致危害健康)；虐待；性虐待；伤害；辱骂
# 例句
- The system is open to abuse .
	- 这项制度容易被滥用。
- The government is taking action to combat drug abuse .
	- 政府正在采取措施，打击滥用毒品。
- Much of the crime in this area is related to drug abuse .
	- 这一地区的许多犯罪都与吸毒有关。
# 形态
- #word_third abuses
- #word_ing abusing
- #word_done abused
- #word_pl abuses
- #word_past abused
