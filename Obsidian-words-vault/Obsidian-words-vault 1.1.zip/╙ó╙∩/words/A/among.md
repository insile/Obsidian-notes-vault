# 词义
- 英：/əˈmʌŋ/； 美：/əˈmʌŋ/
- #prep 在…中；在(其)中；在…之间；…之一；周围是；在三者或以上中(分配或选择)
# 例句
- It put forward that among older adults , resilience could positively influence successful aging .
	- 提出在中老年人群中复原力正向性影响成功老化；
- The theory was introduced into China and popularized among kindergartens , primary and high schools gradually .
	- 多元智能理论引进中国后，首先在中、小学和幼儿园教育中得到推广和应用。
- The money was distributed among schools in the area .
	- 这笔款项是在本地区的学校中分配的。
