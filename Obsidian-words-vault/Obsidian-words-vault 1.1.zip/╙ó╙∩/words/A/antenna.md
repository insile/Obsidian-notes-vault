# 词义
- 英：/ænˈtenə/； 美：/ænˈtenə/
- #n 天线；触角；触须
# 例句
- They erected a television antenna on the roof .
	- 他们在屋顶上架起了电视天线。
- The radio may have an antenna attached to it .
	- 收音机可以外接一根天线。
- The minister was praised for his acute political antennae .
	- 这位部长以政治触觉敏锐而为人称道。
# 形态
- #word_pl antennas
