# 词义
- 英：/ˈeɪprən/； 美：/ˈeɪprən/
- #n 围裙；(机场的)停机坪；台口(舞台幕前的部分)
- #v 用围裙围住
# 例句
- Remember to bring an apron or an old shirt to protect your clothes
	- 记得带一个围裙或者一件旧衬衫来，免得弄脏你的衣服。
- The cook 's apron covered her middle .
	- 厨用围裙裹着她的腰部。
- The British prime minister is too apt to cling to Washington 's apron strings .
	- 英国首相对华府过于唯命是从。
# 形态
- #word_pl aprons
