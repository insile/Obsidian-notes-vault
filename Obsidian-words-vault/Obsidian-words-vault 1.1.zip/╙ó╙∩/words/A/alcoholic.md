# 词义
- 英：/ˌælkəˈhɒlɪk/； 美：/ˌælkəˈhɑːlɪk/
- #adj 酒精的；含酒精的；饮酒引起的
- #n 酒鬼；酒精中毒者；嗜酒如命者
# 例句
- Alcoholic beverages are not sold to children .
	- 含酒精的饮料不出售给儿童。
- Coca-Cola is the best-selling soft ( non - alcoholic ) drink in the world .
	- 可口可乐是全世界销路最好的软饮料（不含酒精的饮料）。
- It is very alcoholic , sometimes near the strength of port
	- 它的酒精浓度很高，有时接近波尔图葡萄酒的浓度。
# 形态
- #word_pl alcoholics
