# 词义
- 英：/əˌliːvɪˈeɪʃ(ə)n/； 美：/əˌliviˈeɪʃən/
- #n 减轻；缓解；缓和；镇痛物
# 例句
- The cost reduction achieved in this way will benefit patients and the society in burden alleviation .
	- 集中招标采购降低的采购成本要让利于患者，减轻社会负担
- Even if rice prices were to plummet , other brakes on poverty alleviation remain .
	- 就算大米价格下跌，其它阻止导致贫困的因素仍然存在。
- This year is the time to secure a decisive victory in building a moderately prosperous society in all respects and achieve the goal of poverty alleviation and sense of responsibility of contemporary teachers .
	- 今年是决胜全面建成小康社会、决战脱贫攻坚之年，全国广大教师用爱心和智慧阻断贫困代际传递，点亮万千乡村孩子的人生梦想，展现了当代人民教师的高尚师德和责任担当。
