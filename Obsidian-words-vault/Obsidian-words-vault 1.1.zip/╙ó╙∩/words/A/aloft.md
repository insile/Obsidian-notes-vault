# 词义
- 英：/əˈlɒft/； 美：/əˈlɔːft/
- #adv #adj 在空中；在高处；在桅顶 ( 或帆索高处 ) ( 的 ) 
- #prep 在…顶上, 在…之上
# 例句
- A small unmanned balloon set aloft to observe atmospheric conditions .
	- 在高处观察气象现象的小的无人驾驶的气球。
- A seat consisting of a board and a rope ; used while working aloft or over the side of a ship .
	- 由一块板和一根绳子组成；用于在高处作业或在船侧作业。
- Four of the nine starting balloons were still aloft the next day .
	- 9个开幕气球第二天还有4个飘在空中。
