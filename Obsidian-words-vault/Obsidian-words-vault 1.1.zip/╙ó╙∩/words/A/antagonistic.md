# 词义
- 英：/ænˌtæɡəˈnɪstɪk/； 美：/ænˌtæɡəˈnɪstɪk/
- #adj 对抗的；敌对的；敌意的；对立情绪的
# 例句
- Each couple of the research traditions is incommensurable and mutually complemental , but not opposite and antagonistic .
	- 其中，每一对研究传统之间是不可通约而又相互补充的关系，但不是对立和对抗的关系。
- A spy who works for two mutually antagonistic countries .
	- 为互相敌对的国家工作的间谍。
- Nearly all the women I interviewed were aggressively antagonistic to the idea .
	- 几乎我采访过的所有女性都对这个观点表示了强烈的反感。
