# 词义
- 英：/əˈpɑːt/； 美：/əˈpɑːrt/
- #adv 分开；分离；(指空间或时间)相隔，相距；除外；分开地；不在一起；成碎片
- #adj (与众)不同的
# 例句
- Just like we will never be apart and spend lives together .
	- 就像从不会分开地等待明天。就像永不曾离去地度过那年。
- Though your smile has gone , we will never be apart .
	- 虽然你的微笑已离去，但是我们将无法分开地。
- Quite apart from all the work , he had financial problems .
	- 除了那么多工作，他还有财务困难。
