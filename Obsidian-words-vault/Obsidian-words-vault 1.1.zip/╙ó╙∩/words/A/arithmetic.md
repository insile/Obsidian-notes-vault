# 词义
- 英：/əˈrɪθmətɪk/； 美：/əˈrɪθmətɪk/
- #n 算术；演算，计算；数据统计
- #adj 算术的，运算的
# 例句
- He 's not very good at arithmetic .
	- 他不太擅长算术。
- They will concentrate on teaching the basics of reading , writing and arithmetic
	- 他们将集中教授阅读、写作和算术基础知识。
- I think there 's something wrong with your arithmetic .
	- 我认为你的计算有错。
# 形态
- #word_pl arithmetics
