# 词义
- 英：/əˈnæləsɪs/； 美：/əˈnæləsɪs/
- #n (对物质的)分析；(对事物的)分析结果
# 例句
- This information is only raw data and will need further analysis .
	- 这些资料只是原始数据，还需要进一步进行分析。
- The blood samples are sent to the laboratory for analysis .
	- 血样要送往实验室进行分析。
- The book is an analysis of poverty and its causes .
	- 这本书分析了贫困及其原因。
# 形态
- #word_pl analyses
