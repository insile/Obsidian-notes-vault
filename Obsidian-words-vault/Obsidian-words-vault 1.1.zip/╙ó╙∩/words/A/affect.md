# 词义
- 英：/əˈfekt/； 美：/əˈfekt/
- #v 影响；使感染；侵袭；假装；使悲伤(或怜悯等)；炫耀；(感情上)深深打动
- #n 【心】情感；【数】偏差
# 例句
- People tend to think that the problem will never affect them .
	- 人们往往认为这个问题绝不会影响到他们。
- The new law will affect us all , directly or indirectly .
	- 新的法规将直接或间接地影响我们所有的人。
- Many external influences can affect your state of mind .
	- 许多外在因素都可能影响人的心情。
# 形态
- #word_third affects
- #word_ing affecting
- #word_done affected
- #word_past affected
