# 词义
- 英：/æmˈbæsədə(r)/； 美：/æmˈbæsədər/
- #n 大使；使节
# 例句
- The ambassador would not be drawn on questions of a political nature
	- 大使不会对政治问题发表意见。
- Also among the speakers was the new American ambassador to Moscow .
	- 发言者当中还有驻莫斯科的新任美国大使。
- The best ambassadors for the sport are the players .
	- 这种运动最好的大使就是运动员。
# 形态
- #word_pl ambassadors
