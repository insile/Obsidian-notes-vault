# 词义
- 英：/əˈraʊnd/； 美：/əˈraʊnd/
- #adv 周围；围绕；大约；四周；环绕；出现；到处；转弯；闲散地
- #prep 围绕；环绕；绕着；到处；在那边；从那边；到那边；同…一致
# 例句
- The story is built around a group of high school dropouts .
	- 故事围绕着一群辍学的中学生展开。
- The house is built around a central courtyard .
	- 这房子是围绕着中央的庭院而建的。
- We were shown around the school by one of the students .
	- 我们由一名学生领着参观了学校。
