# 词义
- 英：/ˌænɪˈmeɪʃn/； 美：/ˌænɪˈmeɪʃn/
- #n 动画；动画片；(指电影、录像、电脑游戏的)动画制作；活力；生气；富有生命力
# 例句
- ‘ Dinosaur ’ combines CGI animation with live-action location shots .
	- 《恐龙》结合了电脑生成的动画和外景地实地拍摄的画面。
- The films are a mix of animation and full-length features .
	- 这些电影将动画制作和长篇故事片融为一体。
- His face was drained of all colour and animation .
	- 他面如死灰。
# 形态
- #word_pl animations
