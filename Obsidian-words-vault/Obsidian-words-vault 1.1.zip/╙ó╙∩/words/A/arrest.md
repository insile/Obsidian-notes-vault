# 词义
- 英：/əˈrest/； 美：/əˈrest/
- #v 逮捕；拘留；阻止；吸引(注意)；心跳停止；中止
- #n 逮捕；拘捕；停止；中止
# 例句
- Our information is that the police will shortly make an arrest .
	- 我们得到的情报是，警察不久就要逮捕人了。
- The police arrived to arrest him .
	- 警察赶来逮捕了他。
- It was reported that several people had been arrested .
	- 据报道已有数人被捕。
# 形态
- #word_third arrests
- #word_ing arresting
- #word_done arrested
- #word_past arrested
