# 词义
- 英：/əˈreɪndʒmənt/； 美：/əˈreɪndʒmənt/
- #n 安排；布置；约定；商定；筹备；安排方式；改编乐曲；整理好的东西
# 例句
- Many people have expressed their dissatisfaction with the arrangement .
	- 许多人表示对这一安排不满。
- Are you happy with that arrangement ?
	- 你对这一安排感到满意吗？
- We can come to an arrangement over the price .
	- 我们可以就价格问题达成一项协议。
# 形态
- #word_pl arrangements
