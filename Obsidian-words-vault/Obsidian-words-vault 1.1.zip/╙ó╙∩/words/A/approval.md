# 词义
- 英：/əˈpruːvl/； 美：/əˈpruːvl/
- #n 批准；通过(计划、要求等)；同意；赞成；(商品)试用
# 例句
- Senior management have given their seal of approval to the plans .
	- 高层管理部门已经正式批准这些计划。
- The project has the government 's stamp of approval .
	- 工程已获得政府批准。
- The film was made with the Prince 's full knowledge and approval .
	- 这部影片是在王子充分了解和认可的情况下拍摄的。
# 形态
- #word_pl approvals
