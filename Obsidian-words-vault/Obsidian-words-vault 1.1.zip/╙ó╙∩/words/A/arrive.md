# 词义
- 英：/əˈraɪv/； 美：/əˈraɪv/
- #vi 到达；抵达；到来；发生；送达；寄到
# 例句
- Please make every endeavour to arrive on time .
	- 请尽全力按时到达。
- You must arrive at the time stated .
	- 你必须在规定时间到达。
- I keep thinking back to the day I arrived here .
	- 我不断回想起刚到这儿那一天的情景。
# 形态
- #word_third arrives
- #word_ing arriving
- #word_done arrived
- #word_past arrived
