# 词义
- 英：/ˈɑːdnt/； 美：/ˈɑːrdnt/
- #adj 热烈的；热心的；激情的
# 例句
- No matter what ardent cosmopolitans or crazed conspiracy theorists believe , there is no world government .
	- 无论是热心的世界主义者也好，还是疯狂的阴谋论者也好，都相信：根本不存在什么世界政府。
- An ardent early supporter of a cause or reform .
	- 对一项事业或改革的热心的早期支持者。
- The general was an unattractive man to all but his most ardent admirers
	- 除了他那些铁杆崇拜者外，这位将军对于其他人并无吸引力。
