# 词义
- 英：/ˈɑːtɪst/； 美：/ˈɑːrtɪst/
- #n 艺术家；(尤指)画家
# 例句
- The artist combines different techniques in the same painting .
	- 这位艺术家在同一幅画中把不同的画法结合在一起。
- She 's an artist whose work I really admire .
	- 她这位艺术家的作品令我赞赏不已。
- The exhibition gives local artists an opportunity to display their work .
	- 这次展览为当地艺术家提供了展示自己作品的机会。
# 形态
- #word_pl artists
