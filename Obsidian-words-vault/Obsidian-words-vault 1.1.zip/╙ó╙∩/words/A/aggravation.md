# 词义
- #n 加重；恶化
# 例句
- The drug may cause an aggravation of the condition .
	- 这种药可能导致病情恶化。
- Can 't stand the aggravation , all day I get aggravation . You know how it is . "
	- 我整天都碰到令人发火的事，你可想而知这是什么滋味。
- Study on the Social Factors about the Aggravation of Flood Disaster
	- 我国洪涝灾害加剧的社会因素分析与减灾对策
# 形态
- #word_pl aggravations
