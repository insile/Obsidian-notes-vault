# 词义
- 英：/ɑːˈtɪkjuleɪt , ɑːˈtɪkjələt/； 美：/ɑːrˈtɪkjuleɪt , ɑːrˈtɪkjələt/
- #v 表达；明确表达；清楚说明；口齿清楚；用关节连接；与…合成整体
- #adj 善于表达的；发音清晰的；口齿清楚的
# 例句
- He finds it very difficult to articulate his distress .
	- 他感到很难表达清楚自己的痛苦。
- " If you understand the material and have the ability to articulate your thoughts , they should be a breeze . "
	- 如果你能够理解材料，并且能表达自己的观点，那这就是很轻而易举的事情。
- These courses are designed to articulate with university degrees .
	- 这些课程旨在与大学学位接轨。
# 形态
- #word_third articulates
- #word_ing articulating
- #word_done articulated
- #word_past articulated
