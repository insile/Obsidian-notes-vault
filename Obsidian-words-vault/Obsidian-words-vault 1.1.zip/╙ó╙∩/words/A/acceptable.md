# 词义
- 英：/əkˈseptəbl/； 美：/əkˈseptəbl/
- #adj 可接受的；(社会上)认同的，认可的；还可以的；令人满意的；尚可的；可容许的；差强人意的
# 例句
- Famous teacher 's personal brand is concentrated reflection of the unique advantage of a teacher which is socially acceptable .
	- 名教师的个人品牌，是教师某方面独特优势的集中反映，是社会广泛认同的产物。
- What I am saying is that maybe the faith you have is not based on Jesus or the Bible , but rather on your own comfort or what culture has deemed acceptable .
	- 其实我真正要说的是，或许你现在的信心不是建立在耶稣或是圣经之上的，而是建立在你的安逸生活上，或是建立在仅为你的文化所认同的层面上。
- There are two types of qualification ─ either is acceptable .
	- 有两种资格证明——任何一种都可以接受。
