# 词义
- 英：/ˌækjuˈzeɪʃn/； 美：/ˌækjuˈzeɪʃn/
- #n 指控；控告；起诉；谴责；告发
# 例句
- He denied the accusation that he had ignored the problems .
	- 他否认别人对他忽视这些问题的指控。
- She was deeply pained by the accusation .
	- 这一指控使她极为痛苦。
- If you 're going to make accusations , you 'd better get your facts right .
	- 你要是打算控告最好把证据弄确凿。
# 形态
- #word_pl accusations
