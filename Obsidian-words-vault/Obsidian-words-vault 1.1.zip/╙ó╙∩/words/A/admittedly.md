# 词义
- 英：/ədˈmɪtɪdli/； 美：/ədˈmɪtɪdli/
- #adv 诚然；(尤用于句首)无可否认
# 例句
- It 's only a theory , admittedly , but the pieces fit together
	- 诚然，这只是一种理论，但各部分互相吻合。
- Admittedly , this relationship is based on correlations4 , which means they don 't say a nutrient1 caused anything .
	- 诚然，这种关系建立在相关性的基础上，这意味着它们无法证实营养就是原因。
- Admittedly , it is rather expensive but you don 't need to use much .
	- 它的确很贵，但不需要用得很多。
