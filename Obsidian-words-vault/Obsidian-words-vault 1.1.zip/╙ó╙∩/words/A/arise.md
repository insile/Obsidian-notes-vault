# 词义
- 英：/əˈraɪz/； 美：/əˈraɪz/
- #vi (因…)产生；出现；(由…)引起；发生；发展；起床；（随着人走近而）逐渐显现；群起反对
# 例句
- Only a finite number of situations can arise
	- 只有有限的几种情况可能会发生。
- However , such gains do not arise in the other Contracting State they shall be taxable only in the Contracting State of which the alienator is a resident .
	- 但是，如果这种收益不是发生于缔约国另一方，应仅在转让者为居民的缔约国征税。
- We will contact you again if the need arises .
	- 如果有必要，我们会再次和你联系。
# 形态
- #word_third arises
- #word_ing arising
- #word_done arisen
- #word_past arose
