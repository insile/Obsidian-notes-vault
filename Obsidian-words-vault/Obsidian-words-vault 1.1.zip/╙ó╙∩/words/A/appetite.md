# 词义
- 英：/ˈæpɪtaɪt/； 美：/ˈæpɪtaɪt/
- #n 食欲；胃口；强烈欲望
# 例句
- She went for a long walk to work up an appetite .
	- 她为了增加食欲散了很长时间的步。
- The sandwich took the edge off my appetite .
	- 这份三明治使我食欲大减。
- The walk gave me a good appetite .
	- 散步使我胃口大开。
# 形态
- #word_pl appetites
