# 词义
- 英：/ɑːt/； 美：/ɑːrt/
- #n 艺术 ( 包括绘画、雕塑、音乐、舞蹈、文学等 )；技术，技艺；方法，诀窍，本领；美术 ( 指绘画、绘图和雕塑 )；人文科学，文科；艺术技巧；(总称)美术 ( 作 ) 品；艺术 ( 作 ) 品
- #v  <古>be的现在式单数第二人称
- #adj 美术 ( 或艺术 ) ( 品 ) 的；美术 ( 或艺术 ) 家的
# 例句
- You can 't do much in the art line without training .
	- 没经过训练，你在艺术行业是不会有多大作为的。
- The short story is a difficult art form to master .
	- 短篇小说是一种很难掌握的艺术形式。
- The system was state of the art .
	- 这一系统是当时最先进的。
# 形态
- #word_pl arts
