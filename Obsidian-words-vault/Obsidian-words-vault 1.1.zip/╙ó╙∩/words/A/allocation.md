# 词义
- 英：/ˌæləˈkeɪʃn/； 美：/ˌæləˈkeɪʃn/
- #n 分配；拨；划；划拨的款项；分配的东西；拨给的场地
# 例句
- Personal assessment allocation interest and penalties receivable on taxes
	- 拨入个人入息课税计算款项应收欠税利息及罚款
- He said $ 10 million of the latest allocation will be devoted to the needs of people in Somalia .
	- 他表示，最近拨出的1000万美元将用于对索马里（Somalia）人民的紧急援助。
- Town planning and land allocation had to be coordinated .
	- 必须协调城市规划和土地分配之间的关系。
# 形态
- #word_pl allocations
