# 词义
- 英：/ˈeɪndʒl/； 美：/ˈeɪndʒl/
- #n 天使；安琪儿(指善良的人或可爱的小孩)；大好人(感激某人时所说)；善人
# 例句
- She could not see herself in the role of ministering angel .
	- 她想象不出自己成为一名救死扶伤的天使会是什么样。
- The ill-advised conceit of the guardian angel dooms the film from the start .
	- 对守护天使的蹩脚设计弄巧成拙，从一开始就注定这部电影要失败。
- John is no angel , believe me .
	- 相信我，约翰绝非善良之辈。
# 形态
- #word_pl angels
