# 词义
- 英：/əˈplɔːd/； 美：/əˈplɔːd/
- #v 鼓掌；赞赏；称赞；赞许
# 例句
- They rose to applaud the speaker .
	- 他们起立向演讲者鼓掌。
- Every person stood to applaud his unforgettable act of courage .
	- 所有人起立为他不可磨灭的英勇之举鼓掌。
- His efforts to improve the situation are to be applauded .
	- 他为改善状况所作的努力应该受到赞许。
# 形态
- #word_third applauds
- #word_ing applauding
- #word_done applauded
- #word_past applauded
