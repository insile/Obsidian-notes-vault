# 词义
- 英：/əˈraʊzl/； 美：/əˈraʊzl/
- #n (性欲的)激起，激发；唤起;激起
# 例句
- Individual difference , time pressure and information arousal methods have been widely used in this research field .
	- 此外，个体差异比较、时间压力以及信息激起为研究情绪在个体判断和决策中的作用提供了很好的研究思路。
- Four , subconscious arousal and strategy and research value .
	- 四，潜意识的激发和运筹及其研究价值。
- Use this technique to control your level of arousal .
	- 用这种方法来控制性兴奋程度。
