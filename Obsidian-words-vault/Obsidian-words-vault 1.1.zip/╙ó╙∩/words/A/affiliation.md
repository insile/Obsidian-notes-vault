# 词义
- 英：/əˌfɪliˈeɪʃn/； 美：/əˌfɪliˈeɪʃn/
- #n 附属；隶属；从属；(与政党、宗教等的)隶属关系
# 例句
- Why shouldn 't our communications software allow multiple connections or make connections by organization or affiliation , or just hide the use of phone numbers altogether ?
	- 为什么我们的通信软件不允许多次连接，或者通过组织或附属关系建立连接，或者隐藏电话号码的使用？
- While subscription is a non-normative part of the V3 specification , it fills a key role in enabling registry affiliation .
	- 尽管订阅是V3规范中的非规范化部分，但它在支持注册中心附属关系上起了关键作用。
- He was arrested because of his political affiliation .
	- 他因所属政党的关系而被捕。
# 形态
- #word_pl affiliations
