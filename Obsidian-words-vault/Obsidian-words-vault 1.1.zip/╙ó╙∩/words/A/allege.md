# 词义
- 英：/əˈledʒ/； 美：/əˈledʒ/
- #v (未提出证据)断言，指称，声称；宣称
# 例句
- The newspaper reporters allege that the man was murdered but they have given no proof .
	- 新闻记者们宣称这个男人是被谋杀的，但他们没提出证据。
- ETC Group and others allege that such patents are wrongly awarded .
	- ETC集团和其它组织宣称，授予这样的专利是错误的。
- This procedure should be followed in cases where dishonesty has been alleged .
	- 指控欺诈的案件应遵循本诉讼程序。
# 形态
- #word_third alleges
- #word_ing alleging
- #word_done alleged
- #word_past alleged
