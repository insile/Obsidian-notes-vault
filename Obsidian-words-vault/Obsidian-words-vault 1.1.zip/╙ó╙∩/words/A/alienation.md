# 词义
- 英：/ˌeɪliəˈneɪʃn/； 美：/ˌeɪliəˈneɪʃn/
- #n 异化；疏远；转让；间离效果；（内科）精神错乱
# 例句
- The new policy resulted in the alienation of many voters .
	- 新政策导致许多选民疏远了。
- Many immigrants suffer from a sense of alienation .
	- 许多移民因感到不容于社会而苦恼。
- Resources are not subject to alienation .
	- 资源不得让渡。
