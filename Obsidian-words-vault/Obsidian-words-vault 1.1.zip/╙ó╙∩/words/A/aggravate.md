# 词义
- 英：/ˈæɡrəveɪt/； 美：/ˈæɡrəveɪt/
- #vt 加重；使恶化；使严重；(尤指故意地)激怒，惹恼
# 例句
- He would only aggravate the injury by rubbing it .
	- 他揉擦伤口只会使伤势加重。
- Pollution can aggravate asthma .
	- 污染会使气喘加重。
- Military intervention will only aggravate the conflict even further .
	- 军事介入只会使冲突加剧。
# 形态
- #word_third aggravates
- #word_ing aggravating
- #word_done aggravated
- #word_past aggravated
