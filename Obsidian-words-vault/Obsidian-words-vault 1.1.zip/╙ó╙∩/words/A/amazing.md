# 词义
- 英：/əˈmeɪzɪŋ/； 美：/əˈmeɪzɪŋ/
- #adj (尤指)令人惊喜(或惊羡、惊叹)的；太神了；令人大为惊奇的
- #v 使惊奇；使惊愕；使惊诧
# 例句
- Did you see the tennis match that Agassi played yesterday on TV ? Man ! He 's Amazing .
	- 你昨天有看阿格西的比赛吗？天啊，他真是太神了。
- With the development of computer technology , the research of complex networks has also made amazing results .
	- 随着计算机技术的发展，复杂网络的研究也取得了令人惊喜的成果。
- I find it amazing that they 're still together .
	- 他们还在一起，这使我大吃一惊。
# 形态
- #word_proto amaze
- #word_est most amazing
- #word_er more amazing
