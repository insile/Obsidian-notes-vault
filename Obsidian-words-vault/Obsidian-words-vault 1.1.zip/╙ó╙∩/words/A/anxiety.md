# 词义
- 英：/æŋˈzaɪəti/； 美：/æŋˈzaɪəti/
- #n 焦虑；忧虑；担心；害怕；渴望
# 例句
- Some hospital patients experience high levels of anxiety .
	- 有些住院病人十分焦虑不安。
- Anxiety can be caused by lack of sleep .
	- 睡眠不足可能导致焦虑。
- His anxiety about the work was just a passing phase .
	- 他对工作的担心只是暂时的。
# 形态
- #word_pl anxieties
