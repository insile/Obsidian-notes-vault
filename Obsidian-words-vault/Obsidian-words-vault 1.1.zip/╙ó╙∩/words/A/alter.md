# 词义
- 英：/ˈɔːltə(r)/； 美：/ˈɔːltər/
- #v 改变；(使)更改；修改(衣服使更合身)；改动
# 例句
- It doesn 't alter the way I feel .
	- 这并没有改变我的感受。
- Nothing can alter the fact that we are to blame .
	- 错在我们，这是无法改变的事实。
- People alter their voices in relationship to background noise .
	- 人们根据环境噪音的大小调节自己的声音。
# 形态
- #word_third alters
- #word_ing altering
- #word_done altered
- #word_past altered
