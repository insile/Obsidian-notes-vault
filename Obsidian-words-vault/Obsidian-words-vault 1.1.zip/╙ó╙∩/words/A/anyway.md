# 词义
- 英：/ˈeniweɪ/； 美：/ˈeniweɪ/
- #adv (转换话题、结束谈话或回到原话题时说)无论如何；反正；而且；至少；尽管；加之；即使这样
# 例句
- To be perfectly honest , I didn 't want to go anyway .
	- 说真心话，无论如何我是真的不想去。
- I probably would have voted that way anyway
	- 无论如何我可能都会那样投票。
- The water was cold but I took a shower anyway .
	- 水很冷，不过我还是冲了个淋浴。
