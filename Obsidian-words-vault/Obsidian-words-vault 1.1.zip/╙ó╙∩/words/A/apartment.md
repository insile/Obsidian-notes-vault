# 词义
- 英：/əˈpɑːtmənt/； 美：/əˈpɑːrtmənt/
- #n 公寓；(尤指巨屋、名宅的)房间；(通常指在同一楼层的)公寓套房
# 例句
- His apartment is three blocks away from the police station .
	- 他住在和警察局相隔三个街区的公寓里。
- Prices are based on full occupancy of an apartment .
	- 公寓租金按全部住满为基础计算。
- I 'm going to have to find a new apartment pretty soon .
	- 我很快就得找个新住处了。
# 形态
- #word_pl apartments
