# 词义
- 英：/æmˈbɪɡjuəs/； 美：/æmˈbɪɡjuəs/
- #adj 不明确的；模棱两可的；含混不清的
# 例句
- The Foreign Secretary 's remarks clarify an ambiguous statement issued earlier this week .
	- 外交大臣的话对本周较早时候发表的一份模棱两可的声明作出了澄清。
- He kept making ambiguous remarks instead of straight forward yes-or-no replies .
	- 他连续地讲些模棱两可的话，而不是作出明确的肯定或否定的回答。
- The phrasing of the report is ambiguous .
	- 这份报告的措辞模棱两可。
