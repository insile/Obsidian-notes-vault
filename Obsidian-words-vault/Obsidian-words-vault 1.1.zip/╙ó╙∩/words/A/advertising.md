# 词义
- 英：/ˈædvətaɪzɪŋ/； 美：/ˈædvərtaɪzɪŋ/
- #n 广告；广告业；广告活动
- #v 宣传(自己的事)；(为…)做广告；(在报纸、公共场所公告牌、互联网等上)公布；登广告；征聘
- #adj 广告(业)的
# 例句
- We need a new angle for our next advertising campaign .
	- 我们需要从一个新的角度去展开下一次广告活动。
- We need to take a firm line on tobacco advertising .
	- 我们需要对烟草广告采取强硬的态度。
- We are currently advertising for a new sales manager .
	- 目前我们公开征聘一位新的销售经理。
# 形态
- #word_proto advertise
