# 词义
- 英：/ˌænəˈnɪməti/； 美：/ˌænəˈnɪməti/
- #n 匿名；不知姓名；无个性特征；无特色；名字不公开
# 例句
- Influence of Anonymity on Computer Based English Writing by Empirical Analysis
	- 匿名对以计算机为媒介的大学英语写作教学影响的实证研究
- Based on the information entropy , the measurement of MIX network anonymity
	- 基于信息熵的MIX网络关系匿名度量
- Names of people in the book were changed to preserve anonymity .
	- 为了姓名保密，书中的人用的都是化名。
# 形态
- #word_pl anonymities
