# 词义
- 英：/ˌænɪkˈdəʊtl/； 美：/ˌænɪkˈdoʊtl/
- #adj 趣闻的；传闻的；逸事的
# 例句
- Their views , and the figures behind them , support anecdotal evidence that an increasing number of parents previously intent on their children being educated in the private sector are exploring the option of a free education at grammar schools .
	- 它们的观点及其背后的数字，支持了坊间传闻的迹象：即越来越多先前打算送孩子上私立学校的家长，现在转而青睐免费的公立重点学校。
- Now there is widespread anecdotal evidence that a price war is breaking out from Beijing to Shenzhen .
	- 现在，普遍传闻的消息说价格战已经开始从北京到深圳开始打响了。
- Anecdotal evidence suggests that sales in Europe have slipped .
	- 传闻有证据表明欧洲的销售量已经下滑。
