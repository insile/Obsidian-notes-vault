# 词义
- 英：/ˌædʒɪˈteɪʃn/； 美：/ˌædʒɪˈteɪʃn/
- #n (液体的)搅动，摇动；鼓动；煽动；骚动；焦虑不安；忧虑；烦乱
# 例句
- Small shopkeepers carried on a long agitation against the big department stores .
	- 小店主们长期以来一直在煽动人们反对大型百货商店。
- The agitation and execution of Jesus at any rate did not arouse the slightest interest on the part of his contemporaries .
	- 无论如何，耶稣的煽动工作和被杀情形并没有引起他的同时代人们的丝毫的关心。
- Danny returned to Father 's house in a state of intense agitation
	- 丹尼回到神父的房子时显得极为焦虑不安。
# 形态
- #word_pl agitations
