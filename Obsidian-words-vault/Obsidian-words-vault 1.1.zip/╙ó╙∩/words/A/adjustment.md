# 词义
- 英：/əˈdʒʌstmənt/； 美：/əˈdʒʌstmənt/
- #n 调整；(行为、思想的)调整，适应；调节
# 例句
- Some adjustment of the lens may be necessary .
	- 可能需要调整一下镜头。
- She went through a period of emotional adjustment after her marriage broke up .
	- 婚姻破裂后，她熬过了一段感情调整期。
- I 've made a few adjustments to the design .
	- 我已对设计作了几处调整。
# 形态
- #word_pl adjustments
