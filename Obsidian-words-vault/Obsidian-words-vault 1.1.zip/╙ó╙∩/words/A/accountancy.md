# 词义
- 英：/əˈkaʊntənsi/； 美：/əˈkaʊntənsi/
- #n 会计工作；会计学；会计职业
# 例句
- He 's sitting his final exams in accountancy .
	- 他正参加会计学的期末考试。
- Earning management is the core issue of current study on accountancy .
	- 盈余管理是目前会计学研究的核心问题之一。
- Accountancy just isn 't sexy .
	- 会计工作实在乏味。
