# 词义
- 英：/əˈɡriː/； 美：/əˈɡriː/
- #v 同意；商定；一致；批准，认可（计划、要求等）；(对…)取得一致意见，一致同意；赞成；答应；（与…）相符；应允
# 例句
- The great majority of people seem to agree with this view .
	- 大多数人似乎都同意这种观点。
- When he said that , I had to agree .
	- 他说了那话，我只好同意。
- Not many people agree with the government 's prediction that the economy will improve .
	- 没有多少人赞同政府认为经济将会有所改善的预测。
# 形态
- #word_third agrees
- #word_ing agreeing
- #word_done agreed
- #word_past agreed
