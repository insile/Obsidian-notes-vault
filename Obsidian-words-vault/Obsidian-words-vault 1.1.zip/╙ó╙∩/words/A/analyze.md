# 词义
- 英：/ˈænəlaɪz/； 美：/ˈænəlaɪz/
- #v 分析（研究）；解析；分解
# 例句
- They will take that problem apart and analyze it in great detail
	- 他们会认真分析那个问题，指出其症结所在。
- We should analyze the cause and effect of this event .
	- 我们应该分析这场事变的因果。
- He just published a paper in the journal Nature analyzing the fires .
	- 他刚刚在《自然》杂志上发表了一篇分析火灾的论文。
# 形态
- #word_third analyzes
- #word_done analyzed
- #word_ing analyzing
- #word_past analyzed
