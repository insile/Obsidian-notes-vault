# 词义
- 英：/əˈluːd/； 美：/əˈluːd/
- #v 暗指；间接提到；影射
# 例句
- Understand the image-numberology han dynasty not only help to grasp the inherent laws of the yi-ology development of han dynasty , still can allude to the whole society , the han dynasty culture , and even the entire Chinese nation value system and way of thinking .
	- 理解汉代象数易学不仅有助于把握易学发展的自身规律，还能影射整个汉代社会、汉代文化乃至整个中华民族的价值体系和思维方式。
- The changing of his living conditions alludes to the disintegrating of human civilization .
	- 巴克生存环境的改变暗指人类文明的堕落，人类面临着与巴克一样的困境，旧自我在磨练中即将瓦解。
- The problem had been alluded to briefly in earlier discussions .
	- 这个问题在以往的讨论中已经间接提及。
# 形态
- #word_third alludes
- #word_ing alluding
- #word_done alluded
- #word_past alluded
