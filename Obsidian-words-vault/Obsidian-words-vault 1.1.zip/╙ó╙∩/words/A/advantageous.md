# 词义
- 英：/ˌædvənˈteɪdʒəs/； 美：/ˌædvənˈteɪdʒəs/
- #adj 有利的；有好处的
# 例句
- You 're in a very advantageous position .
	- 你处于非常有利的地位。
- Injections of vitamin C are obviously advantageous .
	- 注射维生素C显然是有利的。
- A free trade agreement would be advantageous to both countries .
	- 自由贸易协定对两国都会有利。
