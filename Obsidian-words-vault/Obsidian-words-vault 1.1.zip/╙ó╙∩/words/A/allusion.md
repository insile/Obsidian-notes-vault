# 词义
- 英：/əˈluːʒn/； 美：/əˈluːʒn/
- #n 典故；影射；暗指；间接提到
# 例句
- The preacher likes to make an allusion to Homer while preaching .
	- 那牧师在传道时喜欢间接提到荷马。
- His statement was seen as an allusion to the recent drug-related killings .
	- 他的声明被视为暗指最近与毒品有关的多起凶杀案。
- Her poetry is full of obscure literary allusion .
	- 她的诗随处可见晦涩的文学典故。
# 形态
- #word_pl allusions
