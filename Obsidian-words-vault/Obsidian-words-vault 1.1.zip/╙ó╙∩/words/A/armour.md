# 词义
- 英：/ˈɑːmə(r)/； 美：/ˈɑːrmər/
- #n (军舰、坦克等的)装甲，防弹钢板；盔甲；装甲车辆；装甲部队；甲冑
# 例句
- Monkeys do not have any kind of protective armour and use their brains to solve problems .
	- 猴子没有任何防身的盔甲，就动脑筋解决问题。
- In the days of yore it was usual for cavalrymen to wear suits of armour .
	- 昔时，骑士通常身穿一整套盔甲。
- The squadron 's armour is draped in sand-coloured nets that melt into the landscape .
	- 装甲连的装甲车上罩着沙色的网，和周围的风景融为一体。
