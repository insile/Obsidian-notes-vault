# 词义
- 英：/əˈnælədʒi/； 美：/əˈnælədʒi/
- #n 类比；比喻；类推；比拟
# 例句
- It is sometimes easier to illustrate an abstract concept by analogy with something concrete .
	- 有时通过与某种具体事物的类比，更容易说明某个抽象的概念。
- A close analogy with the art of singing can be made .
	- 可以用歌唱艺术作类比。
- There are no analogies with any previous legal cases .
	- 以往的法律案件没有哪一宗可与此案类比。
# 形态
- #word_pl analogies
