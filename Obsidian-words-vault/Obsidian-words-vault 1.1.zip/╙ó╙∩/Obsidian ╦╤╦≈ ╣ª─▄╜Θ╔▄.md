##### 文档
- https://help.obsidian.md/Plugins/Search
##### 嵌入搜索结果
> ```query
> embed OR search
> ```
##### 搜索词与正则表达式
- 搜索词默认独立匹配
	- `A B`: 与, AB都包含
	- `A OR B`: 或, AB至少包含一个 
		- `A B OR C D`: 满足`A B`或`C D`
		- `A (B OR C) D`: 满足`A B D`或`A C D`
	- `-B`: 非, 不含B
		- `A -B`: 含A不含B
		- `A -(B C)`: 含A不满足`B C`
- 搜索词加引号则为整体匹配
	- `"A B"` 作为短语包含
- `/[a-z]+/`
```
高兴 快乐
高兴 OR 快乐
-高兴
"a b"
/^a.*/
```
##### 搜索算子
- `file:`  file:ability
	- 匹配文件名, 并且匹配库中的任何文件
- `path:`  path:words/D/
	- 匹配文件路径, 并且匹配库中的任何文件
- `content:`  content:ability
	- 匹配文件内容
- `tag:`  tag:vi
	- 匹配标签
- `line:(...)`
	- 以行为单位搜索关键词
- `block:(...)`
	- 以块为单位搜索关键词
- `section:(...)`  section:(词义 高兴 快乐)
	- 以章节为单位搜索关键词
- `task:(...)`  task:(ability)
	- 搜索任务列表
- `task-todo:(...)`  
	- 待办任务
- `task-done:(...)`
	- 已完成任务
- `match-case:`
	- 大小写敏感
- `ignore-case:`
	- 大小写不敏感
##### 配置搜索设置
- 匹配大小写
	- 切换区分大小写的匹配。
- 解释搜索词将
	- 搜索词分解并用纯文本进行解释。
- 折叠结果
	- 切换是否显示搜索上下文。
- 显示更多上下文
	- 展开搜索结果以显示更多关于匹配的文本。
- 更改排序顺序
	- 更改搜索结果的顺序。
- 复制搜索结果
	- 转换并将搜索结果复制为带有可选链接的 Markdown 列表。
