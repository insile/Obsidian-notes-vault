# 词义
- 英：/ˈæɡrɪɡət , ˈæɡrɪɡeɪt/； 美：/ˈæɡrɪɡət , ˈæɡrɪɡeɪt/
- #adj 总计的；总数的
- #n (可成混凝土或修路等用的)骨料，集料；合计；总数
- #vt 合计；总计
# 例句
- Portfolio management focuses attention at an aggregate level .
	- 投资组合管理关注点在总计的层次上。
- They won 4 – 2 on aggregate .
	- 他们以总分4:2获胜。
- The scores were aggregated with the first round totals to decide the winner .
	- 此次得分与第一轮所得总分合计决出胜者。
# 形态
- #word_third aggregates
- #word_ing aggregating
- #word_done aggregated
- #word_pl aggregates
- #word_past aggregated
