# 词义
- 英：/ˌæplɪˈkeɪʃn/； 美：/ˌæplɪˈkeɪʃn/
- #n 应用；应用程序；申请；(尤指理论、发现等的)运用；申请表；申请书；施用；涂抹；敷用；勤奋
# 例句
- Students learned the practical application of the theory they had learned in the classroom
	- 学生们学会了将课堂上学到的理论付诸实际应用。
- Simon 's book provides a succinct outline of artificial intelligence and its application to robotics .
	- 西蒙的书简明扼要地概括了人工智能及其在机器人技术方面的应用。
- What is the current status of our application for funds ?
	- 我们申请资金目前进展状况如何？
# 形态
- #word_pl applications
