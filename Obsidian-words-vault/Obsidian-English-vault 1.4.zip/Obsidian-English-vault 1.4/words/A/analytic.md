# 词义
- 英：/ˌænəˈlɪtɪk/； 美：/ˌænəˈlɪtɪk/
- #adj 分析的；分析型的(用词序而非词尾显示词在句中的功能)
# 例句
- The boy has an analytic mind .
	- 这男孩有分析的头脑。
- An analytic mind ; an analytic approach .
	- 善于分析的头脑；
- Two proving method for chain rule of analytic function .
	- 解析函数链式法则的两种证明方法。
