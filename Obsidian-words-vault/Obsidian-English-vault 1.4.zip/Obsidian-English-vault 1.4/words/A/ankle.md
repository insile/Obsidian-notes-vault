# 词义
- 英：/ˈæŋkl/； 美：/ˈæŋkl/
- #n 踝关节；踝
- #v 走路
# 例句
- She fell awkwardly and broke her ankle .
	- 她笨重地摔了一跤，摔断了踝关节。
- The knee and ankle joints must be immobilized — this usually means up to six weeks in plaster .
	- 膝关节和踝关节必须加以固定——这通常意味着要打上6个星期的石膏。
- My ankle is still too painful to walk on .
	- 我的脚腕子还是疼得不能走路。
# 形态
- #word_pl ankles
