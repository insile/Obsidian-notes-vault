# 词义
- 英：/ˌɑːɡjuˈmentətɪv/； 美：/ˌɑːrɡjuˈmentətɪv/
- #adj 论辩的；好争论的；爱辩论的
# 例句
- Great chess players have a reputation for being both eccentric and argumentative
	- 国际象棋大师们以性格怪异和好与人争辩而闻名。
- You 're in an argumentative mood today !
	- 你今天就是找人吵架的。
- She 's quite opinionated and very argumentative .
	- 她十分武断，还好争辩。
