# 词义
- 英：/ˌædməˈreɪʃn/； 美：/ˌædməˈreɪʃn/
- #n 钦佩；赞赏；羡慕
# 例句
- She won the admiration of many people in her battle against cancer .
	- 她在与癌症的对抗中赢得了许多人的钦佩。
- I have great admiration for her as a writer .
	- 我十分钦佩她这位作家。
- His eyes showed open admiration as he looked at her .
	- 他看她的时候，眼神里明显流露着敬佩之情。
