# 词义
- 英：/ˈænɪmeɪt , ˈænɪmət/； 美：/ˈænɪmeɪt , ˈænɪmət/
- #vt 使有生气；使生气勃勃；使具活力；把…制作成动画片
- #adj 有生命的；有生气的；有活力的
# 例句
- Her face suddenly became animated .
	- 她一下子眉飞色舞起来。
- Her hand movements are becoming more animated .
	- 她双手舞动得越发欢快了。
- Disney has returned to what it does best : making full-length animated feature films .
	- 迪斯尼又回到了它最擅长的领域：制作动画长片。
# 形态
- #word_third animates
- #word_ing animating
- #word_done animated
- #word_past animated
