# 词义
- 英：/ˈænɪml/； 美：/ˈænɪml/
- #n 动物(不包括鸟、鱼、爬行动物、昆虫或人)；牲畜；兽；衣冠禽兽；某类型的人
- #adj 肉体的；情欲的；肉欲的
# 例句
- There are many different sorts of animal on the island .
	- 岛上有许多不同种类的动物。
- His research work was attacked by animal rights activists .
	- 他的研究受到了动物权益维护者的抨击。
- Many people do not like the idea of experiments on animals .
	- 许多人不赞成在动物身上做试验。
# 形态
- #word_pl animals
