# 词义
- 英：/əˌpriːʃiˈeɪʃn/； 美：/əˌpriːʃiˈeɪʃn/
- #n 理解；感谢；欣赏；感激；增值；鉴定，评价，评估；体谅；同情
# 例句
- The aim is to inculcate business people with an appreciation of different cultures
	- 其目的是教导商界管理人员逐渐学会欣赏不同的文化。
- One 's appreciation of literature depends on one 's level of aesthetic knowledge .
	- 一个人对文学作品的欣赏能力，取决于他的艺术修养。
- She shows little appreciation of good music .
	- 她感受不到美好音乐的妙处。
# 形态
- #word_pl appreciations
