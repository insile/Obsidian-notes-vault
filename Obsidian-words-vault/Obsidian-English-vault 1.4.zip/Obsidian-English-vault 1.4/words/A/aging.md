# 词义
- 英：/ˈeɪdʒɪŋ/； 美：/ˈeɪdʒɪŋ/
- #n 老化；变老；变旧
- #adj 老化的；变老的；变旧的
- #v (使)成熟，变陈；使变老；变老；使苍老；使显老
# 例句
- As you 've said , there 's talk of my not aging .
	- 像你刚才说的，她们说我不会变老。
- However I am aging , ambition is still in .
	- 虽然一天天变老，但雄心还在！
- They were both only 20 years of age .
	- 他们两人都只有20岁。
# 形态
- #word_proto age
