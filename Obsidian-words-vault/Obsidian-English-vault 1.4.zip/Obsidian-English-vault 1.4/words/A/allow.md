# 词义
- 英：/əˈlaʊ/； 美：/əˈlaʊ/
- #v 允许；使可能；（为某目的）留出，给出；接受；给予；准许；允许进入(或出去、通过)
# 例句
- The doctor may allow her to return to work next week .
	- 医生也许会允许她下周回去上班。
- His parents won 't allow him to stay out late .
	- 他的父母不会允许他在外待得很晚。
- The course allows students to progress at their own speed .
	- 本课程允许学生按各自的速度学习。
# 形态
- #word_third allows
- #word_ing allowing
- #word_done allowed
- #word_past allowed
