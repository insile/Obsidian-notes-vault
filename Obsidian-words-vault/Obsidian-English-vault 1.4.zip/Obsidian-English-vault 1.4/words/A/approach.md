# 词义
- 英：/əˈprəʊtʃ/； 美：/əˈproʊtʃ/
- #n 方法；(待人接物或思考问题的)方式；(距离和时间上的)接近；要求；建议；进场；接洽；通路；相似（或近似）的事物
- #v (在数额、水平或质量上)接近；要求；建议；(在距离或时间上)靠近；接洽；着手处理
# 例句
- We need to take a different approach to the problem .
	- 我们应该采用另一种方法来解决这一问题。
- I think it 's time we tried a fresh approach .
	- 我认为是尝试新方法的时候了。
- We need to take a more global approach to the problem .
	- 我们需要更全面地看这个问题。
# 形态
- #word_third approaches
- #word_ing approaching
- #word_done approached
- #word_pl approaches
- #word_past approached
