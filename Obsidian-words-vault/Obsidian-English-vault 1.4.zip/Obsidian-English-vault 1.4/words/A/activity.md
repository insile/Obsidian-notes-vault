# 词义
- 英：/ækˈtɪvəti/； 美：/ækˈtɪvəti/
- #n (为兴趣、娱乐或达到一定目的而进行的)活动；活跃；热闹状况
# 例句
- Is the property or any part thereof used for commercial activity ?
	- 这一房产或其中任何部分有用于商业活动吗？
- Cooperative activity is essential to effective community work .
	- 要把社区工作做好，协作活动是必不可少的。
- There is a full range of activities for children .
	- 这里有给孩子们提供的各种活动。
# 形态
- #word_pl activities
