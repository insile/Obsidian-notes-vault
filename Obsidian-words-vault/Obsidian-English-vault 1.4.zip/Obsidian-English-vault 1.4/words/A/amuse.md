# 词义
- 英：/əˈmjuːz/； 美：/əˈmjuːz/
- #vt (使)娱乐；(提供)消遣；逗乐；逗笑
# 例句
- A clown 's job is to amuse the spectators .
	- 小丑的工作就是娱乐观众。
- They performed a skit to amuse the crowd .
	- 他们表演了一个幽默小品来娱乐观众。
- Playing with water can keep children amused for hours .
	- 嬉水可以使孩子们玩乐好几个小时。
# 形态
- #word_third amuses
- #word_ing amusing
- #word_done amused
- #word_past amused
