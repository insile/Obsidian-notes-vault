# 词义
- 英：/æmˈbɪʃəs/； 美：/æmˈbɪʃəs/
- #adj 雄心勃勃的；有野心的；有雄心的；耗资的；耗时的；费力的
# 例句
- He has cast her as an ambitious lawyer in his latest movie .
	- 他选定她在他最近的一部影片里扮演一名雄心勃勃的律师。
- He was by his own account an ambitious workaholic .
	- 据他自己所言，他是个雄心勃勃的工作狂。
- They were very ambitious for their children .
	- 他们望子成龙心切。
# 形态
- #word_est most ambitious
- #word_er more ambitious
