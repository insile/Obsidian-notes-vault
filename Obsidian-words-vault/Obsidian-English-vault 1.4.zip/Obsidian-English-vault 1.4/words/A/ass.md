# 词义
- 英：/æs/； 美：/æs/
- #n 驴；笨蛋；蠢人
# 例句
- Come on , Jin . I need your help to stop this ass !
	- 快点儿，金，我需要你帮我劝阻这个笨蛋。
- She whispered in his ear " You silly ass ," and then , tottering to her chamber , lay down on the bed .
	- 她在他耳边悄悄地说：你这个笨蛋。然后她摇摇晃晃地回到她的寝室，躺倒在床上。
- I made an ass of myself at the meeting ─ standing up and then forgetting the question .
	- 我在会议上出了个大洋相——站起来却忘了要问的问题。
# 形态
- #word_pl asses
