# 词义
- 英：/ˈæntənɪm/； 美：/ˈæntənɪm/
- #n 反义词
# 例句
- Learning an antonym for each new word can help you increase your vocabulary .
	- 学习新词的反义词也可以扩展你的词汇量。
- The research on the antonym has been the focus of the study of Chinese ontology research .
	- 反义词的研究一直是汉语本体研究的重点和难点。
- And have listed these antonyms through simple illustration to out .
	- 并把这些反义词通过简单例证列了出来。
# 形态
- #word_pl antonyms
