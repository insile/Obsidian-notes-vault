# 词义
- 英：/əˈpruːv/； 美：/əˈpruːv/
- #v 批准；核准；通过(计划、要求等)；认可；同意；赞成
# 例句
- The council is considering whether to approve of the use of firearms
	- 政务委员会正在考虑是否要批准动用武器。
- They urged parliament to approve plans for their reform programme
	- 他们敦促议会批准他们的改革方案。
- The course is approved by the Department for Education .
	- 课程已获教育部核准。
# 形态
- #word_third approves
- #word_ing approving
- #word_done approved
- #word_past approved
