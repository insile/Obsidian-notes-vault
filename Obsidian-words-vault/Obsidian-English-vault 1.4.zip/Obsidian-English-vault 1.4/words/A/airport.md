# 词义
- 英：/ˈeəpɔːt/； 美：/ˈerpɔːrt/
- #n 机场；航空港；航空站
# 例句
- A glass-enclosed tower for the visual observation of aircraft around an airport .
	- 航空站用于指挥和观察周围飞机活动的一个用玻璃围成的塔。
- The fee covers up to six passengers , who are given priority treatment , even if airport staff are stretched by long queues inside the terminal .
	- 费用可同时包含六名乘客，即使其它乘客在航空站排着长队，工作人员也会赶来优先接待他们。
- Many local people object to the building of the new airport .
	- 许多当地的居民反对兴建新机场。
# 形态
- #word_pl airports
