# 词义
- 英：/əˈnʌðə(r)/； 美：/əˈnʌðər/
- #det #pron （同类中的）又一个，再一个；不同的一个，另一个；类似的另一个
- #adj （同类中）又一的，再一个（或一批）的；另一的，别的，不同的；另一类似的
# 例句
- Time is another important consideration .
	- 时间是另一个需要考虑的重要因素。
- His wife found out he 'd been carrying on with another woman .
	- 他的妻子发现他和另一个女人勾勾搭搭。
- I generally get what I want one way or another .
	- 我一般总能想方设法得到我想要的东西。
