# 词义
- 英：/ˈɑːkɪtekt/； 美：/ˈɑːrkɪtekt/
- #n 建筑师；设计师；缔造者；创造者
# 例句
- The architect had produced a scale model of the proposed shopping complex .
	- 建筑师为提议建设的购物中心做了一个比例模型。
- The architect is drawing up plans for the new offices .
	- 建筑师正在绘制新办公楼的设计图。
- Jones was the architect of the team 's first goal .
	- 琼斯是球队入第一球的发动者。
# 形态
- #word_pl architects
