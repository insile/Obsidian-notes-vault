# 词义
- 英：/əˈfɪks , ˈæfɪks/； 美：/əˈfɪks , ˈæfɪks/
- #vt 贴上；附上；粘上
- #n 词缀(unhappy中的un-和careless中的-less都是词缀)
# 例句
- Affix a warning note in the vehicle .
	- 请在汽车上附上一条警告注释。
- Once these organizations certify compliance by an applicable product or service , they permit the purveyor to affix a certification mark .
	- 一旦这些机构认证了一种适用产品或服务，它们就允许承办商在商品或服务上附上认证标志。
- The label should be firmly affixed to the package .
	- 这张标签应该牢牢地贴在包裹上。
# 形态
- #word_third affixes
- #word_ing affixing
- #word_done affixed
- #word_past affixed
