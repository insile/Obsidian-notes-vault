# 词义
- 英：/ænˈtæɡənɪst/； 美：/ænˈtæɡənɪst/
- #n 对手；敌人；敌手；对抗者；对立者
# 例句
- So chanted the child to his antagonist .
	- 一位小孩向他的敌手诵念这句话。
- He wondered what his antagonist was doing .
	- 他不知道他的敌手在做些什么。
- Spassky had never previously lost to his antagonist .
	- 斯帕斯基以往从未输给过他的对手。
# 形态
- #word_pl antagonists
