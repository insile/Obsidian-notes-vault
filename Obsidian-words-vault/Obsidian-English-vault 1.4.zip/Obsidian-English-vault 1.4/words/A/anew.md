# 词义
- 英：/əˈnjuː/； 美：/əˈnuː/
- #adv 重新；再
# 例句
- Slowly Jewish communities were reconstituted and Jewish life began anew .
	- 渐渐地，犹太社区得到重建，犹太人的生活重新开始。
- He began his work anew .
	- 他重新开始工作。
- They started life anew in Canada .
	- 他们在加拿大开始新生活。
