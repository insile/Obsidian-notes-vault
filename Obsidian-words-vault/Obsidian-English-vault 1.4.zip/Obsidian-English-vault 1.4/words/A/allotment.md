# 词义
- 英：/əˈlɒtmənt/； 美：/əˈlɑːtmənt/
- #n 分配；配给；份额；分配量；(城镇居民可以租来种菜的)小块土地；分配物
# 例句
- How big is your allotment of the budget ?
	- 你的份额有多大？
- On Monday , so-called allotment data from the Treasury revealed domestic fund managers had bought a larger share of bond auctions held in mid-October .
	- 本周一，来自美国财政部的所谓份额数据显示，美国国内基金经理在10月中旬举行的国债拍卖中所认购的份额有所上升。
- Water allotments to farmers were cut back in the drought .
	- 在干旱时期配给农民的水量减少。
# 形态
- #word_pl allotments
