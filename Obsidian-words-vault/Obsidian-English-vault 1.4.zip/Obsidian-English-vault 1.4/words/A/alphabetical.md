# 词义
- 英：/ˌælfəˈbetɪkl/； 美：/ˌælfəˈbetɪkl/
- #adj 按字母(表)顺序的；按字母顺序排列的
# 例句
- The names on the list are in alphabetical order .
	- 名单上的名字是按字母顺序排列的。
- Of course , an alphabetical list of commands may not be all that helpful .
	- 当然，按字母顺序排列的命令列表对您也许没什么帮助。
- The computer sorts the words into alphabetical order .
	- 计算机按字母顺序排列这些单词。
