# 词义
- 英：/əˈledʒd/； 美：/əˈledʒd/
- #adj 涉嫌的；宣称的；据传闻的
- #v (未提出证据)断言，指称，声称
# 例句
- They have begun a hunger strike in protest at the alleged beating .
	- 他们开始绝食以抗议有人所宣称的殴打行为。
- He denounced the alleged killings and said he would launch his own investigation .
	- 他谴责了外界宣称的种种杀人行为，并指出他将发动他自己的追踪调查。
- This procedure should be followed in cases where dishonesty has been alleged .
	- 指控欺诈的案件应遵循本诉讼程序。
# 形态
- #word_proto allege
