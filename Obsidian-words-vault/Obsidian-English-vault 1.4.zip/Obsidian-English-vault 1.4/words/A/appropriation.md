# 词义
- 英：/əˌprəʊpriˈeɪʃn/； 美：/əˌproʊpriˈeɪʃn/
- #n 拨(专)款；挪用；占用；盗用；专款；侵吞；(尤指政府、公司的)所拨款项；擅自调用
# 例句
- Study on the Reform of Funds Appropriation System of Higher Education in China
	- 我国高等教育拨款制度改革探讨
- Government Appropriation : the Important Source of Vocational Education Fund
	- 政府拨款：职业教育经费的重要来源
- The government raised defence appropriations by 12 per cent .
	- 政府将国防拨款提高了12%。
# 形态
- #word_pl appropriations
