# 词义
- 英：/əˈliːdʒəns/； 美：/əˈliːdʒəns/
- #n 效忠；(对党、宗教、统治者的)忠诚；拥戴
# 例句
- My allegiance to Kendall and his company ran deep .
	- 我对肯德尔及其公司的忠诚加深了。
- Although naturalism had not become an obsession among American writers by1914 , it clearly commanded the allegiance of a majority of serious young writers .
	- 到1914年，虽然自然主义在美国作家中没有成为一种固定的观念，但它明显得到多数严肃青年作者的忠诚。
- People of various party allegiances joined the campaign .
	- 各个不同政党的拥护者都参加了这次活动。
# 形态
- #word_pl allegiances
