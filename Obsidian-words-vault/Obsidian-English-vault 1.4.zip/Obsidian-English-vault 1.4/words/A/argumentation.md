# 词义
- 英：/ˌɑːɡjumənˈteɪʃn/； 美：/ˌɑːrɡjumənˈteɪʃn/
- #n 论据；论证；推论
# 例句
- Water resources argumentation is basic work for the water permit system .
	- 建设项目水资源论证是取水许可制度服务的，是一项科学性很强的工作。
- Logic is also commonly used today in argumentation theory .
	- 逻辑也普遍用于论证理论。
- After Wang Anshi carried out the political reform , the confucian-classics argumentation writing style became the major style in the imperial examination of the song dynasty .
	- 经义是王安石变法以后宋代科举考试的主要文体，对后来时文文体的影响很大。
