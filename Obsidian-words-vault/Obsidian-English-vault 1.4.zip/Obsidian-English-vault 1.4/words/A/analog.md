# 词义
- #n 模拟（与数字相对应）；类似物
- #adj 模拟的
# 例句
- New debuting analog thermostat welding machine , easy to operate .
	- 新登场模拟式调温电焊台，操作简单。
- An amplifying type ( or analog ) device , as opposed to digital device .
	- 放大器类（或模拟）器件，相对于数字器件而言的。
- Analog Signal Processing and Digital Communication Technology of Infrared Imaging System
	- 红外成像系统模拟信号处理及数字通信技术
