# 词义
- 英：/ˈɑːɡjuəbl/； 美：/ˈɑːrɡjuəbl/
- #adj 可论证的；有论据的；可疑的；无把握的
# 例句
- It 's arguable that the government has no right to interfere in this matter .
	- 说政府无权干预这一事件是有论据的。
- It is arguable whether the case should have ever gone to trial .
	- 这个案件原本是否应该审判还是个问题。
- It is arguable that giving too much detail may actually be confusing .
	- 过分详细反而使人糊涂的说法是有道理的。
