# 词义
- 英：/əˈpiːlɪŋ/； 美：/əˈpiːlɪŋ/
- #adj 有吸引力的；吸引人的；恳求的；有感染力的；可怜的；令人感兴趣的；希望同情的
- #v 上诉；呼吁；申诉；吁请；有吸引力；恳求；有感染力；引起兴趣
# 例句
- That 's a very appealing idea .
	- 那是个十分吸引人的想法。
- The underlying idea is an appealing one .
	- 基础的概念是一种吸引人的概念。
- There is no right of appeal against the decision .
	- 关于这项判决，没有上诉权。
# 形态
- #word_proto appeal
