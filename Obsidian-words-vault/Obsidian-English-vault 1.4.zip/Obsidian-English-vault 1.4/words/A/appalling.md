# 词义
- 英：/əˈpɔːlɪŋ/； 美：/əˈpɔːlɪŋ/
- #adj 骇人听闻的；令人震惊的；糟糕的；极为恶劣的；使人惊骇的；很不像话的
- #v 使大为震惊；使惊骇
# 例句
- Nothing can extenuate such appalling behaviour .
	- 这种骇人听闻的行径罪无可恕。
- but for the appalling silence of the good people "
	- “也因好人们骇人听闻的沉默”
- Nothing will change as long as the workers continue to accept these appalling conditions .
	- 只要工人继续容忍这种恶劣的劳动条件，情况就不会有任何改变。
# 形态
- #word_proto appall
