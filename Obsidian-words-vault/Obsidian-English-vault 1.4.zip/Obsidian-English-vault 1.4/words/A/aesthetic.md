# 词义
- 英：/iːsˈθetɪk/； 美：/esˈθetɪk/
- #n 美学；美感；审美观
- #adj 审美的；美学的；艺术的；美的；有审美观点的
# 例句
- The professor advanced a new aesthetic theory .
	- 那位教授提出了新的美学理论。
- It 's also one of the aesthetic principles in novel writing .
	- 反讽是一种人生态度和叙述方式，也是小说的美学原则之一。
- The benefits of conservation are both financial and aesthetic .
	- 保护自然环境在经济上和美化环境上都有好处。
# 形态
- #word_pl aesthetics
