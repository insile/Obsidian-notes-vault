# 词义
- 英：/æz , əz/； 美：/æz , əz/
- #prep 像；如同；作为；当作
- #adv (比较时用)像…一样，如同；(指事情以同样的方式发生)和…一样
- #conj 当…时；随着；照…方式；因为；由于；正如；尽管
- #n “A”的复数；阿斯
# 例句
- After he left I just tried to carry on as normal .
	- 他离开后，我只管尽力像往常一样继续干。
- Food prices are no longer inflating at the same rate as last year .
	- 食物价格的上涨率已不再像去年那样高了。
- I 'd like one the same as yours .
	- 我要一个和你一样的。
