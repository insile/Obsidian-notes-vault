# 词义
- 英：/əˈmæs/； 美：/əˈmæs/
- #vt (尤指大量)积累，积聚；聚积
# 例句
- The aim of science is surely to amass and systematize knowledge
	- 科学的目的当然是为了积累科学并使之系统化
- Scientists are continuing to amass data concerning the effects of many other types of toxic pollutants .
	- 科学家正在继续积累有关其他类型有害污染物影响和危害的数据资料。
- He amassed a fortune from silver mining .
	- 他靠开采银矿积累了一笔财富。
# 形态
- #word_third amasses
- #word_ing amassing
- #word_done amassed
- #word_past amassed
