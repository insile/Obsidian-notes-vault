# 词义
- 英：/ˈeəriə/； 美：/ˈeriə/
- #n (地方、城市、国家、世界的)地区；领域；面积；(物体上的)区；部位；(房间、建筑物、处所划为某用途的)场地；地域
# 例句
- This is the main factor driving investment in the area .
	- 这是推动在这个地区投资的主要因素。
- We can 't get Channel 5 in our area .
	- 我们地区收不到5频道的节目。
- The company needs to improve performance in all these areas .
	- 公司需要在所有这些方面改善业绩。
# 形态
- #word_pl areas
