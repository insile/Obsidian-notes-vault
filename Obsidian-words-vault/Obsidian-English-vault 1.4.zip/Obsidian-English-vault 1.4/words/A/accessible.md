# 词义
- 英：/əkˈsesəbl/； 美：/əkˈsesəbl/
- #adj 可使用的；可进入的；可接近的；可到达的；易接近的；易懂的；容易理解的；可见到的；易打交道的；易相处的
# 例句
- In the NOW moment , any point in time is accessible that one may wish to explore or clear karma for .
	- 在当下，任一点你可能会希望探究或清理业力的时间都是可到达的。
- Most parts of China are now accessible by rail .
	- 中国的绝大多数的部份是现在可接近的火车。
- These documents are not accessible to the public .
	- 公众无法看到这些文件。
