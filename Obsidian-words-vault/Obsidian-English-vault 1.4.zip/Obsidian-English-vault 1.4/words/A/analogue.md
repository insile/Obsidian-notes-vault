# 词义
- 英：/ˈænəlɒɡ/； 美：/ˈænəlɔːɡ/
- #adj 模拟的；指针式的
- #n 相似物；类似事情
# 例句
- Several results of q - analogue of basic hypergeometric series
	- 基本超几何级数q-模拟的几个结果
- This article introduces an algorithm for the realization of the logical analogue in the industrial control equipment .
	- 介绍一种在工业控制设备中实现逻辑模拟的算法。
- No conversion from analogue to digital data is needed .
	- 没有必要把模拟转换为数字数据。
# 形态
- #word_pl analogues
