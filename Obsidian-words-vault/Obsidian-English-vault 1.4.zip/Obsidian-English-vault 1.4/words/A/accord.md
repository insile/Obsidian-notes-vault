# 词义
- 英：/əˈkɔːd/； 美：/əˈkɔːrd/
- #v (与…)符合；一致；给予；授予(权力、地位、某种待遇)；赠予
- #n 协议；条约
# 例句
- These results accord closely with our predictions .
	- 这些结果和我们的预测相当一致。
- These results seem to be in accord with earlier research .
	- 这些结果似乎与先前的研究一致。
- Number the car 's features from 1 to 10 according to importance .
	- 将车的特征从1到10编号按重要性一一列出。
# 形态
- #word_third accords
- #word_ing according
- #word_done accorded
- #word_past accorded
