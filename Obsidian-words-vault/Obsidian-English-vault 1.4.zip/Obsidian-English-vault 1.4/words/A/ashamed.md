# 词义
- 英：/əˈʃeɪmd/； 美：/əˈʃeɪmd/
- #adj 羞愧；惭愧的；惭愧；羞于；尴尬；因惭愧而不情愿
# 例句
- I would be ashamed to be seen here .
	- 被人看到在这里我会感到惭愧的。
- If she only knew , she would be ashamed .
	- 如果她知道，会很惭愧的。
- You should be ashamed of treating your daughter like that .
	- 你这样对待自己的女儿应该感到羞愧。
