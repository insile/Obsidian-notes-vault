# 词义
- 英：/əˈlɒt/； 美：/əˈlɑːt/
- #vt 分配(时间、钱财等)；分派(任务等)；配给
# 例句
- Study on the Hospital Bonus Allot System and Its Related Factors
	- 医院奖金分配方式及其影响因素的研究
- The company with higher stock concentration is more prefer to allot .
	- 股权集中度越高，上市公司越愿意分配；
- I completed the test within the time allotted .
	- 我在限定的时间内完成了试验。
# 形态
- #word_third allots
- #word_ing allotting
- #word_done allotted
- #word_past allotted
