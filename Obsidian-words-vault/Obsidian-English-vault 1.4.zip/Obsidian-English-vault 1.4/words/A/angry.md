# 词义
- 英：/ˈæŋɡri/； 美：/ˈæŋɡri/
- #adj 生气的；愤怒的；发怒的；红肿的；发炎的；感染的；波涛汹涌的；狂风暴雨的；天昏地暗的
# 例句
- An angry gorilla has a fierce roar .
	- 发怒的猩猩发出凶猛的吼叫。
- They try to deal politely with angry customers .
	- 他们尽量对发怒的顾客彬彬有礼。
- It doesn 't take much to make her angry .
	- 她动辄就发脾气。
# 形态
- #word_est angriest
- #word_er angrier
