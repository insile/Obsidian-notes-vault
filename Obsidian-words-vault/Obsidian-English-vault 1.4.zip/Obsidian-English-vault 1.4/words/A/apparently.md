# 词义
- 英：/əˈpærəntli/； 美：/əˈpærəntli/
- #adv 显然；看来；显然地；据…所知
# 例句
- Apparently , he 's one of these extreme sports nuts .
	- 显然地，他是极限运动的铁杆爱好者。
- Apparently he started already in high school , selling computers out of a friend 's garage .
	- 显然地，他的创业史开始于高中，那时他从朋友的杂货店里出售电脑。
- I thought she had retired , but apparently she hasn 't.
	- 我原以为她退休了，但显然她还没有退。
