# 词义
- 英：/ˈeə kəndɪʃənə(r)/； 美：/ˈer kəndɪʃənər/
- #n 空调；空气调节器；冷（暖）气机
# 例句
- The air-conditioner thrummed .
	- 空调嗡嗡作响。
- Since that first repair job , a broken air-conditioner , a non-functioning washer and a non-toasting toaster have been fixed .
	- 自第一次修理工作以来,他还修好了坏掉的空调、洗衣机和烤面包机。
- Design and Construction of Automatic Control System of Building Air-Conditioner
	- 大楼空调设备自控系统的设计与施工
