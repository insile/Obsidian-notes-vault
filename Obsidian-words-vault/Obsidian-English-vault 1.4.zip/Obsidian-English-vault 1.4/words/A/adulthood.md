# 词义
- 英：/ˈædʌlthʊd/； 美：/əˈdʌlthʊd/
- #n 成年；成年期
# 例句
- Inhibition in adulthood seems to be very clearly a reflection of a person 's experiences as a child .
	- 一个人成年期的情感压抑似乎很明显是其童年时期经历的反映。
- But experts say the behaviors often last into adulthood . VOICE TWO :
	- 但是专家称，这些行为通常持续到成年期。
- Is there a cut-off point between childhood and adulthood ?
	- 童年与成年之间有分界线吗？
