# 词义
- 英：/əˈnaʊns/； 美：/əˈnaʊns/
- #v 宣布；(尤指通过广播)通知；宣告(决定、计划等)；播音，广播；宣称；声称；宣布（某人）到达
# 例句
- He used the occasion to announce further tax cuts .
	- 他利用这个机会宣布再次减税。
- They will announce the result of the vote tonight .
	- 今晚他们将宣布投票结果。
- It was announced that new speed restrictions would be introduced .
	- 据宣布，将有新的限速规定出台。
# 形态
- #word_third announces
- #word_ing announcing
- #word_done announced
- #word_past announced
