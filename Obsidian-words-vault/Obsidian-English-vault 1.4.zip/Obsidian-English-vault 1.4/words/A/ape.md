# 词义
- 英：/eɪp/； 美：/eɪp/
- #n 类人猿；猿类
- #vt (尤指笨拙地)模仿，学…的样子；(为了取笑)学…的样，模仿
# 例句
- I began to imagine a mystery ape as a possible solution to the problem .
	- 我开始构思一种神秘猿类，作为年代问题的可能解决办法。
- The question remains : is there only one mystery ape or possibly more ?
	- 留存的问题：可能是一种还是多种神秘猿类存在？
- When Colonel Harper found out , he would go ape .
	- 哈珀上校发现了一定会勃然大怒。
# 形态
- #word_third apes
- #word_ing aping
- #word_done aped
- #word_pl apes
- #word_past aped
