# 词义
- 英：/æmˈbɪʃn/； 美：/æmˈbɪʃn/
- #n 野心；雄心；抱负；志向；追求的目标；夙愿
- #v 热望
# 例句
- It had been her lifelong ambition .
	- 这是她终身追求的目标。
- I had the ambition , but not the resources .
	- 我有自己追求的目标，但缺乏资源。
- She never achieved her ambition of becoming a famous writer .
	- 她一直未能实现当名作家的夙愿。
# 形态
- #word_pl ambitions
