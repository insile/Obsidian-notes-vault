# 词义
- 英：/əˈpɪə(r)/； 美：/əˈpɪr/
- #v 出现，呈现，显现；显得，看来，似乎；出庭（作证或受审）；出版；演出；记载；起源，首次使用
# 例句
- She longed to break in on their conversation but didn 't want to appear rude .
	- 她很想打断他们的谈话，但又不愿显得粗鲁。
- He didn 't wish to appear discourteous .
	- 他不想显得没礼貌。
- It would appear that this was a major problem .
	- 看来这是个主要问题。
# 形态
- #word_third appears
- #word_ing appearing
- #word_done appeared
- #word_past appeared
