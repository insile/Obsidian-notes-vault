# 词义
- 英：/əˈlaɪəns/； 美：/əˈlaɪəns/
- #n 联盟；(国家、政党等的)结盟，同盟；结盟团体
# 例句
- China will not enter into alliance with any big power .
	- 中国不同任何大国结盟。
- Japan was in alliance with Germany and Italy during the Second World War .
	- 第二次世界大战时，日本和德国、意大利结盟。
- Strategic alliances are being forged with major European companies .
	- 正与欧洲主要公司设法结成战略同盟。
# 形态
- #word_pl alliances
