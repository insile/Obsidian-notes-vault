# 词义
- 英：/əˈdɪkʃn/； 美：/əˈdɪkʃn/
- #n 上瘾；瘾；嗜好；入迷
# 例句
- Some people know how to control themselves , and thus avoid addiction .
	- 有些人知道如何控制自己，以至于自己不会上瘾。
- Reason and Education Strategy of Computer Game Addiction on Contemporary Undergraduate Students
	- 当代大学生玩电脑游戏上瘾的原因及教育对策
- For drug addicts , the need to feed the addiction takes priority over everything else .
	- 对于吸毒者来说满足毒瘾胜过一切。
# 形态
- #word_pl addictions
