# 词义
- 英：/ənd , ænd/； 美：/ənd , ænd/
- #conj 和；与；同；又；而；加；加上；然后；接着；…为了；那么，于是；（表示结果）结果是；接连，又，愈来愈；与…不同，各有不同
- #n 附加条件；附加细节
# 例句
- It is quite possible that space and time are finite .
	- 很有可能空间和时间是有限的。
- It 's a waste of time and energy .
	- 那是浪费时间和精力。
- 5 and 7 make 12 .
	- 5加7等于12。
