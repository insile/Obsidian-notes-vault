# 词义
- 英：/ɑːˈtɪləri/； 美：/ɑːrˈtɪləri/
- #n (统称)火炮；炮兵部队
# 例句
- The two sides joined battle once again using artillery , mortars and heavy machine guns .
	- 双方使用火炮、迫击炮和重机枪再次交战。
- The artillery was deployed to bear on the fort .
	- 火炮是对着那个碉堡部署的。
- The town is under heavy artillery fire .
	- 该市镇处于密集的炮火之下。
