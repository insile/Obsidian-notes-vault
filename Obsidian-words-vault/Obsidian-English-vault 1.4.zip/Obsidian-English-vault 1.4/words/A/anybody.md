# 词义
- 英：/ˈenibɒdi/； 美：/ˈenibɑːdi/
- #pron (用于疑问句、条件从句)任何人；同 anyone
- #n 重要人物；平常人
# 例句
- Anybody can use the pool ─ you don 't need to be a member .
	- 任何人都可使用这个游泳池，不必是会员。
- She can hold her own against anybody in an argument .
	- 她在辩论中不会让任何人占上风。
- She wasn 't anybody before she got that job .
	- 她在获得那个职位之前不过是个无名之辈。
# 形态
- #word_pl anybodies
