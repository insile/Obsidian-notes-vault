# 词义
- 英：/ˈæli/； 美：/ˈæli/
- #n 小巷；胡同；(建筑群中间或后面的)小街
# 例句
- When he saw the police arrive , he bolted down an alley .
	- 他看见警察来了，便从小巷逃走了。
- He wheeled his bike into the alley at the side of the house
	- 他把自行车推进了房子旁的小巷中。
- The Internet has proved a blind alley for many firms .
	- 事实证明，因特网对许多公司而言是一条行不通的路。
# 形态
- #word_pl alleys
