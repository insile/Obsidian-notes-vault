# 词义
- 英：/əˈmʌŋst/； 美：/əˈmʌŋst/
- #prep （表示范围）在…之内；在；同 among；（表示位置）处在…中
# 例句
- Amongst the population at large the support for the present regime is virtually zero .
	- 在一般大众中，支持现政权的人数几乎是零。
- He decided no assassin would chance a shot from amongst that crowd .
	- 他认定，没有刺客会冒险混在人群里开枪。
- Morale amongst the players is very high at the moment .
	- 此刻各选手士气高昂。
