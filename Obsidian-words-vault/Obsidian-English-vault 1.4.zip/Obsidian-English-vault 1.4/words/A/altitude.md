# 词义
- 英：/ˈæltɪtjuːd/； 美：/ˈæltɪtuːd/
- #n 海拔；海拔高度；(海拔高的)高处，高地；高程
# 例句
- Research of Influence of Altitude on DC - Ion - Flow Field
	- 海拔高度对直流离子流场影响的研究
- Effect of Altitude on Radio Interference Based on Corona Test Cage
	- 基于电晕笼的海拔高度对无线电干扰的影响
- The plane made a dive to a lower altitude .
	- 飞机俯冲到较低高度。
# 形态
- #word_pl altitudes
