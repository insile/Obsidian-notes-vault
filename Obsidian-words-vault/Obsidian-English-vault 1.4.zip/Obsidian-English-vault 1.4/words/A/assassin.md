# 词义
- 英：/əˈsæsɪn/； 美：/əˈsæsn/
- #n 刺客；(为金钱或政治目的的)暗杀者，行刺者
# 例句
- He was cut down by an assassin 's bullet .
	- 他被刺客的子弹击中身亡。
- He decided no assassin would chance a shot from amongst that crowd .
	- 他认定，没有刺客会冒险混在人群里开枪。
- The assassin said he had acted alone .
	- 暗杀者声称他是单独作案。
# 形态
- #word_pl assassins
