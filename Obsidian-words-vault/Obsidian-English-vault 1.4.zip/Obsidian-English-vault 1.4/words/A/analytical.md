# 词义
- 英：/ˌænəˈlɪtɪkl/； 美：/ˌænəˈlɪtɪkl/
- #adj 分析的；解析的；善于分析的
# 例句
- He lacked profundity and analytical precision .
	- 他缺乏深度和分析的精确性。
- We must use both the inductive and analytical methods .
	- 我们必须同时运用归纳的和分析的方法。
- I have an analytical approach to every survey .
	- 对每项调查我都采用分析方法。
