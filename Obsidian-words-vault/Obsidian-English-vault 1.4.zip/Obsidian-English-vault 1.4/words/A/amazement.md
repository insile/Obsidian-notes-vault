# 词义
- 英：/əˈmeɪzmənt/； 美：/əˈmeɪzmənt/
- #n 惊奇；惊愕；惊诧
# 例句
- To my amazement , he remembered me .
	- 使我大为惊奇的是他还记得我。
- I was expressing some amazement and wonder at her good fortune
	- 我对她的好运既惊奇又感叹。
- His expression changed from amazement to joy .
	- 他的表情由惊变喜。
