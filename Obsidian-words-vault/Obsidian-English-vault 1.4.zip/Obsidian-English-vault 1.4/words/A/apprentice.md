# 词义
- 英：/əˈprentɪs/； 美：/əˈprentɪs/
- #n 学徒；徒弟
- #vt 使某人当(某人的)学徒
# 例句
- I started off as an apprentice and worked my way up
	- 我从学徒开始干起，逐步上升。
- It 's not quite a year since she became an apprentice .
	- 她学徒还不满一年。
- He left school at 15 and trained as an apprentice carpenter .
	- 他15岁辍学，当上木工学徒。
# 形态
- #word_third apprentices
- #word_ing apprenticing
- #word_done apprenticed
- #word_pl apprentices
- #word_past apprenticed
