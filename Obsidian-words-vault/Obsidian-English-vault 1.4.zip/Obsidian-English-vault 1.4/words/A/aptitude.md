# 词义
- 英：/ˈæptɪtjuːd/； 美：/ˈæptɪtuːd/
- #n 资质；天赋；天资；天生的才能
# 例句
- Researchers used ACT scores as a measure of intellectual aptitude .
	- 研究人员用美国大学入学考试(ACT)成绩来衡量其智力资质。
- Thinking of aptitude establish work to the marine check organization
	- 对实施船检机构资质认可工作的探讨
- She showed a natural aptitude for the work .
	- 她表现出了做这工作的天赋。
# 形态
- #word_pl aptitudes
