# 词义
- 英：/əˈkweɪntəns/； 美：/əˈkweɪntəns/
- #n 熟人；(与某人)认识，略有交情；(对某事物的)了解；相识；认识的人；泛泛之交
# 例句
- I am delighted to make your acquaintance , Mrs Baker .
	- 贝克太太，我很高兴与您相识。
- I first made his acquaintance in the early 1960s
	- 我与他初次相识是在20世纪60年代早期。
- I made the acquaintance of several musicians around that time .
	- 大约在那段时间，我结识了几位音乐家。
# 形态
- #word_pl acquaintances
