# 词义
- 英：/əˈlaɪnmənt/； 美：/əˈlaɪnmənt/
- #n 对齐；(国家、团体间的)结盟；排成直线
# 例句
- Analysis of Three Kinds of Classification Based on Different Absolute Alignment Methods
	- 基于三种不同绝对对齐方法的分类器分析
- Study on the Alignment Method of Multi-view Data in Reverse Engineering
	- 逆向工程中的多视数据对齐方法
- His increasing alignment with the Reagan administration nearly cost him re-election .
	- 与里根政府日益紧密的关系差点让他失去了连任的机会。
# 形态
- #word_pl alignments
