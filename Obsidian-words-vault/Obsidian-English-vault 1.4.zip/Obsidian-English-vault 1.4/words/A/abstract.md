# 词义
- 英：/ˈæbstrækt , æbˈstrækt/； 美：/ˈæbstrækt , æbˈstrækt/
- #n 摘要；(文献等的)概要；抽象派艺术作品
- #adj 抽象的(与个别情况相对)；纯理论的
- #vt 提取；抽取；分离；把…抽象出；写摘要
# 例句
- Please write an abstract of this article 〔 thesis 〕 .
	- 请写一份这本书〔这篇论文〕的摘要。
- He read through the papers and made an abstract of their contents .
	- 他把那些论文都读了一遍并做了内容摘要。
- We may talk of beautiful things but beauty itself is abstract .
	- 我们尽可谈论美的事物，但美本身却是抽象的。
# 形态
- #word_third abstracts
- #word_ing abstracting
- #word_done abstracted
- #word_pl abstracts
- #word_past abstracted
