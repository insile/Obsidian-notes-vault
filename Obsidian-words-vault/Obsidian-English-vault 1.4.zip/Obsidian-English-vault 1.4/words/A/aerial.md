# 词义
- 英：/ˈeəriəl/； 美：/ˈeriəl/
- #n 天线
- #adj 空中的；空气中的；从飞机上的；地表以上的
# 例句
- The aerial doesn 't look very secure to me .
	- 我看这天线不太牢固。
- You 'll need a good aerial to exploit the radio 's performance
	- 你需要弄个好天线来发挥广播的性能。
- Aerial photography has revolutionized the study of archaeology .
	- 航空摄影已经给考古学研究带来了一场革命。
# 形态
- #word_pl aerials
