# 词义
- 英：/əˈfɜːmətɪv/； 美：/əˈfɜːrmətɪv/
- #adj 肯定的；积极的；同意的
- #n 肯定；同意；肯定词；赞成的一方
- #int 是的；对的
# 例句
- She answered in the affirmative .
	- 她作出了肯定的答复。
- He asked me if I was ready . I answered in the affirmative .
	- 他问我是否准备好了，我给出肯定的回答。
- Seventy-nine voted in the affirmative , and none in the negative .
	- 79人投赞成票，没有人投反对票。
# 形态
- #word_pl affirmatives
