# 词义
- 英：/ˌɔːltəˈneɪʃn/； 美：/ˌɔːltərˈneɪʃn/
- #n 交替；交替，变换，间隔
# 例句
- Practice on Working and Study Alternation Mode in Higher Vocational Education
	- 高等职业教育中工学交替模式的实践
- On the Research of the Theory of the Alternation - Modes
	- 调式交替理论之比较研究
- Light and shade come in swift alternation ; Days and months flash by as quickly as a weaver 's shuttle . ; Light travels like an arrow , and time like a shuttle .
	- 光阴似箭，日月如梭。
# 形态
- #word_pl alternations
