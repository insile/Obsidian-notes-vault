# 词义
- 英：/ˌæspəˈreɪʃn/； 美：/ˌæspəˈreɪʃn/
- #n 渴望；抱负；志向；送气；发送气音
# 例句
- He has the aspiration to earn a lot of money .
	- 他渴望赚很多钱。
- Young Addison had a strong aspiration to be an inventor .
	- 年幼的爱迪生渴望成为一名发明家。
- The college 's aim is to help students achieve their aspirations .
	- 大学的目标是帮助学生实现他们的抱负。
# 形态
- #word_pl aspirations
