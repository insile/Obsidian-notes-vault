# 词义
- 英：/ˈɑːbɪtreɪt/； 美：/ˈɑːrbɪtreɪt/
- #v 仲裁；公断
# 例句
- A committee was created to arbitrate between management and the unions .
	- 已成立一个委员会在资方与工会之间进行仲裁。
- The tribunal had been set up to arbitrate in the dispute .
	- 曾设立过特别法庭对此纷争作出仲裁。
- He arbitrates between investors and members of the association
	- 他在投资者和该协会成员之间作出仲裁。
# 形态
- #word_third arbitrates
- #word_ing arbitrating
- #word_done arbitrated
- #word_past arbitrated
