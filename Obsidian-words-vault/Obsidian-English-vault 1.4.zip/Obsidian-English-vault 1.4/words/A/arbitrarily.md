# 词义
- 英：/ˈɑːbɪtrərɪli/； 美：/ˈɑrbɪˌtrɛrəli/
- #adv 任意地；任意(性)地，随意地；(个人)主观武断地，随心所欲地；反复无常地，任性多变地，无定见地，变幻莫测地
# 例句
- Neural Network is an estimator of adaptive resonance function , which is not dependent on models , and could fulfill arbitrarily functional relation without them .
	- 神经网络是一个不依赖于模型的自适应函数估计器，不需要模型就可以实现任意的函数关系。
- Using the position , correlation and code of laws of more than two behaviors of compound behavior crime as the standard , we can divide compound behavior crime into three kinds of situation : the juxtaposed compound behavior crime , necessary compound behavior crime and arbitrarily compound behavior crime .
	- 以复合行为犯罪中两个以上行为的地位、相互关系和法律的规定为标准，可以将复合行为犯罪分为并列的复合行为犯罪、必要的复合行为犯罪和任意的复合行为犯罪三种情形。
- The leaders of the groups were chosen arbitrarily .
	- 这些团体的领导人是任意挑选的。
