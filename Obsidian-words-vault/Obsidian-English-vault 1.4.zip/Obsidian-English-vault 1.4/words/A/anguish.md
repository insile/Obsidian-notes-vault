# 词义
- 英：/ˈæŋɡwɪʃ/； 美：/ˈæŋɡwɪʃ/
- #n 痛苦；苦恼；剧痛
- #vi 苦恼；使苦恼；使极度痛苦；悲痛万分；感到极度的痛苦
# 例句
- He groaned in anguish .
	- 他痛苦地呻吟。
- Every line etched on her face told a story of personal anguish .
	- 她脸上的每条皱纹都讲述了一次痛苦的经历。
- Tears of anguish filled her eyes .
	- 她双眸噙满了伤心的泪水。
# 形态
- #word_third anguishes
- #word_ing anguishing
- #word_done anguished
- #word_past anguished
