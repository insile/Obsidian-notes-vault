# 词义
- #adv 适当地；适宜地
# 例句
- He won his first Derby on the aptly named ' Never Say Die ' .
	- 他驾驭着这匹名副其实的“永不言败”夺得了他的第一个德比马赛冠军。
- The concept underpinned of fire seems much more appealing however , aptly comparing the damage caused by the spread of misleading facts to the trail of destruction left in the wake of a wildfire .
	- “网络谣言”另外一个比较低调的说法是digitalmisinformation。不过，用火来做比喻似乎更加引人注意，而且这个说法巧妙地将传播误导性事实带来的破坏性结果比作野火烧过后留下的残迹。
- It aptly describes the response of many Chinese bankers to the global crisis .
	- 这个词正可以形容许多中国银行家对这场全球性危机的反应。
