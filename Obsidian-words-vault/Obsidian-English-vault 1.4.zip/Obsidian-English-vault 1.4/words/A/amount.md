# 词义
- 英：/əˈmaʊnt/； 美：/əˈmaʊnt/
- #n 金额；数量；数额
- #v 合计，共计；等同，接近
# 例句
- We need double the amount we already have .
	- 我们需要现有数量的两倍。
- Too often children are witness to a disturbing amount of violence .
	- 孩子们经常会目睹暴力事件，其数量之多令人不安。
- A small amount of this paint goes a long way .
	- 这种涂料用一点就可涂一大片。
# 形态
- #word_third amounts
- #word_ing amounting
- #word_done amounted
- #word_pl amounts
- #word_past amounted
