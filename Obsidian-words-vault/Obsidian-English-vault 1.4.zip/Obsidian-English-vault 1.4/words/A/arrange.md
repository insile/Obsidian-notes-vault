# 词义
- 英：/əˈreɪndʒ/； 美：/əˈreɪndʒ/
- #v 安排；布置；排列；整理；筹备；谱写，改编(乐曲)
# 例句
- I must arrange my financial affairs and make a will .
	- 我必须把我的财务安排好，并立下遗嘱。
- Can you telephone me at your convenience to arrange a meeting ?
	- 你能不能在你方便时给我来个电话，安排见一次面？
- The findings are arranged in rank order according to performance .
	- 这些研究结果是根据性能等级排列的。
# 形态
- #word_third arranges
- #word_ing arranging
- #word_done arranged
- #word_past arranged
