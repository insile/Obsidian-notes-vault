# 词义
- 英：/ˈænsestri/； 美：/ˈænsestri/
- #n 祖先；(统称)祖宗；列祖列宗
# 例句
- Sri Lankans share a common ancestry with their Indian brethren .
	- 斯里兰卡人和他们的印度兄弟有共同的祖先。
- Many of the early settlers in America had English ancestry .
	- 许多早期美国移民的祖先都是英国人。
- He was able to trace his ancestry back over 1 000 years .
	- 他可追祖溯宗至1000年以前。
# 形态
- #word_pl ancestries
