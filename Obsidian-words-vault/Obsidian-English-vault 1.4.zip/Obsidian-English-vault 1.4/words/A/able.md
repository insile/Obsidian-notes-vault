# 词义
- 英：/ˈeɪbl/； 美：/ˈeɪbl/
- #adj 能够的；能够；能；(某方面)擅长的；有才能的；有才智的
# 例句
- The project schedule control about the theory of the efficient use of the engineering construction , better able to guide the engineering progress schedule , ensure that the project can be completed on time .
	- 通过将项目进度控制有关的理论高效地运用到工程建设中去，能够较好地指导工程进度的进度，确保工期能够的准时完成。
- You need to be able to work as part of a team .
	- 你必须能作为团队的一员去工作。
- I have some information you may be able to use .
	- 我有些可能对你有用的信息。
# 形态
- #word_est ablest
- #word_er abler
