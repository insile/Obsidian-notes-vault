# 词义
- 英：/əˈnɔɪəns/； 美：/əˈnɔɪəns/
- #n 烦恼；恼怒；生气；使人烦恼的事；令人生气的事物
# 例句
- A look of annoyance crossed her face .
	- 恼怒的神色从她脸上掠过。
- A look of annoyance crossed her face when she knew that her boyfriend couldn 't come back before Christmas Eve .
	- 得知男朋友平安夜前无法赶回来，她的脸上掠过一丝恼怒的神情。
- Much to our annoyance , they decided not to come after all .
	- 他们终于决定不来，使我们很生气。
# 形态
- #word_pl annoyances
