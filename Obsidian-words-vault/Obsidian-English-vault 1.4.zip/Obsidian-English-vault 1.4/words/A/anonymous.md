# 词义
- 英：/əˈnɒnɪməs/； 美：/əˈnɑːnɪməs/
- #adj 匿名的；不具名的；不知姓名的；没有特色的；名字不公开的
# 例句
- On the morning of his birthday , the young man received an anonymous gift .
	- 例如：生日那天早晨，这个年青人收到一份匿名的礼物。
- First , an anonymous data preserving method is provided .
	- 该机制的主要贡献有：首先，给出了一种匿名的数据隐私保护方法。
- The money was donated by a local businessman who wishes to remain anonymous .
	- 这笔款子是当地一位不愿透露姓名的企业家捐赠的。
