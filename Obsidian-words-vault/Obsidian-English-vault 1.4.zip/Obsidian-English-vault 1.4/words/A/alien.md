# 词义
- 英：/ˈeɪliən/； 美：/ˈeɪliən/
- #n 外国人；外星人；外侨；外星生物
- #adj 外星的；外国的；陌生的；格格不入；异域的；不熟悉；不相容；相抵触
- #v 〈诗〉疏远；离间；【法】(所有权的)让渡
# 例句
- Jim is an alien in this film .
	- 吉姆在这部电影里是个外星人。
- A rare form of the condition , which can involve hallucinations or the feeling of being dragged out of bed , may explain ' alien abductions ' that people sincerely believe happened but can 't remember .
	- 非常少见的表现形式可能包括幻觉或感觉被从床上拉下来，这可以解释“外星人绑架”现象，对此人们深信发生过却无法记住。
- In a world that had suddenly become alien and dangerous , he was her only security .
	- 在一个突然变得陌生而危险的世界里，他是她唯一的守护神。
# 形态
- #word_pl aliens
