# 词义
- 英：/ˈɑːmi/； 美：/ˈɑːrmi/
- #n 军队；(一国的)陆军；大批；陆军部队；大群；陆上作战军队
# 例句
- There 's enough here to feed an army .
	- 这儿的东西足以养活一支军队。
- The army met with fierce opposition in every town .
	- 军队在每一座城镇都遭遇到了顽强的抵抗。
- He 's a major in the US army .
	- 他是美国陆军少校。
# 形态
- #word_pl armies
