# 词义
- 英：/əˈpɔːl/； 美：/əˈpɔːl/
- #vt 使惊骇；使大为震惊
# 例句
- It appalled me that they could simply ignore the problem .
	- 他们竟然对问题置之不理，令我非常诧异。
- Nothing will change as long as the workers continue to accept these appalling conditions .
	- 只要工人继续容忍这种恶劣的劳动条件，情况就不会有任何改变。
- The idea of sharing a room appalled her .
	- 合住一个房间的想法使她惊骇。
# 形态
- #word_third appals
- #word_ing appalling
- #word_done appalled
- #word_past appalled
