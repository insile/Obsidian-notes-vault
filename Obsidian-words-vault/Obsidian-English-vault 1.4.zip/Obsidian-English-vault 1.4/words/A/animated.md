# 词义
- 英：/ˈænɪmeɪtɪd/； 美：/ˈænɪmeɪtɪd/
- #adj 活跃的；栩栩如生的；有生气的；生气勃勃的；兴致勃勃的；(似)能活动的
- #v 使具活力；使生气勃勃；把…制作成动画片
# 例句
- The animated pieced of sculpture attracted a lot of people .
	- 栩栩如生的雕塑作品吸引了许多人。
- We talk , I believe , all day long : to talk to each other is but a more animated and an audible thinking .
	- 我相信，我们是整天谈着话。互相交谈只不过是一种比较活跃的、一种可以听见的思考罢了。
- Her face suddenly became animated .
	- 她一下子眉飞色舞起来。
# 形态
- #word_proto animate
