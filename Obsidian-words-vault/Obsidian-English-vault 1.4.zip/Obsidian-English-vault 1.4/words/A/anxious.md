# 词义
- 英：/ˈæŋkʃəs/； 美：/ˈæŋkʃəs/
- #adj 焦虑的；担心；渴望；忧虑；非常希望；流露出忧虑的
# 例句
- The metamorphosis from anxious wife to feted author was rapid and dramatic .
	- 从整日焦虑的妻子到受人追捧的作家，这变化迅速而剧烈。
- Every anxious person will have his or her own special problems or fears .
	- 每一个焦虑的人都会有自己的问题或者担心。
- She was anxious to finish school and get a job .
	- 她渴望毕业找一份工作。
# 形态
- #word_est most anxious
- #word_er more anxious
