# 词义
- 英：/ˈæŋɡə(r)/； 美：/ˈæŋɡər/
- #n 愤怒；怒气；怒火；怒
- #vt 激怒；使发怒
# 例句
- His feelings were part anger , part relief .
	- 他感到既愤怒，又解脱。
- The poet 's anger finds expression in the last verse of the poem .
	- 诗人的愤怒在诗的最后一节表达出来。
- She made a visible effort to control her anger .
	- 看得出她竭力控制自己不发火。
# 形态
- #word_third angers
- #word_ing angering
- #word_done angered
- #word_past angered
