# 词义
- 英：/æpt/； 美：/æpt/
- #adj 易于…，有…倾向；恰当的，适当的；.聪明的，反应敏捷的
# 例句
- ' Urchin ' , with its connotation of mischievousness , may not be a particularly apt word . urchin
	- 有淘气的含义，可能不是一个特别恰当的词。
- Now that 's not really an apt comparison .
	- 这并不是一个恰当的比较。
- Babies are apt to put objects into their mouths .
	- 婴儿爱把东西往嘴里塞。
