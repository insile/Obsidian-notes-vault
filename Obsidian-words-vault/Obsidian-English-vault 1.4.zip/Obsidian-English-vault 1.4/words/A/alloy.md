# 词义
- 英：/ˈælɔɪ , əˈlɔɪ/； 美：/ˈælɔɪ , əˈlɔɪ/
- #n 合金
- #vt 把…铸成合金(尤指掺入一种价值低的金属)
# 例句
- Brass is an alloy of copper and zinc .
	- 黄铜是铜锌合金。
- The company produces titanium alloy .
	- 该公司生产钛合金。
- Bronze is an alloy of copper and tin
	- 青铜是铜和锡的合金。
# 形态
- #word_pl alloys
