# 词义
- 英：/ˈæplɪkənt/； 美：/ˈæplɪkənt/
- #n 申请人(尤指求职、进高等学校等)
# 例句
- Upon a negative decision , the applicant loses the protection offered by Belgian law
	- 一旦得到否定裁决，申请人就失去了比利时法律的保护。
- He is the best applicant for the job .
	- 他是这一职位的申请人中最优秀的一位。
- Applicants will be expected to have good command of English .
	- 申请人必须精通英语。
# 形态
- #word_pl applicants
