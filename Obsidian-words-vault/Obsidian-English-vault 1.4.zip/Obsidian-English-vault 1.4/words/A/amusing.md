# 词义
- 英：/əˈmjuːzɪŋ/； 美：/əˈmjuːzɪŋ/
- #adj 有趣的；好笑的；有乐趣的；逗人笑的
- #v (使)娱乐；(提供)消遣；逗乐；逗笑
# 例句
- It is a highly amusing film .
	- 这是一部特别有趣的电影。
- He likes to surround himself with amusing people .
	- 他喜欢让自己身边拥着有趣的人们。
- She suggested several ideas to help Laura amuse the twins .
	- 她给劳拉出了一些主意，好逗这对双胞胎开心。
# 形态
- #word_proto amuse
