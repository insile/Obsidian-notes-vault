# 词义
- 英：/əˈkwaɪə(r)/； 美：/əˈkwaɪər/
- #vt (通过努力、能力、行为表现)获得；得到；购得
# 例句
- But people must acquire this skill somewhere .
	- 但人们必须在某个地方获得这种技能。
- Less inherently interpersonal subjects , such as math , could acquire a social aspect through team problem solving and peer tutoring .
	- 本身较少涉及人际关系的科目，如数学，可以通过团队解决问题和同伴辅导的方式获得其社交方面。
- She has acquired a good knowledge of English .
	- 她英语已经学得很好。
# 形态
- #word_third acquires
- #word_ing acquiring
- #word_done acquired
- #word_past acquired
