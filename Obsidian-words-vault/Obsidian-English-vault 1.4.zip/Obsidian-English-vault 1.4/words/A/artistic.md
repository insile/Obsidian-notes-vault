# 词义
- 英：/ɑːˈtɪstɪk/； 美：/ɑːrˈtɪstɪk/
- #adj 艺术家的；艺术的；精美的；有艺术性的；有艺术天赋的；(尤指)有美术才能的
# 例句
- Artistic and intellectual people tend towards left-wing views .
	- 搞艺术的人和知识分子容易持“左倾”观点。
- One boy said , " I 'd rather be concentrating on artistic efforts than saving the world or something . "
	- 一个男孩说：“我宁愿专注于艺术的努力，而不是拯救世界之类的。”
- He reacted strongly against the artistic conventions of his time .
	- 他强烈反对当时的艺术俗套。
# 形态
- #word_est most artistic
- #word_er more artistic
