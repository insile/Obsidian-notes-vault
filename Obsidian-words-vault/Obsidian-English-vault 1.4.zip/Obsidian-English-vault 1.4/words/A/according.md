# 词义
- 英：/əˈkɔːdɪŋ/； 美：/əˈkɔːrdɪŋ/
- #v (与…)一致，符合，配合；给予，赠予，授予(权力、地位、某种待遇)
- #adj 相符的“，”一致的“，”相应的
# 例句
- According theory and practice ;
	- 这与理论预期相一致。理论研究要密切联系实际；
- The according theory ;
	- 这与理论预期相一致。二是遵循的理论依据不同；
- Number the car 's features from 1 to 10 according to importance .
	- 将车的特征从1到10编号按重要性一一列出。
# 形态
- #word_proto accord
