# 词义
- 英：/ˌædəˈlesnt/； 美：/ˌædəˈlesnt/
- #n 青少年
- #adj 青少年的；青春期的；未成熟的
# 例句
- He spent his adolescent years playing guitar in the church band .
	- 他在教堂的乐队里弹吉他，度过了他的青少年时期。
- Most adolescent problems are temporary .
	- 多数青少年问题是暂时性的。
- He was showing off , as is the way with adolescent boys .
	- 他在炫耀，青春期的男孩都是这个样子。
# 形态
- #word_pl adolescents
