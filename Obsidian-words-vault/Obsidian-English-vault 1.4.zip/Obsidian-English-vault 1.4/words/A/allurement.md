# 词义
- #n 诱惑；诱惑物
# 例句
- Money is a kind of allurement for us .
	- 对我们来说金钱是种诱惑物。
- The world-class allurement to build cosmopolis agricultural products market system in Shanghai
	- 构建世界级城市上海的农产品市场体系
- The drive forces mainly come from static electricity allurement and cation interaction .
	- 其识别推动力主要来自静电吸引以及阳离子一二相互作用。
# 形态
- #word_pl allurements
