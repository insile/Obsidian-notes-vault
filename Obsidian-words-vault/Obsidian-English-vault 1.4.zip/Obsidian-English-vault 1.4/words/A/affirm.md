# 词义
- 英：/əˈfɜːm/； 美：/əˈfɜːrm/
- #v 申明；断言；肯定属实
# 例句
- For in these monuments are chiseled those unlikely stories that affirm our unyielding faith & a faith that anything is possible in America .
	- 凿在这些纪念碑里面那些难以置信的故事申明了我们不屈的信念。一个在美国一切皆有可能的信念。
- So , now , obviously difficult cultures may have different attitudes about the relationship between men and women , but I think it is the view of the United States that it is important for us to affirm the rights of women all around the world .
	- 当然，不同的文化对男性和女性之间的关系可能会有不同的态度，不过我认为美国的观点是，我们必须申明全世界妇女的权利。
- I can affirm that no one will lose their job .
	- 我可以肯定，谁都不会丢掉工作。
# 形态
- #word_third affirms
- #word_ing affirming
- #word_done affirmed
- #word_past affirmed
