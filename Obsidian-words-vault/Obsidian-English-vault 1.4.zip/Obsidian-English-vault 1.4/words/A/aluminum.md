# 词义
- 英：/əˈljʊmɪnəm/； 美：/əˈlumənəm/
- #n 铝
# 例句
- He had a house there and a dock and a little aluminum boat .
	- 他在那儿有一所房子、一个泊船的码头和一艘小铝船。
- The materials from e-waste include iron , copper , gold , silver , and aluminum materials that could be reused , resold , salvaged , or recycled .
	- 电子垃圾中的材料包括铁、铜、金、银和铝这些材料可以重复使用、转售、回收或循环利用。
- Most solar heating systems use large aluminum or alloy sheets , painted black to absorb the sun 's heat .
	- 大多数太阳能热水器使用大片的涂成黑色的铝板或合金板来吸收太阳的热量。
