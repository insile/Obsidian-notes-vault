# 词义
- 英：/eɪdz/； 美：/eɪdz/
- #n 艾滋病(全写为Acquired Immune Deficiency Syndrome，获得性免疫缺陷综合征)
# 例句
- The money will go to the San Francisco AIDS Foundation .
	- 这笔钱将交给旧金山艾滋病基金会。
- Scientists around the world are working to discover a cure for AIDS .
	- 全世界的科学家都在努力寻找治疗艾滋病的方法。
- They give advice for people with HIV and AIDS .
	- 他们向艾滋病病毒携带者和艾滋病患者提供咨询。
