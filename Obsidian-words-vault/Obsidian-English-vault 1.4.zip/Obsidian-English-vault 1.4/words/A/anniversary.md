# 词义
- 英：/ˌænɪˈvɜːsəri/； 美：/ˌænɪˈvɜːrsəri/
- #n 周年纪念日
# 例句
- It 's our anniversary .
	- 今天是我们的周年纪念日。
- It was the fortieth anniversary of the death of the composer .
	- 这是该作曲家逝世40周年纪念日。
- Today 's our wedding anniversary .
	- 今天是我们的结婚纪念日。
# 形态
- #word_pl anniversaries
