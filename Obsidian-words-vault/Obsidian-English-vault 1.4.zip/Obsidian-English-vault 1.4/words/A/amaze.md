# 词义
- 英：/əˈmeɪz/； 美：/əˈmeɪz/
- #vt 使惊奇；使惊愕
# 例句
- It 's amazing how soon you adapt .
	- 你这么快就适应了，真是令人惊奇。
- It was amazing to see how she made progress in English .
	- 看到她在英语方面取得的进步真是令人惊奇。
- I find it amazing that they 're still together .
	- 他们还在一起，这使我大吃一惊。
# 形态
- #word_third amazes
- #word_ing amazing
- #word_done amazed
- #word_past amazed
