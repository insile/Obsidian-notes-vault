# 词义
- 英：/əˈmendmənt/； 美：/əˈmendmənt/
- #n (法律、文件的)修订；(美国宪法的)修正案
# 例句
- The 19th Amendment gave women the right to vote .
	- 第19条修正案赋予妇女选举权。
- The Opposition moved an amendment to the Bill .
	- 反对派对法案提出修正案。
- She made several minor amendments to her essay .
	- 她对自己的论文作了几处小的修改。
# 形态
- #word_pl amendments
