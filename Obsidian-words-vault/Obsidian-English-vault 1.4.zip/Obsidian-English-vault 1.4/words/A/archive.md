# 词义
- 英：/ˈɑːkaɪv/； 美：/ˈɑːrkaɪv/
- #n 档案；档案馆；档案室；档案文件
- #vt 把…存档；把…归档；将(不常用信息)存档
# 例句
- Type : The type of module , such as system module ( car ), jar module ( jar ), web archive ( war ), enterprise archive ( ear ), and so on .
	- Type：模块类型，比如系统模块（car）、jar模块（jar）、web档案文件（war）、企业档案文件（ear），等等。
- Enter a name and storage location for the project archive file .
	- 请为项目档案文件输入名称和存储位置。
- The BBC 's archives are bulging with material .
	- 英国广播公司的档案库材料极其丰富。
# 形态
- #word_third archives
- #word_ing archiving
- #word_done archived
- #word_pl archives
- #word_past archived
