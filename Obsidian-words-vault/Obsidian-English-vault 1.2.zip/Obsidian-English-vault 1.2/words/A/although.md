# 词义
- 英：/ɔːlˈðəʊ/； 美：/ɔːlˈðoʊ/
- #conj 虽然；尽管；不过；然而；即使
# 例句
- The two pictures are similar , although not identical .
	- 这两幅画很相似，虽然不完全相同。
- I like her , although I could cheerfully throttle her at times .
	- 我喜欢她，虽然有时烦得真想把她掐死。
- They got on well together although they were total strangers .
	- 尽管以前素未谋面，但他们相处融洽。
