# 词义
- 英：/əˈpɔɪntmənt/； 美：/əˈpɔɪntmənt/
- #n 任命；委任；预约；约会；职位；职务；约定
# 例句
- Have you an appointment ?
	- 你有约会吗？
- The appointment is at 3 p.m.
	- 约会定于下午3点。
- What is the latest time I can have an appointment ?
	- 最晚的预约时间是几点钟？
# 形态
- #word_pl appointments
