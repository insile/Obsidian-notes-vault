# 词义
- 英：/əˈkaʊnt/； 美：/əˈkaʊnt/
- #n 账户，账号；账户；解释，说明，叙述；账目；描述；赊购；老主顾；赊销账；赊欠账
- #vt 认为是；视为
# 例句
- I 'd like to pay some money into my account .
	- 我想在我的账户里存一些钱。
- How can I transfer money from my bank account to his ?
	- 怎么才能把我账户上的钱转到他的账户上呢？
- People often give very different accounts of the same event .
	- 人们常常对同一件事的叙述大为不同。
# 形态
- #word_third accounts
- #word_ing accounting
- #word_done accounted
- #word_pl accounts
- #word_past accounted
