# 词义
- 英：/ænˈtiːk/； 美：/ænˈtiːk/
- #n 古董；文物；古物；古玩
- #adj 古董的；古老的
- #v 寻觅古玩；使显得古色古香；仿古制作
# 例句
- This isn 't a genuine antique ─ you 've been done .
	- 这不是真正的古董——你上当了。
- They were trying to palm the table off as a genuine antique .
	- 他们在设法把那张普通桌子当真正的古董推销出去。
- The value of antiques will depend on their condition and rarity .
	- 古董的价值依它们的保存状况和稀有程度而定。
# 形态
- #word_third antiques
- #word_ing antiquing
- #word_done antiqued
- #word_pl antiques
- #word_past antiqued
