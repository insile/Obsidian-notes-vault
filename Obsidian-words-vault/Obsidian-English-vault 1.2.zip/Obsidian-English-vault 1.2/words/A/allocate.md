# 词义
- 英：/ˈæləkeɪt/； 美：/ˈæləkeɪt/
- #vt 分配；拨…(给)；划…(归)
# 例句
- You must allocate the money carefully .
	- 你们必须谨慎地分配钱。
- I allocate some time every day to relax . It really helps me clear my head !
	- （我每天都会分配一些时间来放松。这样做真的有助于帮我理清思绪。）
- More resources are being allocated to the project .
	- 正在调拨更多的资源给这个项目。
# 形态
- #word_third allocates
- #word_ing allocating
- #word_done allocated
- #word_past allocated
