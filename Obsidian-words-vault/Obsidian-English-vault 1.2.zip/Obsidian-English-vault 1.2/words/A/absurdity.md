# 词义
- 英：/əbˈsɜːdɪti/； 美：/əbˈsɜrdəti/
- #n 荒谬；荒唐；谬论；不合理；荒唐的事；荒唐行为
# 例句
- It was only later that she could see the absurdity of the situation .
	- 直到后来她才看出了那种局面的荒唐。
- Once aboard we were soon helpless with laughter at the absurdity of it
	- 一上飞机我们就按捺不住，大笑起这事的荒唐。
- The absurdity of the situation made everyone laugh .
	- 情况的荒谬可笑使每个人都笑了。
# 形态
- #word_pl absurdities
