# 词义
- 英：/əˈnɔɪ/； 美：/əˈnɔɪ/
- #vt 使生气；惹恼；使恼怒；骚扰；打扰
- #n 同“annoyance”
# 例句
- Even if your application is fast and responsive , it can still annoy users .
	- 即使应用运行快速和响应及时，这任然可能惹恼用户。
- What did you do to annoy him this time ?
	- 你这次又怎么惹恼了他？
- I like her , even though she can be annoying at times .
	- 尽管她有时可能很烦人，我还是喜欢她。
# 形态
- #word_third annoys
- #word_ing annoying
- #word_done annoyed
- #word_past annoyed
