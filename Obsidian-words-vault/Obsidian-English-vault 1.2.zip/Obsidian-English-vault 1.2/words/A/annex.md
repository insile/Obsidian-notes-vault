# 词义
- 英：/əˈneks/； 美：/əˈneks/
- #n 附件；附录；附属建筑；附属物（品）
- #vt 强占，并吞(国家、地区等)
# 例句
- Annex 4 domestic support : calculation of equivalent measurement of support
	- 附件4国内支持：支持等值的计算
- Annex A provides information specific to one organization .
	- 附件A提供了某一组织的信息。
- Germany annexed Austria in 1938 .
	- 1938年德国吞并了奥地利。
# 形态
- #word_third annexes
- #word_ing annexing
- #word_done annexed
- #word_pl annexes
- #word_past annexed
