# 词义
- 英：/ˈeɪnʃənt/； 美：/ˈeɪnʃənt/
- #adj 古代的；古老的；很老的；(尤指埃及、希腊和罗马的)古代人
- #n 古代人；<古>旗手；古文明国的国民；<古>高龄老人
# 例句
- Only the names are ancient ; the characters are modern and contemporary .
	- 只有姓名是古代的；人物都是现代的、摩登的。
- Ancient scrolls were found in caves by the Dead Sea .
	- 死海旁边的山洞里发现了古代的卷轴。
- He 's ancient ─ he must be at least fifty !
	- 他老得很了——肯定至少有五十岁！
# 形态
- #word_pl ancients
