# 词义
- 英：/ænˈtæɡənɪzəm/； 美：/ænˈtæɡənɪzəm/
- #n 敌对；敌意；对立情绪；对抗情绪
# 例句
- There is still much antagonism between trades unions and the oil companies
	- 工会和石油公司之间仍然存在着相当大的敌意。
- He felt a strong antagonism towards his immediate superior .
	- 他对他的顶头上司怀着强烈的敌意。
- The antagonism he felt towards his old enemy was still very strong .
	- 他对宿敌的仇恨仍然十分强烈。
# 形态
- #word_pl antagonisms
