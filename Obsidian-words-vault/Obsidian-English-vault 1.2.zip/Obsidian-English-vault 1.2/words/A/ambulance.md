# 词义
- 英：/ˈæmbjələns/； 美：/ˈæmbjələns/
- #n 救护车
# 例句
- The ambulance arrived within minutes of the call being made .
	- 打电话后几分钟内救护车就到了。
- He didn 't even have the intelligence to call for an ambulance .
	- 他连呼叫救护车的头脑都没有。
- Ambulance drivers provided only emergency cover during the dispute .
	- 纠纷期间救护车司机只提供急救替班。
# 形态
- #word_pl ambulances
