# 词义
- 英：/ɔːlˈredi/； 美：/ɔːlˈredi/
- #adv 已经(强调情况或问题存在)；(表示惊奇)已经，都；早已
# 例句
- He already had an idea for his next novel .
	- 他已经构思好了下一部小说。
- I 'm going ─ I 've done enough damage here already .
	- 我要走了——我在这里造成的损害已经够大了。
- We had to work within the parameters that had already been established .
	- 我们必须在已设定的范围内工作。
