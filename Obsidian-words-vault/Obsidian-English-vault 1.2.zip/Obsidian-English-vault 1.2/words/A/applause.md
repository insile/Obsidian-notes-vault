# 词义
- 英：/əˈplɔːz/； 美：/əˈplɔːz/
- #n 掌声；鼓掌；喝彩
# 例句
- There was a great round of applause when the dance ended .
	- 舞蹈结束的时候，爆发出了一阵热烈的掌声。
- When the applause had died down , she began her speech .
	- 掌声平息后她便开始演讲了。
- Give her a big round of applause !
	- 为她热烈鼓掌！
