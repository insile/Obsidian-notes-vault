# 词义
- 英：/ˈæmplɪfaɪ/； 美：/ˈæmplɪfaɪ/
- #v 放大；增强(声音等)；充实(故事、事情、陈述等)；阐发
# 例句
- This landscape seemed to trap and amplify sounds
	- 这种地貌好像可以笼住并放大声音。
- Before liquefaction , soil would amplify the function of vibration .
	- 液化前，土体对振动起放大作用；
- You may need to amplify this point .
	- 你可能需要对这一点进一步予以说明。
# 形态
- #word_third amplifies
- #word_ing amplifying
- #word_done amplified
- #word_past amplified
