# 词义
- 英：/ˈænəlɪst/； 美：/ˈænəlɪst/
- #n 分析师；分析者；化验员
# 例句
- Curran , the Accenture analyst , said that increased government interest in the show makes sense as technology becomes a larger part of our lives .
	- 埃森晢咨询公司分析师库兰认为，政府对科技展越来越感兴趣是必然的，因为科技已经成为我们生活中的一大部分。
- I 'm a market research analyst .
	- 我是市场调查分析师。
- City analysts forecast huge profits this year .
	- 伦敦金融分析家预测今年的利润非常丰厚。
# 形态
- #word_pl analysts
