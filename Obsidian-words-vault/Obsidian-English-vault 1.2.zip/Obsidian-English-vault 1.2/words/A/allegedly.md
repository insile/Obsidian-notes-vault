# 词义
- #adv 据称；根据(人们)宣称
# 例句
- He lost his job for allegedly being incapable .
	- 据说他由于软弱无能而丢掉了工作。
- The police report stated that he was arrested for allegedly assaulting his wife
	- 警方的报告称，他因涉嫌殴打妻子而被捕。
- A writer is suing director Steven Spielberg for allegedly stealing his film idea
	- 一名作家正控告导演史蒂文·斯皮尔伯格涉嫌剽窃了他的电影创意。
