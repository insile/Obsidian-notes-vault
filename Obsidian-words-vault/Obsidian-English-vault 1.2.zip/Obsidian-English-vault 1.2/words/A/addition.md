# 词义
- 英：/əˈdɪʃn/； 美：/əˈdɪʃn/
- #n 附加；增加；添加；加；加法；添加物；增加物
# 例句
- Calculation method for stress of shaft wall under vertical addition force
	- 考虑竖向附加力时井壁应力计算方法
- Methods of Genetic Analysis on Quantitative Traits in Alien Addition Lines
	- 异附加系数量性状的遗传分析方法
- There is , in addition , one further point to make .
	- 此外，还有一点要说。
# 形态
- #word_pl additions
