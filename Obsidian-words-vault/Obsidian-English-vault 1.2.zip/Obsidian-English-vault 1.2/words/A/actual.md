# 词义
- 英：/ˈæktʃuəl/； 美：/ˈæktʃuəl/
- #adj 实际的；(强调事情最重要的部分)真正的，…本身；真实的
# 例句
- The actual nest is a work of art .
	- 真实的鸟巢十分精致。
- The segments are filmed using either local actors or the actual people involved
	- 这些片断是由当地的演员或真实的当事人参与拍摄的。
- First we need to identify actual and potential problems .
	- 首先，我们需要弄清实际的问题和潜在的问题。
