# 词义
- 英：/əˈlaɪn/； 美：/əˈlaɪn/
- #v 使一致；排列；校准；(尤指)使成一条直线；排整齐
# 例句
- This will align our line numbers in the first six columns of the output line .
	- 这将把行号排列到输出行的前6个列中。
- Align the columns with the top of the page .
	- 将这些栏目与本页的上头并排排列。
- Domestic prices have been aligned with those in world markets .
	- 国内价格已调整到与世界市场一致。
# 形态
- #word_third aligns
- #word_ing aligning
- #word_done aligned
- #word_past aligned
