# 词义
- 英：/əˈpɔɪnt/； 美：/əˈpɔɪnt/
- #vt 任命；委任；安排，确定(时间、地点)
# 例句
- He promised to appoint an AIDS czar to deal with the disease .
	- 他许诺任命一位艾滋病大使来应对这种疾病。
- I have resigned , and they have a free hand to appoint whom they like in my place .
	- 我已经辞职了，他们可以放开手脚任命他们喜欢的人来顶替我的位置。
- A new manager has been appointed to direct the project .
	- 已任命一位新经理来管理这项工程。
# 形态
- #word_third appoints
- #word_ing appointing
- #word_done appointed
- #word_past appointed
