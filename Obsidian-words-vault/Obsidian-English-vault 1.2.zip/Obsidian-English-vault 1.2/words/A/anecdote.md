# 词义
- 英：/ˈænɪkdəʊt/； 美：/ˈænɪkdoʊt/
- #n 轶事；趣闻；传闻；逸事
# 例句
- He has a talent for recollection and anecdote .
	- 他在记忆力和讲述趣闻轶事方面颇具天赋。
- He listened to this anecdote about the president 's childhood .
	- 他听着这段关于总统幼年时代的轶事。
- This research is based on anecdote not fact .
	- 这项研究的根据是传闻而非事实。
# 形态
- #word_pl anecdotes
