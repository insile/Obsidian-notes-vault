# 词义
- 英：/ˈeni/； 美：/ˈeni/
- #det 任何；(与单数可数名词连用)任一；不寻常的；非一般的；(与不可数或复数名词连用，用于否定句和疑问句，也用于if或whether之后，或紧接某些动词如prevent、ban、forbid等)任一的
- #pron 任一；任何一些；(用于否定句和疑问句中或if、whether后)任一数额
- #adv (用于否定句末)根本(不)；(用于否定句或疑问句中，加强形容词或副词的语气)完全(不)
- #adj 任何；一个；什么；一般的
# 例句
- Your request shouldn 't present us with any problems .
	- 你的请求应该不会给我们造成任何问题。
- We are not getting any further forward with the discussion .
	- 我们的讨论没有取得任何进展。
- They couldn 't give me any more information .
	- 他们不可能给我提供更多的信息。
