# 词义
- 英：/əˈpriːʃieɪt/； 美：/əˈpriːʃieɪt/
- #v 理解；感谢；欣赏；感激；欢迎；意识到；增值；重视；领会；赏识
# 例句
- You really need a magnifying glass to appreciate all the fine detail .
	- 确实需要放大镜才能欣赏到一切细微之处。
- Only inside do you appreciate the church 's true grandeur .
	- 只有深入其中，你才能真正欣赏教堂的富丽堂皇。
- We would appreciate you letting us know of any problems .
	- 如有任何问题，请告诉我们。
# 形态
- #word_third appreciates
- #word_ing appreciating
- #word_done appreciated
- #word_past appreciated
