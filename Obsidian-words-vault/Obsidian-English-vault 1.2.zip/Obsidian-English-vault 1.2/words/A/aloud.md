# 词义
- 英：/əˈlaʊd/； 美：/əˈlaʊd/
- #adv 大声地；出声地
# 例句
- This was said as if thinking aloud .
	- 他说这句话就好像在出声地思索。
- As soon as people heard this , they laughed aloud at him .
	- 当时在周围的人听了这话，都大声地讥笑他。
- The teacher listened to the children reading aloud .
	- 老师听着孩子们朗读。
