# 词义
- 英：/əˈdɪʃənl/； 美：/əˈdɪʃənl/
- #adj 附加的；额外的；外加的
# 例句
- I have one lock but I bought another as an additional insurance against thieves .
	- 我有一把锁，但我又买了一把作为附加的防盗保障。
- When it is dragged over pliant areas , an additional percussive tap could indicate this collision .
	- 当它被拖到受范区域时，一个附加的敲击声提示这种碰触
- This system imposes additional financial burdens on many people .
	- 这个制度给很多人增加了额外的经济负担。
