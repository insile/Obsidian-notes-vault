# 词义
- 英：/əˈnaʊnsmənt/； 美：/əˈnaʊnsmənt/
- #n (指行动)宣布；公告；通告；宣告；(一项)布告
# 例句
- The announcement had a dramatic effect on house prices .
	- 这项公告对房屋价格产生了巨大的影响。
- Following the announcement , share prices went into a tailspin .
	- 公告宣布后，股市大跌。
- I have an important announcement to make .
	- 我要宣布一件重要的事情。
# 形态
- #word_pl announcements
