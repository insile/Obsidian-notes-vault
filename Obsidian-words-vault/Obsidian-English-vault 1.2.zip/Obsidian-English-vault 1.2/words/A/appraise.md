# 词义
- 英：/əˈpreɪz/； 美：/əˈpreɪz/
- #vt 评价；估价；(对某人的工作)作出评价；估量
# 例句
- New Concept and Appraise of the Highway Efficiency Under Market Economy
	- 市场经济下公路运输效率的新定义及评价
- The second part , design of appraise index system to financial risk .
	- 第二部分，金融风险评价指标体系设计。
- His eyes coolly appraised the young woman before him .
	- 他双眼冷静地打量着面前的年轻女子。
# 形态
- #word_third appraises
- #word_ing appraising
- #word_done appraised
- #word_past appraised
