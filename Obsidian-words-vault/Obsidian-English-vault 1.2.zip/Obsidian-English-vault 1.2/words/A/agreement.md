# 词义
- 英：/əˈɡriːmənt/； 美：/əˈɡriːmənt/
- #n 协定；同意；(意见或看法)一致；契约；应允；协议
# 例句
- The new trade agreement should facilitate more rapid economic growth .
	- 新贸易协定应当会加快经济发展。
- We consider this agreement to be an important step forward .
	- 我们认为，这项协定是向前迈出了重要的一步。
- We need to come to some form of agreement .
	- 我们需要达成某种形式的协议。
# 形态
- #word_pl agreements
