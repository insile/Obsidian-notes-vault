# 词义
- 英：/əˈspaɪə(r)/； 美：/əˈspaɪər/
- #vi 渴望(成就)；有志(成为)
# 例句
- The world 's students may aspire to work for Google .
	- 全世界的学生可能都渴望为谷歌工作。
- And not let it control what I aspire to have .
	- 但未来不能支配我渴望得到的东西。
- Aspiring musicians need hours of practice every day .
	- 想当音乐家就要每天练许多小时。
# 形态
- #word_third aspires
- #word_ing aspiring
- #word_done aspired
- #word_past aspired
