# 词义
- 英：/əˈʃɔː(r)/； 美：/əˈʃɔːr/
- #adv 向(或在)岸上，向(或在)陆地
- #adj 在岸上的，在陆上的
# 例句
- The water was only waist-deep and I walked ashore .
	- 海水仅及我的腰部，我向岸上走去。
- Call for assistance from ashore by VHF .
	- 通过甚高频电话向岸上求救。
- The cruise included several days ashore .
	- 这次航行包括几天陆上行程。
