# 词义
- 英：/ˈɑːnsə(r)/； 美：/ˈænsər/
- #n 回答；(试题、练习等的)答案，正确答案；(问题的)解决办法，答案；答复；足以媲美的人
- #v 回答；答复；符合；适合；比得上；相配
# 例句
- He didn 't give an adequate answer to the question .
	- 他没有对这个问题作出满意的答复。
- I 'm going to have to push you for an answer .
	- 我将不得不催促你答复了。
- She of all people should know the answer to that .
	- 在所有的人中，唯有她最应知道那个问题的答案。
# 形态
- #word_third answers
- #word_ing answering
- #word_done answered
- #word_past answered
