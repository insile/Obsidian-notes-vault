# 词义
- 英：/ˌæmjuˈnɪʃn/； 美：/ˌæmjuˈnɪʃn/
- #n 弹药；(辩论中可攻击对方的)信息，事实，炮弹
# 例句
- Stocks of ammunition were running low .
	- 弹药的库存正在减少。
- They fired in long bursts , which depleted their ammunition
	- 他们长时间开火，耗尽了弹药。
- The letter gave her all the ammunition she needed .
	- 这封信给了她所需的一切有力证据。
