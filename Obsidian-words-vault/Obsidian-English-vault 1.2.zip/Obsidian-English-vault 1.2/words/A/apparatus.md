# 词义
- 英：/ˌæpəˈreɪtəs/； 美：/ˌæpəˈrætəs/
- #n 装置；仪器；(尤指政党或政府的)机构，组织，机关；器械；器官
# 例句
- The apparatus is spotlessly clean .
	- 仪器上一尘不染。
- This apparatus scans patients ' brains for tumours .
	- 这台仪器扫描检查病人的脑瘤
- Firefighters needed breathing apparatus to enter the burning house .
	- 消防队员需要呼吸器以便进入燃烧的大楼。
# 形态
- #word_pl apparatuses
