# 词义
- 英：/ɔːlˈtɜːnətɪv/； 美：/ɔːlˈtɜːrnətɪv/
- #adj 另类的；非传统的；可供替代的
- #n 可供选择的事物
# 例句
- We are currently investigating a number of alternative options .
	- 我们现在正在研究一系列可供替代的选择方案。
- Alternative architectures exist and should be evaluated with an expert based on all available information .
	- 还有一些可供替代的架构，应该让具备所有相关可用知识的专家对它们进行评估。
- There is a vegetarian alternative on the menu every day .
	- 每天的菜单上另有素食餐点。
# 形态
- #word_pl alternatives
