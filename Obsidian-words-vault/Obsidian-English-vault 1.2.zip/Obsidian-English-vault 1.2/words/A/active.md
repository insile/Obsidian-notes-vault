# 词义
- 英：/ˈæktɪv/； 美：/ˈæktɪv/
- #adj 积极的；(尤指体力上)忙碌的，活跃的；起作用的；定期进行的；主动语态的；起化学作用的
- #n 主动语态
# 例句
- In spite of his age , he still leads an active life .
	- 尽管年事已高，他依旧过着一种忙碌的生活。
- Idiom : in In spite of his age , he still leads an active life .
	- 尽管年事已高，他依旧过着一种忙碌的生活。
- She takes an active part in school life .
	- 她积极参加学校活动。
# 形态
- #word_est most active
- #word_er more active
