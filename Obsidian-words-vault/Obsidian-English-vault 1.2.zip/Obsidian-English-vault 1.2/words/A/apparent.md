# 词义
- 英：/əˈpærənt/； 美：/əˈpærənt/
- #adj 显然的；显然；显而易见；表面上的；貌似的；明白易懂；未必真实的
# 例句
- apparent It is apparent that you dislike your job .
	- adj.显然的；表面上的很明显，你不喜欢你的工作。n.谷仓；
- Here the advantage of praxis over general theories is apparent .
	- 这里，实践优于一般理论是很显然的。
- It soon became apparent that no one was going to come .
	- 很快就很清楚，没人会来。
