# 词义
- 英：/ˈeɪdʒɪŋ/； 美：/ˈeɪdʒɪŋ/
- #n 老化；变老；苍老；变旧
- #adj 老化的；变老的；老朽的；变旧的
- #v (使)成熟，变陈；使变老；变老；使苍老；使显老
# 例句
- ' Do you worry about ageing ? ' — ' Not in the slightest . '
	- “你担心变老吗？”——“一点也不。”
- Ageing to me is not being able to do what you used to do .
	- 对于我来说变老就是不能再做以前的事
- They were both only 20 years of age .
	- 他们两人都只有20岁。
# 形态
- #word_proto age
