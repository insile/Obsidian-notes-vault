# 词义
- 英：/əˈlɑːm/； 美：/əˈlɑːrm/
- #n 警报；警报器；恐慌；惊慌；惊恐
- #vt 使担心；使惊恐；使害怕；给(门等)安装警报器
# 例句
- ' What have you done ? ' Ellie cried in alarm .
	- “你都干了些什么？”埃利惊恐地喊道。
- Ainslie 's pulse quickened in alarm
	- 由于惊恐，安斯利的脉搏加快了。
- Could I have an alarm call at 5.30 tomorrow , please ?
	- 请在明天早晨5:30打电话叫醒我好吗？
# 形态
- #word_third alarms
- #word_ing alarming
- #word_done alarmed
- #word_pl alarms
- #word_past alarmed
