# 词义
- 英：/ænˌtɪsɪˈpeɪʃn/； 美：/ænˌtɪsɪˈpeɪʃn/
- #n 预期；预计；期待；预料；期望；预见；期盼
# 例句
- There 's been an atmosphere of anticipation around here for a few days now
	- 几天来这里一直有一种满怀期待的气氛。
- He will be attending next week 's American Grammy Awards in feverish anticipation .
	- 他将带着紧张兴奋的期待出席下周的美国格莱美奖颁奖。
- He bought extra food in anticipation of more people coming than he 'd invited .
	- 他预料来的客人会比邀请的多，就多买了食物。
# 形态
- #word_pl anticipations
