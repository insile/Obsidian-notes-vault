# 词义
- 英：/eɪm/； 美：/eɪm/
- #n 目的；目标；瞄准
- #v 旨在，目的是；针对，指向；瞄准，对准；打算，企图
# 例句
- Our main aim is to increase sales in Europe .
	- 我们的主要目标是增加在欧洲的销售量。
- The college 's aim is to help students achieve their aspirations .
	- 大学的目标是帮助学生实现他们的抱负。
- The new management techniques aim to improve performance .
	- 新的管理技术旨在提高效率。
# 形态
- #word_third aims
- #word_ing aiming
- #word_done aimed
- #word_pl aims
- #word_past aimed
