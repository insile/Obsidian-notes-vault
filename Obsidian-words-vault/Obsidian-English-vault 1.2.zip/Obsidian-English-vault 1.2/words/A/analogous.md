# 词义
- 英：/əˈnæləɡəs/； 美：/əˈnæləɡəs/
- #adj 类似的；相似的
# 例句
- The analogous dorsal region in other animals .
	- 动物的背部其它动物相似的背部部位。
- And subsequently Starck did the analogous experiment but with an electric field .
	- 之后，斯塔克做了一个相似的实验，不过他在实验中用的是电场。
- Sleep has often been thought of as being in some way analogous to death .
	- 人们常常认为睡眠在某种意义上来说类似死亡。
