# 词义
- 英：/ədˈmaɪə(r)/； 美：/ədˈmaɪər/
- #vt 欣赏；钦佩；赞赏；仰慕
# 例句
- I really admire your enthusiasm .
	- 我确实钦佩你的热情。
- I admire his thoroughness .
	- 我钦佩他办事认真仔细。
- The new building has been very much admired .
	- 这座新建筑物是人见人夸。
# 形态
- #word_third admires
- #word_ing admiring
- #word_done admired
- #word_past admired
