# 词义
- 英：/əˈraɪvl/； 美：/əˈraɪvl/
- #n 到达；抵达；(新技术、新思想的)引进，采用，推行；到达者；抵达物
# 例句
- A computer screen shows arrival and departure times .
	- 电脑屏幕显示出到达和离开的时间。
- All visitors must report to the reception desk on arrival .
	- 所有参观者到达后务必在接待处报到。
- We 're expecting a new arrival in the family soon .
	- 我们家很快就会添一个新生婴儿。
# 形态
- #word_pl arrivals
