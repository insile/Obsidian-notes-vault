# 词义
- 英：/ˈeəkrɑːft/； 美：/ˈerkræft/
- #n 飞机；航空器
# 例句
- Production of the new aircraft will start next year .
	- 新飞机的生产将于明年开始。
- The factory was turned over to the manufacture of aircraft parts .
	- 这家工厂转产飞机部件。
- The use of cellular phones is not permitted on most aircraft .
	- 大多数飞机上不许使用手机。
# 形态
- #word_pl aircraft
