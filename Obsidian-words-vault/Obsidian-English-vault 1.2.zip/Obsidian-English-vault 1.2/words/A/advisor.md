# 词义
- 英：/ədˈvaɪzə/； 美：/ædˈvaɪzər/
- #n 顾问；提供意见者
# 例句
- Step into your academic advisor 's office , introduce yourself , and begin making the valuable connections that are necessary to help during the rest of your college career ．
	- 走进你的学术顾问办公室,自我介绍,并开始建立在你余下的大学生涯中所必需的有价值的联系。
- The advisor suggested , " What you are looking for cannot be brought to you . "
	- 顾问建议说：“你要找的东西不能拿来给你。”
- The governors felt that they were being strung along by their advisors .
	- 地方长官感到他们一直在受顾问们的愚弄。
# 形态
- #word_pl advisors
