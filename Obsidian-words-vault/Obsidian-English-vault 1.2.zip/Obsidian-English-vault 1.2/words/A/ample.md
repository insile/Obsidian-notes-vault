# 词义
- 英：/ˈæmpl/； 美：/ˈæmpl/
- #adj 充足的；足够的；丰满的；丰裕的；硕大的
# 例句
- There 'll be ample opportunity to relax , swim and soak up some sun
	- 将会有充足的机会去放松、游泳和晒太阳。
- Agriculture has developed rapidly , thus providing light industry with ample raw materials .
	- 农业迅速发展，从而为轻工业提供了充足的原料。
- There was ample time to get to the airport .
	- 有足够的时间到达机场。
# 形态
- #word_est amplest
- #word_er ampler
