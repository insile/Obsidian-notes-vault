# 词义
- #adv 对抗性；反对地
# 例句
- Auxin and cytokinin play antagonistically important roles in many aspects of plant growth and development .
	- 生长素和细胞分裂素相互拮抗并共同调控植物的生长和发育的诸多方面。
- They compete with one another but provide sufficiently different services that they can do so cooperatively rather than antagonistically .
	- 它们彼此竞争，但是提供各不相同的服务，它们以协作而不是敌对的方式提供服务。
- He behaves antagonistically toward his colleagues .
	- 他对他的同事采取敌对态度。
