# 词义
- 英：/ˈeniθɪŋ/； 美：/ˈeniθɪŋ/
- #pron （用于描述所谈论事物的词语前）…的东西，…的事情；（用于疑问句或条件从句）任何事物，任何事情；（用于否定句）任何事物，什么事情 ；（限定范围内的）任何一点；（用于加强语气）无论什么东西，随便什么事情；（用于强调）多少接近于
# 例句
- I won 't be bullied into signing anything .
	- 我绝不会屈服于压力签署任何东西。
- He is convinced he just has to say ' please ' and he can have anything .
	- 他深信只要说一个“请”字，他就能拥有任何东西。
- If you need anything , I am at your service .
	- 您要是需要什么，请尽管吩咐。
