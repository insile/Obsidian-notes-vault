# 词义
- 英：/əˈbɔːʃn/； 美：/əˈbɔːrʃn/
- #n 堕胎；流产；人工流产；堕胎手术；人工流产手术；打胎
# 例句
- She decided to have an abortion .
	- 她决定做人工流产。
- Sometimes the original abortion was done so badly that the uterus prolapsed .
	- 有时第一次流产手术做得太糟糕，会导致子宫下垂。
- They are totally opposed to abortion .
	- 他们完全反对堕胎。
# 形态
- #word_pl abortions
