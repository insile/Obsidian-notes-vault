# 词义
- 英：/ədˈvaɪzəri/； 美：/ədˈvaɪzəri/
- #adj 咨询的；顾问的
- #n 警报
# 例句
- She is employed by them in an advisory capacity .
	- 他以顾问的身分地位被他们聘用。
- He is acting in an advisory capacity .
	- 他以顾问的身份发挥作用（或行为）。
- We are simply involved in an advisory capacity on the project .
	- 我们只不过是以顾问身份参与这个项目。
# 形态
- #word_pl advisories
