# 词义
- 英：/ˌɑːftəˈnuːn/； 美：/ˌæftərˈnuːn/
- #n 下午(中午12点至下午6点左右)
# 例句
- Our system should be up by this afternoon .
	- 到今天下午，我们的电脑系统应该运行起来了。
- Where were you on the afternoon of May 21 ?
	- 5月21日下午你在哪里？
- I saw her one afternoon last week .
	- 我在上周的一个下午见到了她。
# 形态
- #word_pl afternoons
