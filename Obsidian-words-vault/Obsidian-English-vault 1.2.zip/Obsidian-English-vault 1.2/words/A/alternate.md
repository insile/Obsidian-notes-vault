# 词义
- 英：/ɔːlˈtɜːnət , ˈɔːltəneɪt , ˈɔːltɜːnət/； 美：/ˈɔːltərnət , ˈɔːltərneɪt/
- #n 候补；代理人；代替者
- #v (使)交替；(使)轮流
- #adj 交替的；间隔的；轮流的；每隔(…天等)的
# 例句
- Select the Lead time alternate region for the item .
	- 选择的筹建时间候补地区的项目。
- In those cases , the only option is to use alternate data binding .
	- 在那些情况下，唯一点选择就是使用候补数据绑定。
- Alternate cubes of meat and slices of red pepper .
	- 交替放置肉丁和红辣椒片。
# 形态
- #word_third alternates
- #word_ing alternating
- #word_done alternated
- #word_past alternated
