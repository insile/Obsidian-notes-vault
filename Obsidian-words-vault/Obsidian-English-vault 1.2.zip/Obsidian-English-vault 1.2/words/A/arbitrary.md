# 词义
- 英：/ˈɑːbɪtrəri/； 美：/ˈɑːrbɪtreri/
- #adj 任意的；武断的；专横的；专制的；随心所欲的
# 例句
- Load an arbitrary matrix to the current projection matrix .
	- 加载一个任意的矩阵到当前的投影矩阵。
- This element represents any arbitrary XML content in an XML Schema .
	- 这个元素代表XML模式中任意的XML内容。
- The choice of players for the team seemed completely arbitrary .
	- 看来这个队的队员完全是随意选定的。
