# 词义
- 英：/əˈriːnə/； 美：/əˈriːnə/
- #n 竞技场；活动场所；竞争舞台；圆形剧场；斗争场所；圆形运动场
# 例句
- The competitors cantered into the arena to conclude the closing ceremony .
	- 选手们慢跑进入竞技场，为闭幕式画上了句号。
- The arena was bathed in warm sunshine
	- 竞技场沐浴在温暖的阳光中。
- They 're in concert at Wembley Arena .
	- 他们在温布利体育馆演出。
# 形态
- #word_pl arenas
