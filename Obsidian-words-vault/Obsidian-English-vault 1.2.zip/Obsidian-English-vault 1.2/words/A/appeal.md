# 词义
- 英：/əˈpiːl/； 美：/əˈpiːl/
- #n 上诉；(尤指慈善机构或警方的)呼吁，吁请，恳求；吸引力；申诉；魅力；感染力；启发
- #v 上诉；呼吁；申诉；吁请；有吸引力；恳求；启发；有感染力；引起兴趣
# 例句
- The case was referred to the Court of Appeal .
	- 这个案子被送交到上诉法院。
- He said he would appeal after being found guilty on four counts of murder .
	- 法庭判决他犯有四项谋杀罪，他表示要上诉。
- There is no right of appeal against the decision .
	- 关于这项判决，没有上诉权。
# 形态
- #word_third appeals
- #word_ing appealing
- #word_done appealed
- #word_pl appeals
- #word_past appealed
