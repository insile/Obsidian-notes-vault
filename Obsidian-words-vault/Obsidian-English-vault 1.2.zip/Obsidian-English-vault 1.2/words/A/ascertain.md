# 词义
- 英：/ˌæsəˈteɪn/； 美：/ˌæsərˈteɪn/
- #vt 查明；弄清
# 例句
- It can be difficult to ascertain the facts .
	- 可能难以查明事实真相。
- Tests were conducted to ascertain whether pollution levels have dropped .
	- 做测试以查明污染程度是否下降。
- It must be ascertained if the land is still owned by the government .
	- 必须确定这块土地是否仍属于政府所有。
# 形态
- #word_third ascertains
- #word_ing ascertaining
- #word_done ascertained
- #word_past ascertained
