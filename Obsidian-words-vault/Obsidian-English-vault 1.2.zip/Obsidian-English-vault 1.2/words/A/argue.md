# 词义
- 英：/ˈɑːɡjuː/； 美：/ˈɑːrɡjuː/
- #v 争论；争辩；争吵；论证；证明；表明；说理
# 例句
- I 'm not disposed to argue .
	- 我无意争论。
- He looked at me as if he was defying me to argue .
	- 他看着我，仿佛在激我与他争论。
- He argued that they needed more time to finish the project .
	- 他提出理由说明他们需要更多的时间来完成该项目。
# 形态
- #word_third argues
- #word_ing arguing
- #word_done argued
- #word_past argued
