# 词义
- 英：/əˈsæsɪneɪt/； 美：/əˈsæsɪneɪt/
- #vt 暗杀；(尤为政治目的)行刺
# 例句
- The intelligence service conceived a grand design to assassinate the War Minister .
	- 情报机构策划了一项暗杀陆军部长的重大计划。
- The police have uncovered a plot to assassinate the president .
	- 警方已破获一起暗杀总统的阴谋。
- The prime minister was assassinated by extremists .
	- 首相遭极端分子暗杀。
# 形态
- #word_third assassinates
- #word_ing assassinating
- #word_done assassinated
- #word_past assassinated
