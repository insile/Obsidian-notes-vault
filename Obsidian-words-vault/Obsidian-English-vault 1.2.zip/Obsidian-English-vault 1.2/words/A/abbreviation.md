# 词义
- 英：/əˌbriːviˈeɪʃn/； 美：/əˌbriːviˈeɪʃn/
- #n 缩写；缩写词；缩略；略语
# 例句
- ESNR vocabulary has flexible word-formations including compounding , affixation , conversion and abbreviation .
	- 英语体育新闻报道词汇的构词灵活，常用合成词、加缀词、转类词和缩写词。
- When you see the abbreviation SFRS , you 'd know this is Swiss Franc : such as .
	- 当你见到SFRS的缩写词，这是瑞士法朗，例如。
- The postal abbreviation for Kansas is KS .
	- 堪萨斯州的邮政缩写是KS。
# 形态
- #word_pl abbreviations
