# 词义
- 英：/əˈraʊz/； 美：/əˈraʊz/
- #vt 激起，引起(感情、态度)；激发；唤醒；激起性欲；使行动起来
# 例句
- There is nothing like a long walk to arouse the appetite
	- 没有什么比走很长的路更能激起食欲的了。
- The Treaty has failed to arouse genuine public outrage .
	- 该协定并未真正激起公愤。
- The whole community was aroused by the crime .
	- 这个罪行使整个社会行动起来。
# 形态
- #word_third arouses
- #word_ing arousing
- #word_done aroused
- #word_past aroused
