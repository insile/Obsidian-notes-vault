# 词义
- 英：/əˈmɪdst/； 美：/əˈmɪdst/
- #prep 在…中；中间；在…过程中；同 amid
# 例句
- The visit took place amidst tight security .
	- 访问是在戒备森严的情况下进行的。
- I tackled him about how anyone could live amidst so much poverty .
	- 我坦率地问他，人在如此贫穷的环境中如何还能生存。
- Whatever troubles arise , we 'll have peace of mind amidst seeming chaos .
	- 无论出现什么样的麻烦，我们都会在貌似混乱的情形中保持平和的心态。
