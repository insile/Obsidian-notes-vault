# 词义
- 英：/ˈɑːtəri/； 美：/ˈɑːrtəri/
- #n 动脉；干线(指主要公路、河流、铁路线等)
# 例句
- He had an operation last year to widen a heart artery
	- 去年他接受了一个扩张心脏动脉的手术。
- The research institute is on the track of what causes the artery damage .
	- 研究所正在探究动脉损伤的诱因。
- A muscular spasm in the coronary artery can cause a heart attack
	- 冠状动脉的肌肉痉挛可能导致心脏病。
# 形态
- #word_pl arteries
