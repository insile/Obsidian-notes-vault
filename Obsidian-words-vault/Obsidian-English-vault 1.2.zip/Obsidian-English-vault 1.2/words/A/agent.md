# 词义
- 英：/ˈeɪdʒənt/； 美：/ˈeɪdʒənt/
- #n (演员、音乐家、运动员、作家等的)代理人；（化学）剂；(企业、政治等的)经纪人；动因(指对事态起重要作用的人、事物)；原动力；施事者
# 例句
- You are buying direct , rather than through an agent .
	- 你这是直接购买，而不是通过代理人。
- As an agent , you may have an inside track when good deals become available .
	- 作为代理人，一旦有划算的买卖你恐怕能近水楼台先得月。
- Our agent in New York deals with all US sales .
	- 我们在纽约的代理商经办在整个美国的销售。
# 形态
- #word_pl agents
