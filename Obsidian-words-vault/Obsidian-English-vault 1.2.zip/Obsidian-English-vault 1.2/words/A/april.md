# 词义
- 英：/ˈeɪprəl/； 美：/ˈeɪprəl/
- #n 四月
# 例句
- We went to Japan last April .
	- 去年四月我们去了日本。
- I arrived at the end of April .
	- 我是四月底到达的。
- The new software is planned for release in April .
	- 新软件计划四月份发行。
# 形态
- #word_pl Aprils
