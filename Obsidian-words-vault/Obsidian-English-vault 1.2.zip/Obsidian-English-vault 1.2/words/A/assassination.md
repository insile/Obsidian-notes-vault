# 词义
- 英：/əˌsæsɪ'neɪʃ(ə)n/； 美：/əˌsæsɪ'neɪʃ(ə)n/
- #n 暗杀；刺杀
# 例句
- The assassination of the president precipitated the country into war .
	- 总统被暗杀使国家骤然陷入战争状态。
- The president survived a number of assassination attempts .
	- 总统在数次暗杀企图中幸免于难。
- They shot ten hostages in reprisal for the assassination of their leader .
	- 他们的首领遭到暗杀，他们为了报复，枪杀了十名人质。
# 形态
- #word_pl assassinations
