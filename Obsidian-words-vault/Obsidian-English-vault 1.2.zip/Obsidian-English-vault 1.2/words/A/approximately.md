# 词义
- 英：/əˈprɒksɪmətli/； 美：/əˈprɑːksɪmətli/
- #adv 大约；大概；约莫
# 例句
- At approximately 11:30 p.m. , Pollard finally gave his consent to the search
	- 大概晚上11点半的时候，波拉德最终同意进行搜查。
- Dudok alone shaped most 21th century Hilversum and approximately 75 buildings still bear his unique characteristics , His masterpiece , Hilversum Town Hall , was built in 1928-1931 .
	- 杜尔克自主打造了21世纪希尔弗瑟姆的大部分城景，其中大概75座建筑仍有他的个人风格。他的杰作希尔弗瑟姆市政厅建于1928-1931年。
- The flight takes approximately three hours .
	- 飞行时间大约需要三小时。
