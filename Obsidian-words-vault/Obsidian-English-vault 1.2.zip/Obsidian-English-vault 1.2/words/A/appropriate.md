# 词义
- 英：/əˈprəʊpriət , əˈprəʊprieɪt/； 美：/əˈproʊpriət , əˈproʊprieɪt/
- #adj 适当的；合适的；恰当的
- #vt 拨(专款等)；挪用；占用；盗用；侵吞
# 例句
- Put a cross in the appropriate box .
	- 在适当的长方格里打叉号。
- Put a mark in the appropriate column .
	- 在适当的栏里标上记号。
- Different levels of formality are appropriate in different situations .
	- 不同程度的注重礼节适用于不同场合。
# 形态
- #word_third appropriates
- #word_ing appropriating
- #word_done appropriated
- #word_past appropriated
