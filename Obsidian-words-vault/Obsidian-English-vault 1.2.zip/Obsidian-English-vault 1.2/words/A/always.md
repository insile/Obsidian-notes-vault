# 词义
- 英：/ˈɔːlweɪz/； 美：/ˈɔːlweɪz/
- #adv 总是；一直；(将)永远；（讨厌地）老是，一再；一贯；每次都是；总还，总还有
# 例句
- Work always piles up at the end of the year .
	- 年底总是积压一大堆工作。
- There 's always a lot of traffic at this time of day .
	- 每天这个时候总是有很多来往车辆。
- I always think of you as one of the family .
	- 我一直把你当成自家人。
